package ts.tree;

import java.util.ArrayList;

import ts.Location;
import ts.tree.visit.TreeVisitor;

/**
 * @author Madhuri Gurumurthy
 * 
 *         AST call expression node
 * 
 */
public class CallExpression extends Expression {
	private Expression callExp;
	private ArrayList<Expression> arguments;

	/**
	 * 
	 * @param loc
	 *            source code location of Try Statement
	 * @param callExp
	 *            the call expression
	 * @param arguments
	 *            the arguments with the function call
	 */
	public CallExpression(Location loc, Expression callExp,
			ArrayList<Expression> arguments) {
		super(loc);
		this.callExp = callExp;
		this.arguments = arguments;
	}

	/**
	 * 
	 * @return Expression
	 * 
	 *         return the call expression
	 */
	public Expression getCallExp() {
		return callExp;
	}

	/**
	 * 
	 * @param callExp
	 *            the expression associated with the call
	 */
	public void setCallExp(Expression callExp) {
		this.callExp = callExp;
	}

	/**
	 * 
	 * @return list of expressions
	 */
	public ArrayList<Expression> getArguments() {
		return arguments;
	}

	/**
	 * 
	 * @param arguments
	 *            arguments sent along with function call
	 */
	public void setArguments(ArrayList<Expression> arguments) {
		this.arguments = arguments;
	}

	@Override
	public <T> T apply(TreeVisitor<T> visitor) {
		return visitor.visit(this);
	}

}
