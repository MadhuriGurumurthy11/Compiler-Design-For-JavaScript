package ts.tree.visit;

import ts.tree.*;
import ts.tree.type.*;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * Dump an AST to a stream. Uses prefix order with indentation.
 * <p>
 * Using Object for the type parameter but there is really no return type.
 * <p>
 * The "visit" method is overloaded for each tree node type.
 */
public final class Dump extends TreeVisitorBase<Object> {
	// where to write the dump to
	private PrintWriter writer;

	// current indentation amount
	private int indentation;

	// how much to increment the indentation by at each level
	// using an increment of zero would mean no indentation
	private int increment;

	/**
	 * Initiate the dump even to the left margin and set the increment
	 * indentation amount to two spaces.
	 *
	 * @param writer
	 *            where to write the dump to.
	 */
	public Dump(final PrintWriter writer) {
		this(writer, 0, 2);
	}

	/**
	 * Initiate the dump at a specific distance from the left margin and set the
	 * increment indentation amount to a specific value.
	 *
	 * @param writer
	 *            where to write the dump to.
	 * @param indentation
	 *            initial indentation amount.
	 * @param increment
	 *            increment indentation amount.
	 */
	public Dump(final PrintWriter writer, final int indentation,
			final int increment) {
		this.writer = writer;
		this.indentation = indentation;
		this.increment = increment;
	}

	// generate a string of spaces for current indentation level
	private void indent() {
		for (int i = 0; i < indentation; i++) {
			writer.print(" ");
		}
	}

	/**
	 * Visit a list of ASTs and dump them in order. Uses a wildcard for
	 * generality: list of Statements, list of Expressions, etc.
	 */
	@Override
	public List<Object> visitEach(final Iterable<?> nodes) {
		for (final Object node : nodes) {
			visitNode((Tree) node);
		}
		return null;
	}

	/** Dump a binary operator. */
	@Override
	public Object visit(final BinaryOperator binaryOperator) {
		indent();
		writer.println(binaryOperator.getOpString() + " ("
				+ binaryOperator.getType() + ") ");
		indentation += increment;
		visitNode(binaryOperator.getLeft());
		visitNode(binaryOperator.getRight());
		indentation -= increment;
		return null;
	}

	/** Dump a unary operator. */
	@Override
	public Object visit(final UnaryOperator unaryOperator) {
		indent();
		writer.println(unaryOperator.getOpString() + " ("
				+ unaryOperator.getType() + ") ");
		indentation += increment;
		visitNode(unaryOperator.getRight());
		indentation -= increment;
		return null;
	}

	/** Dump an expression statement. */
	@Override
	public Object visit(final ExpressionStatement expressionStatement) {
		indent();
		writer.println("ExpressionStatement");
		indentation += increment;
		visitNode(expressionStatement.getExp());
		indentation -= increment;
		return null;
	}

	/** Dump a function expression statement. */
	public Object visit(final FunctionExpression functionExpression) {
		indent();
		writer.println("FunctionExpression");
		indentation += increment;
		indent();
		writer.println("function");
		if (functionExpression.getFunctionIdentifier() != null) {
			writer.println(functionExpression.getFunctionIdentifier());
		}
		indent();
		writer.println("LPAREN");
		if (functionExpression.getFormalParameterList() != null) {
			for (String paramName : functionExpression.getFormalParameterList())
				writer.println(paramName);
		}
		indent();
		writer.println("RPAREN");
		indent();
		writer.println("LBRACE");
		if (functionExpression.getFunctionBody() != null) {
			for (int i = 0; i < functionExpression.getFunctionBody().size(); i++)
				visitNode(functionExpression.getFunctionBody().get(i));
		}
		indent();
		writer.println("RBRACE");
		return null;
	}

	/** Dump a function body statement. */
	public Object visit(final FunctionBody functionBody) {
		indent();
		writer.println("FunctionBody");
		indentation += increment;
		List<Statement> sourceElements = functionBody.getBody();
		if (sourceElements != null && sourceElements.size() > 0) {
			for (Statement stmt : sourceElements) {
				visitNode(stmt);
			}
		}
		indentation -= increment;
		indent();
		writer.println("FunctionBody End");
		return null;
	}

	/** Dump a call expression statement. */
	public Object visit(final CallExpression callExpression) {
		indent();
		writer.println("CallExpression");
		indentation += increment;
		if (callExpression.getCallExp() != null) {
			visitNode(callExpression.getCallExp());
		}
		indent();
		writer.println("LPAREN");
		if (callExpression.getArguments() != null) {
			for (Expression arg : callExpression.getArguments()) {
				indentation += increment;
				indent();
				writer.println("ExpressionStatement");
				visitNode(arg);
			}

		}
		indent();
		writer.println("RPAREN");
		return null;
	}

	/** Dump a block statement. */
	public Object visit(final BlockStatement blockStatement) {
		indent();
		writer.println("BlockStart");
		List<Statement> stmtList = blockStatement.getStatementList();
		if (stmtList != null && stmtList.size() > 0) {
			for (Statement stmt : stmtList) {
				visitNode(stmt);
			}
		}
		indentation -= increment;
		indent();
		writer.println("BlockEnd");
		indentation -= increment;
		return null;
	}

	/** Dump an empty statement. */
	public Object visit(final EmptyStatement emptyStatement) {
		indent();
		writer.println("EmptyStatement");
		return null;
	}

	/** Dump a while statement. */
	public Object visit(final WhileStatement whileStatement) {
		indent();
		writer.println("WhileStart");
		indentation += increment;
		indent();
		writer.println("ExpressionStatement");
		indentation += increment;
		visitNode(whileStatement.getExp());
		indentation -= increment;
		visitNode(whileStatement.getStmt());
		indentation -= increment;
		indentation -= increment;
		indentation -= increment;
		return null;
	}

	/** Dump a if-else statement. */
	public Object visit(final IfElseStatement ifElseStatement) {
		indent();
		writer.println("IfStatement");
		indentation += increment;
		indent();
		writer.println("ExpressionStatement");
		indentation += increment;
		visitNode(ifElseStatement.getExp());
		if (ifElseStatement.getElseStmt() != null) {
			writer.println("ElseStatement");
			indentation += increment;
			visitNode(ifElseStatement.getElseStmt());
			indentation -= increment;
		}
		indentation -= increment;
		indentation -= increment;
		return null;
	}

	/** Dump a break statement. */
	public Object visit(final BreakStatement breakStatement) {
		indent();
		if (breakStatement.getId() != null) {
			writer.println("BreakStatement " + breakStatement.getId());
		} else {
			writer.println("BreakStatement");
		}
		indentation += increment;
		return null;
	}

	/** Dump a continue statement. */
	public Object visit(final ContinueStatement continueStatement) {
		indent();
		if (continueStatement.getId() != null) {
			writer.println("ContinueStatement " + continueStatement.getId());
		} else {
			writer.println("ContinueStatement");
		}
		indentation += increment;
		return null;
	}

	/** Dump a throw statement. */
	public Object visit(final ThrowStatement throwStatement) {
		indent();
		writer.println("ThrowStatement");
		indentation += increment;
		indent();
		writer.println("ExpressionStatement");
		indentation += increment;
		visitNode(throwStatement.getExp());
		indentation -= increment;
		indentation -= increment;
		return null;
	}

	/** Dump a try statement. */
	public Object visit(final TryStatement tryStatement) {
		indent();
		writer.println("TryStatement");
		indentation += increment;
		indent();
		writer.println("ExpressionStatement");
		indentation += increment;
		visitNode(tryStatement.getBlockStmt());
		indentation += increment;
		if (tryStatement.getCatchStmt() != null) {
			writer.println("CatchStatement");
			indentation += increment;
			visitNode(tryStatement.getCatchStmt());
			indentation -= increment;
		}
		return null;
	}

	/** Dump a catch statement. */
	public Object visit(final CatchStatement catchStatement) {
		indent();
		writer.println("CatchStatement " + catchStatement.getCIdentifier());
		indentation += increment;
		visitNode(catchStatement.getBlockStmt());
		indentation -= increment;
		return null;
	}

	/** Dump a finally statement. */
	public Object visit(final FinallyStatement finallyStatement) {
		indent();
		writer.println("FinallyStatement");
		indentation += increment;
		visitNode(finallyStatement.getFinallyBlckStmt());
		indentation -= increment;
		return null;
	}

	/** Dump a return statement. */
	public Object visit(final ReturnStatement returnStatement) {
		indent();
		writer.println("ReturnStatement");
		indentation += increment;
		if (returnStatement.getExp() != null)
			visitNode(returnStatement.getExp());
		indentation -= increment;
		indentation -= increment;
		return null;
	}

	/** Dump an identifier. */
	@Override
	public Object visit(final Identifier identifier) {
		// get the Type from the declaration tree node (if not null)
		VarStatement node = identifier.getVarNode();
		String typeString = null;
		if (node == null) {
			typeString = "<var is null>";
		} else {
			Type type = node.getType();
			if (type == null) {
				typeString = "<type is null>";
			} else {
				typeString = type.toString();
			}
		}

		// is it a lval or a rval?
		String valKind = null;
		if (identifier.isLval()) {
			valKind = "lval";
		} else {
			valKind = "rval";
		}

		// also a "local" type in the identifier node itself
		String locTypeString = null;
		Type locType = identifier.getType();
		if (locType == null) {
			locTypeString = "<null>";
		} else {
			locTypeString = locType.toString();
		}

		indent();
		writer.println("Identifier (" + typeString + " " + valKind + ") "
				+ identifier.getName() + " " + locTypeString);
		return null;
	}

	/** Dump a object Literal. */
	public Object visit(final ObjectLiteral objectLiteral) {
		indent();
		writer.println("ObjectLiteral");
		indentation += increment;
		indent();
		indentation += increment;
		ArrayList<PropertyPair> propList = objectLiteral
				.getPropertyNameAndValueList();
		if (propList != null) {
			indentation += increment;
			for (PropertyPair p : propList) {
				writer.println("PropertPair");
				indentation += increment;
				visitNode(p);
				indentation -= increment;
			}
		}
		return null;
	}

	/** Dump a Property Pair. */
	public Object visit(final PropertyPair property) {
		indent();
		writer.println("PropertyPair :" + property.getPropertyName());
		visitNode(property.getPropertyValue());
		indent();
		return null;
	}

	/** Dump a PropertyAccessorExpression. */
	public Object visit(PropertyAccessorExpression accessorExpression) {
		indent();
		writer.println("PropertyAccessorExpression");
		visitNode(accessorExpression.getMemberExpr());
		indent();
		if (accessorExpression.getId() != null) {
			writer.println("DOT");
			indent();
			writer.println("Identifier " + accessorExpression.getId());
		} else if (accessorExpression.getExp() != null) {
			writer.println("LSQUAREBRACE");
			indent();
			writer.println("Expression");
			visitNode(accessorExpression.getExp());
			indent();
			writer.println("RSQUAREBRACE");
			indent();
		}
		return null;
	}

	/** Dump a NewExpression. */
	public Object visit(NewExpression newExpression) {
		indent();
		writer.println("NewExpression");
		visitNode(newExpression.getMemberExp());
		if (newExpression.getArguments() != null) {
			for (Expression arg : newExpression.getArguments()) {
				indentation += increment;
				indent();
				writer.println("ExpressionStatement");
				visitNode(arg);
			}

		}
		return null;
	}

	/** Dump a numeric literal. */
	@Override
	public Object visit(final NumericLiteral numericLiteral) {
		indent();
		writer.println("NumericLiteral (" + numericLiteral.getType() + ") "
				+ numericLiteral.getValue());
		return null;
	}

	/** Dump a boolean literal. */
	@Override
	public Object visit(final BooleanLiteral booleanLiteral) {
		indent();
		writer.println("BooleanLiteral (" + booleanLiteral.getType() + ") "
				+ booleanLiteral.getValue());
		return null;
	}

	/** Dump a null literal. */
	@Override
	public Object visit(final NullLiteral nullLiteral) {
		indent();
		writer.println("NullLiteral (" + nullLiteral.getType() + ") " + null);
		return null;
	}

	/** Dump a print statement. */
	@Override
	public Object visit(final PrintStatement printStatement) {
		indent();
		writer.println("PrintStatement");
		indentation += increment;
		visitNode(printStatement.getExp());
		indentation -= increment;
		return null;
	}

	/** Dump a program. */
	@Override
	public Object visit(final Program program) {
		indent();
		writer.println("Program");
		indentation += increment;
		visitEach(program.getList());
		indentation -= increment;
		return null;
	}

	/** Dump a string literal. */
	@Override
	public Object visit(final StringLiteral stringLiteral) {
		indent();
		writer.println("StringLiteral (" + stringLiteral.getType() + ") "
				+ stringLiteral.getValue());
		return null;
	}

	/** Dump a var statement. */
	@Override
	public Object visit(final VarStatement varStatement) {
		Type type = varStatement.getType();
		String typeStr = null;
		if (type == null) {
			typeStr = "<null>";
		} else {
			typeStr = type.toString();
		}
		String capturedStr = null;
		if (varStatement.isCaptured()) {
			capturedStr = "captured";
		} else {
			capturedStr = "not-captured";
		}
		String redundantStr = null;
		if (varStatement.isCaptured()) {
			redundantStr = "redundant";
		} else {
			redundantStr = "not-redundant";
		}
		indent();
		writer.println("Var (" + typeStr + " "
				+ varStatement.getFunctionDepth() + " "
				+ varStatement.getTempName() + " " + capturedStr + " "
				+ redundantStr + ") " + varStatement.getName());
		return null;
	}

}
