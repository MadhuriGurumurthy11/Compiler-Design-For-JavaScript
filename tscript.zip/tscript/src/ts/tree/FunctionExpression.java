package ts.tree;

import java.util.ArrayList;
import java.util.List;

import ts.Location;
import ts.tree.visit.TreeVisitor;

/**
 * @author Madhuri Gurumurthy
 * 
 *         AST function expression node
 * 
 */
public class FunctionExpression extends Expression {

	private String functionIdentifier;
	/** A List holding the parameters list for the function */
	private ArrayList<String> formalParameterList = new ArrayList<String>();
	/** statement representing function body */
	private ArrayList<Statement> functionBody = new ArrayList<Statement>();

	private List<VarStatement> functionVars = null;

	/**
	 * @param loc
	 *            source code location of Try Statement
	 * @param functionIdentifier
	 *            the function identifier
	 * @param formalParameterList
	 *            the arguments list sent with the function
	 * @param functionBody
	 *            the body of the function
	 */
	public FunctionExpression(Location loc, String functionIdentifier,
			ArrayList<String> formalParameterList,
			ArrayList<Statement> functionBody) {
		super(loc);
		this.functionIdentifier = functionIdentifier;
		if (formalParameterList != null)
			this.formalParameterList = formalParameterList;
		this.functionBody = functionBody;
	}

	/**
	 * @param functionIdentifier
	 *            the functionIdentifier to set
	 */
	public void setFunctionIdentifier(String functionIdentifier) {
		this.functionIdentifier = functionIdentifier;
	}

	/**
	 * 
	 * @return Function Identifier
	 */
	public String getFunctionIdentifier() {
		return functionIdentifier;
	}

	/**
	 * 
	 * @return FUntiona parameters.
	 */
	public ArrayList<String> getFormalParameterList() {
		return formalParameterList;
	}

	/**
	 * 
	 * @param formalParameterList
	 * 
	 *            Set the function parameter list
	 */
	public void setFormalParameterList(ArrayList<String> formalParameterList) {
		this.formalParameterList = formalParameterList;
	}

	/**
	 * @return the functionBody
	 */
	public ArrayList<Statement> getFunctionBody() {
		return functionBody;
	}

	/**
	 * @param functionBody
	 *            the functionBody to set
	 */
	public void setFunctionBody(ArrayList<Statement> functionBody) {
		this.functionBody = functionBody;
	}

	/**
	 * @return the functionVars
	 * 
	 *         the var associated with the function
	 */
	public List<VarStatement> getFunctionVars() {
		return functionVars;
	}

	/**
	 * @param functionvars
	 *            the functionVars to set
	 */
	public void setFunctionVars(List<VarStatement> functionvars) {
		if (functionVars == null) {

			this.functionVars = functionvars;
		}
	}

	@Override
	public <T> T apply(TreeVisitor<T> visitor) {
		return visitor.visit(this);
	}

}
