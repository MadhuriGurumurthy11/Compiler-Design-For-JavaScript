package ts.tree;

/**
 * enum for unary operator names
 *
 */
public enum Unop {
	LOGICALNOT, UNARYMINUS
}
