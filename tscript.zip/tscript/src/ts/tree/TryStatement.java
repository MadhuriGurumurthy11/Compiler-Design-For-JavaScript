package ts.tree;

import ts.Location;
import ts.tree.visit.TreeVisitor;

/**
 * @author Madhuri Gurumurthy
 * 
 *         AST Try statement node
 * 
 */
public class TryStatement extends Statement {

	/** statements representing try block, catch and finally */
	Statement blockStmt, catchStmt, finallyStmt;

	/**
	 * 
	 * @param loc
	 *            source code location of Try Statement
	 * @param blockStmt
	 *            block statement of the try block
	 * @param catchStmt
	 *            block statement of the catch block
	 * @param finallyStmt
	 *            block statement of the finally block
	 */
	public TryStatement(Location loc, Statement blockStmt, Statement catchStmt,
			Statement finallyStmt) {
		super(loc);
		this.blockStmt = blockStmt;
		this.catchStmt = catchStmt;
		this.finallyStmt = finallyStmt;
	}

	public Statement getBlockStmt() {
		return blockStmt;
	}

	public void setBlockStmt(Statement blockStmt) {
		this.blockStmt = blockStmt;
	}

	public Statement getCatchStmt() {
		return catchStmt;
	}

	public void setCatchStmt(Statement catchStmt) {
		this.catchStmt = catchStmt;
	}

	public Statement getFinallyStmt() {
		return finallyStmt;
	}

	public void setFinallyStmt(Statement finallyStmt) {
		this.finallyStmt = finallyStmt;
	}

	@Override
	public <T> T apply(TreeVisitor<T> visitor) {
		return visitor.visit(this);
	}

}
