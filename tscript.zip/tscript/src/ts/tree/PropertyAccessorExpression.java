package ts.tree;

import ts.Location;
import ts.tree.visit.TreeVisitor;

/**
 * @author Madhuri Gurumurthy
 * 
 *         Represents a member expression for property accessors (<a
 *         href="http://www.ecma-international.org/ecma-262/5.1/#sec-11.1.5">ELS
 *         11.1.5</a>).
 */
public class PropertyAccessorExpression extends Expression {

	Expression memberExpr;
	String id;
	Expression exp;

	public PropertyAccessorExpression(Location loc, Expression memberExpr,
			String id, Expression exp) {
		super(loc);
		this.memberExpr = memberExpr;
		this.id = id;
		this.exp = exp;
	}

	public Expression getMemberExpr() {
		return memberExpr;
	}

	public void setMemberExpr(Expression memberExpr) {
		this.memberExpr = memberExpr;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the exp
	 */
	public Expression getExp() {
		return exp;
	}

	/**
	 * @param exp
	 *            the exp to set
	 */
	public void setExp(Expression exp) {
		this.exp = exp;
	}

	@Override
	public <T> T apply(TreeVisitor<T> visitor) {
		return visitor.visit(this);
	}

}
