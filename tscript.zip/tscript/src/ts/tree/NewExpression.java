package ts.tree;

import java.util.ArrayList;
import java.util.List;

import ts.Location;
import ts.tree.visit.TreeVisitor;

/**
 * @author Madhuri Gurumurthy
 * 
 *         AST new expression node
 */
public class NewExpression extends Expression {

	Expression memberExp;

	List<Expression> args = new ArrayList<Expression>();

	public NewExpression(Location loc, Expression memberExp,
			List<Expression> args) {
		super(loc);
		this.memberExp = memberExp;
		if (args != null)
			this.args = args;
	}

	public Expression getMemberExp() {
		return memberExp;
	}

	public void setMemberExp(Expression memberExp) {
		this.memberExp = memberExp;
	}

	public List<Expression> getArguments() {
		return args;
	}

	public void setArguments(List<Expression> args) {
		this.args = args;
	}

	@Override
	public <T> T apply(TreeVisitor<T> visitor) {
		return visitor.visit(this);
	}

}
