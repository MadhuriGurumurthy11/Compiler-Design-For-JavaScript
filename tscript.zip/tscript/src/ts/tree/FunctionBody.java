package ts.tree;

import java.util.ArrayList;
import java.util.List;

import ts.Location;
import ts.tree.visit.TreeVisitor;

/**
 * @author Madhuri Gurumurthy
 * 
 *         AST function body node
 * 
 */
public class FunctionBody extends Statement {

	ArrayList<Statement> body;

	/**
	 * 
	 * @param loc
	 *            source code location of Try Statement
	 * @param body
	 *            The function body
	 */
	public FunctionBody(Location loc, ArrayList<Statement> body) {
		super(loc);
		this.body = body;

	}

	/**
	 * 
	 * @return List
	 * 
	 *         the statements in the function body
	 */
	public ArrayList<Statement> getBody() {
		return body;
	}

	/**
	 * 
	 * @param body
	 * 
	 *            Set the list of statements in the function body
	 */
	public void setBody(ArrayList<Statement> body) {
		this.body = body;
	}

	@Override
	public <T> T apply(TreeVisitor<T> visitor) {
		return visitor.visit(this);
	}

}
