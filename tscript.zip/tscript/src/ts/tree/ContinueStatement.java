/**
 * 
 */
package ts.tree;

import ts.Location;
import ts.tree.visit.TreeVisitor;

/**
 * @author Madhuri Gurumurthy
 *
 *         AST continue node
 */
public class ContinueStatement extends Statement {

	private String id;

	public ContinueStatement(Location loc, String id) {
		super(loc);
		this.id = id;
	}

	/**
	 * @return the id
	 * 
	 *         Return the Identifier string
	 */
	public String getId() {
		return id;
	}

	@Override
	public <T> T apply(TreeVisitor<T> visitor) {
		return visitor.visit(this);
	}

}
