/**
 * 
 */
package ts.support;

import ts.tree.VarStatement;

/**
 * @author Madhuri Gurumurthy
 *
 */
public class TSEnvironment {

	private TSEnvironment outer;
	private TSValue[] vars;

	/**
	 * @param outer
	 *            reference to the outer environment
	 * @param vars
	 *            list of captured variables
	 */
	public TSEnvironment(TSEnvironment outer, TSValue[] vars) {
		super();
		this.outer = outer;
		this.vars = vars;
	}

	/**
	 * @return the outer
	 */
	public TSEnvironment getOuter() {
		return outer;
	}

	/**
	 * @param outer
	 *            the outer to set
	 */
	public void setOuter(TSEnvironment outer) {
		this.outer = outer;
	}

	/**
	 * @return the vars
	 */
	public TSValue[] getVars() {
		return vars;
	}

	/**
	 * @param vars
	 *            the vars to set
	 */
	public void setVars(TSValue[] vars) {
		this.vars = vars;
	}

	/**
	 * Create a new environment.
	 *
	 * @param outer
	 *            the enclosing environment
	 * @return TSEnvironment
	 */
	public static TSEnvironment createNewEnvironment(final TSEnvironment outer) {
		return new TSEnvironment(outer, null);

	}

}
