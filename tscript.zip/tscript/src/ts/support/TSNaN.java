package ts.support;

/**
 * @author Madhuri Gurumurthy
 * 
 *         Represent a non standard built-in function to read NaN
 */
public class TSNaN implements TSCode {

	public static TSNaN instance = new TSNaN();

	@Override
	public TSValue execute(boolean isConstructorCall, TSValue ths,
			TSValue[] arguments, TSEnvironment env) {
		TSBoolean isFinite = TSBoolean.trueValue;
		if (arguments != null && arguments.length > 0) {
			String num = arguments[0].toStr().getInternal();
			double number = Double.parseDouble(num);
			if (Double.isNaN(number)) {
				return isFinite;
			}
			isFinite = TSBoolean.falseValue;
		}
		return isFinite;
	}
}
