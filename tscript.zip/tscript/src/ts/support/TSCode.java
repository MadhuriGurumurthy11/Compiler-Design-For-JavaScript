/**
 * 
 */
package ts.support;

/**
 * @author Madhuri Gurumurthy
 *
 *
 *         Supporting interface for Function expression
 */
public interface TSCode {

	TSValue execute(boolean isConstructorCall, TSValue ths, TSValue args[],
			TSEnvironment env);
}
