package ts.support;

/**
 * @author Madhuri Gurumurthy
 * 
 *         Represent a non standard built-in function to read finite
 */
public class TSFinite implements TSCode {

	public static TSFinite instance = new TSFinite();

	@Override
	public TSValue execute(boolean isConstructorCall, TSValue ths,
			TSValue[] arguments, TSEnvironment env) {

		TSBoolean isFinite = TSBoolean.falseValue;
		if (arguments != null && arguments.length > 0) {
			String arg = arguments[0].toStr().getInternal();
			// // TODO:
			// System.out.println( isFinite.getInternal( ).booleanValue( ) );
			double number = Double.parseDouble(arg);
			if (Double.isInfinite(number) || Double.isNaN(number)) {
				isFinite = TSBoolean.falseValue;
			} else {
				isFinite = TSBoolean.trueValue;
			}
		}
		// // // TODO:
		// System.out.println( isFinite.getInternal( ).booleanValue( ) );
		return isFinite;
	}
}
