package ts.support;

/**
 * Represent Boolean values (
 * <a href="http://www.ecma-international.org/ecma-262/5.1/#sec-8.3"></a>).
 */
public final class TSBoolean extends TSPrimitive {
	/** pre-built value for false */
	public static final TSBoolean falseValue = new TSBoolean(false);
	/** pre-built value for true */
	public static final TSBoolean trueValue = new TSBoolean(true);

	// // use the "create" method instead
	private TSBoolean(final boolean value) {
		this.value = value;
	}

	private final boolean value;

	/**
	 * Create a boolean with the given value.
	 *
	 * @param value
	 *            the Java boolean to be encapsulated by the TSBoolean
	 * @return the new TSBoolean
	 */
	public static TSBoolean create(final boolean value) {
		// could screen for more common values?
		// even use a hashmap?
		if (value == false) {
			return falseValue;
		} else if (value == true) {
			return trueValue;
		}
		return new TSBoolean(value);
	}

	/**
	 * Get the value.
	 *
	 * @return the Java boolean from the TSBoolean
	 */
	public boolean getInternal() {
		return value;
	}

	/** The result equals the input argument */
	public TSBoolean toBoolean() {
		return this;
	}

	//
	// /**
	// * The result is false if the argument is +0, −0, or NaN; otherwise the
	// * result is true.
	// */
	// public TSNumber toNumber() {
	// if ((this.getInternal(). == +0.0) || (val.doubleValue() == -0.0)
	// || (val.doubleValue() == Double.NaN)) {
	// return TSBoolean.create(false);
	// } else
	// return TSBoolean.create(true);
	// }

	/**
	 * The result is false if the argument is +0, −0, or NaN; otherwise the
	 * result is true.
	 */
	@Override
	public TSNumber toNumber() {
		if (this.value == false) {
			return TSNumber.create(0);
		} else {
			return TSNumber.create(1);
		}
	}

	/**
	 * The result is false if the argument is +0, −0, or NaN; otherwise the
	 * result is true.
	 */
	public TSString toStr() {
		if (this.value == false) {
			return TSString.create("false");
		} else
			return TSString.create("true");
	}

	/** Convert to Primitive . */
	public TSPrimitive toPrimitive() {
		return this;
	}

}
