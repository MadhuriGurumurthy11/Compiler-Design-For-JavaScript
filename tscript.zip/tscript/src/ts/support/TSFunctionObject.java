package ts.support;

/**
 * A class to support function objects
 * 
 * @author Madhuri Gurumurthy
 *
 */
public class TSFunctionObject extends TSObject {
	private TSEnvironment scope;
	private TSCode tsCode;

	/**
	 * Constructor
	 * 
	 * @param tsCode
	 *            the reference for TSCode
	 * @param envi
	 *            refernce for the outer environment
	 */
	public TSFunctionObject(final TSCode tsCode, final TSEnvironment envi) {
		this.scope = envi;
		this.tsCode = tsCode;
	}

	/**
	 * @return the scope
	 */
	public TSEnvironment getScope() {
		return scope;
	}

	/**
	 * @param scope
	 *            the scope to set
	 */
	public void setScope(TSEnvironment scope) {
		this.scope = scope;
	}

	/**
	 * toStr
	 */
	public TSString toStr() {
		return TSString.create("");
	}

	/**
	 * callFunction
	 * 
	 * @param isConstructorCall
	 *            boolean flag indicating whether it is a constructor call or
	 *            not.
	 * @param ths
	 *            reference to TSValue.
	 * @param arguments
	 *            arguments array.
	 * 
	 * @return TSValue
	 */
	public TSValue callFunction(boolean isConstructorCall, TSValue ths,
			TSValue arguments[]) {

		if (ths == null) {
			ths = TSObject.getGlobalObject();
		}
		return this.tsCode.execute(false, ths, arguments, scope);

	}

	/**
	 * 
	 * @param isConstructorCall
	 *            A boolean flag to tell if it's a constructor call
	 * @param ths
	 *            value of this
	 * @param arguments
	 *            TSValue args
	 * @return TSValue
	 */
	public TSValue callConstructor(boolean isConstructorCall, TSValue ths,
			TSValue[] arguments) {

		if (propertyMap.containsKey("prototype")
				&& propertyMap.get("prototype") instanceof TSObject) {
			TSObject newObj = new TSObject(
					(TSObject) propertyMap.get("prototype"));
			TSValue val = callFunction(true, newObj, arguments);
			if (val instanceof TSObject) {
				return val;
			}
			return newObj;
		} else {
			TSObject newObj = new TSObject();
			TSValue val = callFunction(true, newObj, arguments);
			if (val instanceof TSObject) {
				return val;
			}
			return newObj;
		}
	}

	/**
	 * Create a Number with the given value.
	 *
	 * @param code
	 *            the TSCode reference
	 * @param env
	 *            The TSEnvironment reference
	 * @return the new TSNumber
	 */
	public static TSValue create(TSCode code, TSEnvironment env) {
		return new TSFunctionObject(code, env);
	}

}