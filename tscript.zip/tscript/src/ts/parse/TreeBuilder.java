package ts.parse;

import ts.Location;
import ts.Message;
import ts.tree.*;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

/**
 * Provides static methods for building AST nodes.
 */
public class TreeBuilder {

	/**
	 * Build a binary operator.
	 *
	 * @param loc
	 *            location in source code (file, line, column).
	 * @param op
	 *            the binary operator.
	 * @param left
	 *            the left subtree.
	 * @param right
	 *            the right subtree.
	 * @return tree node for a binary operator.
	 * @see Binop
	 */
	public static Expression buildBinaryOperator(final Location loc,
			final Binop op, final Expression left, final Expression right) {
		Message.log("TreeBuilder: Binop " + op.toString());

		return new BinaryOperator(loc, op, left, right);
	}

	/**
	 * Build a unary operator.
	 *
	 * @param loc
	 *            location in source code (file, line, column).
	 * @param op
	 *            the unary operator.
	 * @param right
	 *            the right subtree.
	 * @return tree node for a unary operator.
	 * @see Unop
	 */
	public static Expression buildUnaryOperator(final Location loc,
			final Unop op, final Expression right) {
		Message.log("TreeBuilder: Unop " + op.toString());

		return new UnaryOperator(loc, op, right);
	}

	/**
	 * Build an expression statement.
	 *
	 * @param loc
	 *            location in source code (file, line, column).
	 * @param exp
	 *            expression subtree.
	 * @return tree node for an expression statement.
	 */
	public static Statement buildExpressionStatement(final Location loc,
			final Expression exp) {
		Message.log("TreeBuilder: ExpressionStatement");
		return new ExpressionStatement(loc, exp);
	}

	/**
	 * Build an identifier expression.
	 *
	 * @param loc
	 *            location in source code (file, line, column).
	 * @param name
	 *            name of the identifier.
	 * @return tree node for an identififier.
	 */
	public static Expression buildIdentifier(final Location loc,
			final String name) {
		Message.log("TreeBuilder: Identifier (" + name + ")");
		return new Identifier(loc, name);
	}

	/**
	 * Build a numeric literal expression. Converts the String for the value to
	 * a double.
	 *
	 * @param loc
	 *            location in source code (file, line, column).
	 * @param value
	 *            value of the literal as a String.
	 * @return tree node for a numeric literal.
	 */
	public static Expression buildNumericLiteral(final Location loc,
			final String value) {
		double d = 0.0;

		try {
			// d = Double.parseDouble(value);

			// look for hex constants first
			if (value.startsWith("0x") || value.startsWith("0X")) {
				d = new BigInteger(value.substring(2), 16).doubleValue();
			} else {
				try {
					d = Double.valueOf(value);
				} catch (NumberFormatException ex) {
					d = Double.NaN;
				}
			}
		} catch (NumberFormatException nfe) {
			Message.bug(loc, "numeric literal not parsable");
		}
		Message.log("TreeBuilder: NumericLiteral " + d);
		return new NumericLiteral(loc, d);
	}

	// ------------------------------------------------------------------------------------

	/**
	 * Build a boolean literal expression.
	 *
	 * @param loc
	 *            location in source code (file, line, column).
	 * @param value
	 *            value of the literal as a boolean.
	 * @return tree node for a boolean literal.
	 */
	public static Expression buildBooleanLiteral(final Location loc,
			final String value) {
		boolean val;
		if (value.equals("false")) {
			val = false;
		} else {
			val = true;
		}

		Message.log("TreeBuilder: BooleanLiteral " + val);
		return new BooleanLiteral(loc, val);
	}

	/**
	 * Build a null literal expression.
	 *
	 * @param loc
	 *            location in source code (file, line, column).
	 * @return tree node for a null literal.
	 */
	public static Expression buildNullLiteral(final Location loc) {
		Message.log("TreeBuilder: NullLiteral ");
		return new NullLiteral(loc);
	}

	// ------------------------------------------------------------------------------------
	/**
	 * Build a print statement.
	 *
	 * @param loc
	 *            location in source code (file, line, column).
	 * @param exp
	 *            expression subtree.
	 * @return tree node for a print statement.
	 */
	public static Statement buildPrintStatement(final Location loc,
			final Expression exp) {
		Message.log("TreeBuilder: PrintStatement");
		return new PrintStatement(loc, exp);
	}

	/**
	 * Build a block statement.
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param stmtList
	 *            List of statements in the block, which can be executed.
	 * @return tree node for a print statement.
	 */
	public static Statement buildBlockStatement(final Location loc,
			final List<Statement> stmtList) {
		Message.log("TreeBuilder: BlockStatement");
		return new BlockStatement(loc, stmtList);
	}

	/**
	 * Build an empty statement.
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @return tree node for a print statement.
	 */
	public static Statement buildEmptyStatement(final Location loc) {
		Message.log("TreeBuilder: EmptyStatement");
		return new EmptyStatement(loc);
	}

	/**
	 * Build a while statement.
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param stmt
	 *            Statement in the while block, which can be executed.
	 * @param exp
	 *            Expression associated with the while statement
	 * @return tree node for a print statement.
	 */
	public static Statement buildWhileStatement(final Location loc,
			Expression exp, final Statement stmt) {
		Message.log("TreeBuilder: WhileStatement " + stmt);
		return new WhileStatement(loc, exp, stmt);
	}

	/**
	 * Build an if-else statement.
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param exp
	 *            Expression associated with the if statement
	 * @param stmt1
	 *            Statement in the if block, which can be executed.
	 * @param stmt2
	 *            Statement in the else block, which can be executed.
	 * @return tree node for a print statement.
	 */
	public static Statement buildIfElseStatement(final Location loc,
			Expression exp, final Statement stmt1, final Statement stmt2) {
		Message.log("TreeBuilder: IfElseStatement");
		return new IfElseStatement(loc, exp, stmt1, stmt2);
	}

	/**
	 * Build an break statement.
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param id
	 *            the identifier associated with the break statement.
	 * @return tree node for a print statement.
	 */
	public static Statement buildBreakStatement(final Location loc, String id) {
		Message.log("TreeBuilder: BreakStatement");
		return new BreakStatement(loc, id);
	}

	/**
	 * Build an continue statement.
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param id
	 *            the identifier associated with the continue statement.
	 * @return tree node for a print statement.
	 */
	public static Statement buildContinueStatement(final Location loc, String id) {
		Message.log("TreeBuilder: ContinueStatement");
		return new ContinueStatement(loc, id);
	}

	/**
	 * Build an throw statement.
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param exp
	 *            the expression associated with the throw statement.
	 * @return tree node for a print statement.
	 */
	public static Statement buildThrowStatement(final Location loc,
			Expression exp) {
		Message.log("TreeBuilder: ThrowStatement");
		return new ThrowStatement(loc, exp);
	}

	// buildTryStatement(loc($start),$blk1.lval,$ct.lval,$fin.lval);}

	/**
	 * Build a try statement.
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param block
	 *            block of code to be executed in try
	 * @param catchStmt
	 *            Statements in catch
	 * @param finallyStatement
	 *            Statements in finally
	 * @return tree node for a try statement.
	 */
	public static Statement buildTryStatement(final Location loc,
			final Statement block, final Statement catchStmt,
			final Statement finallyStatement) {
		Message.log("TreeBuilder: Try");
		return new TryStatement(loc, block, catchStmt, finallyStatement);
	}

	// buildCatchStatement(loc($start),$IDENTIFIER.text,$blk.lval);
	/**
	 * Build a catch statement.
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param cIdentifier
	 *            Identifier of the catch
	 * @param block
	 *            block of code to be executed
	 * @return tree node for a catch statement.
	 */
	public static Statement buildCatchStatement(final Location loc,
			final String cIdentifier, Statement block) {
		Message.log("TreeBuilder: Catch");
		return new CatchStatement(loc, block, cIdentifier);
	}

	// buildFinallyStatement(loc($start),$blk.lval);

	/**
	 * Build a finally statement.
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param block
	 *            block of code to be executed
	 * @return tree node for a finally statement.
	 */
	public static Statement buildFinallyStatement(final Location loc,
			Statement block) {
		Message.log("TreeBuilder: Finally");
		return new FinallyStatement(loc, block);
	}

	/**
	 * Build return Statement
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param exp
	 *            the expression associated with the return.
	 * @return tree node for a finally statement.
	 */
	public static Statement buildReturnStatement(Location loc, Expression exp) {
		Message.log("TreeBuilder: Return Statment " + exp);
		return new ReturnStatement(loc, exp);
	}

	// --------------------------------------------------------------------------------------------------
	/**
	 * Build Function Expression
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param fParameters
	 *            the function arguments
	 * @param fBody
	 *            the function body
	 * @param fIdentifier
	 *            the function identifier
	 * @return tree node for a Function expression.
	 */
	public static Expression buildFunctionExpression(Location loc,
			String fIdentifier, ArrayList<String> fParameters,
			ArrayList<Statement> fBody) {
		Message.log("TreeBuilder: Function Expression");
		return new FunctionExpression(loc, fIdentifier, fParameters, fBody);
	}

	/**
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param memberExpression
	 *            the member expression
	 * @param callArgs
	 *            the function call arguments
	 * @return tree node for a Call expression.
	 */
	public static Expression buildCallExpression(Location loc,
			Expression memberExpression, ArrayList<Expression> callArgs) {
		Message.log("TreeBuilder: Call Expression");
		return new CallExpression(loc, memberExpression, callArgs);
	}

	/**
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param body
	 *            the function body
	 * @return tree node for a Function body.
	 */
	public static Statement buildFunctionBody(Location loc,
			ArrayList<Statement> body) {
		Message.log("TreeBuilder: Function Body");
		return new FunctionBody(loc, body);
	}

	// ---------------------------------------------------------------------------------------------------

	// ------------------Phase 3------------------

	/**
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param propertyNameAndValueList
	 *            the property name, value pair
	 * @return tree node for a ObjectLiteral
	 */
	public static Expression buildObjectLiteral(Location loc,
			ArrayList<PropertyPair> propertyNameAndValueList) {
		Message.log("TreeBuilder: Object Literal ");
		return new ObjectLiteral(loc, propertyNameAndValueList);
	}

	/**
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param propertyName
	 *            Name of the property
	 * @param propertyValue
	 *            Value of the property
	 * @return tree node for a PropertyAssignment.
	 */
	public static PropertyPair buildPropertyAssignment(Location loc,
			String propertyName, Expression propertyValue) {
		Message.log("TreeBuilder: Object Literal ");
		return new PropertyPair(loc, propertyName, propertyValue);
	}

	/**
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param memExp
	 *            the member expression associated with the Property Accessor
	 * @param id
	 *            The Identifier
	 * @param exp
	 *            The sub- expression
	 * @return Expression
	 */
	public static Expression buildPropertyAccesorExpression(Location loc,
			Expression memExp, String id, Expression exp) {
		return new PropertyAccessorExpression(loc, memExp, id, exp);
	}

	/**
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param exp
	 *            the expression associated with the new Expression
	 * @param args
	 *            List of Expression associated with the new Expression
	 * @return Expression
	 */
	public static Expression buildNewExpression(Location loc, Expression exp,
			List<Expression> args) {
		return new NewExpression(loc, exp, args);
	}

	/**
	 * 
	 * @param loc
	 *            location in source code (file, line, column)
	 * @param thisValue
	 *            this parameter
	 * @return Expression
	 */
	public static Expression buildThisLiteral(final Location loc,
			final String thisValue) {
		Message.log("TreeBuilder: This " + thisValue);

		return new ThisLiteral(loc, thisValue);
	}

	// -------------------------------------------------------------------------------------------------
	/**
	 * Build the root node of the AST.
	 *
	 * @param loc
	 *            location in source code (file, line, column).
	 * @param list
	 *            list of statements for the program.
	 * @return tree node for the root of the AST.
	 */
	public static Program buildProgram(final Location loc,
			final List<Statement> list) {
		Message.log("TreeBuilder: Program");
		return new Program(loc, list);
	}

	/**
	 * Build a string literal expression.
	 *
	 * @param loc
	 *            location in source code (file, line, column).
	 * @param value
	 *            value of the literal as a String.
	 * @return tree node for a numeric literal.
	 */
	public static Expression buildStringLiteral(final Location loc,
			final String value) {
		// need to strip off the doublequotes

		String strVal = value.substring(1, value.length() - 1);
		Message.log("TreeBuilder: StringLiteral " + strVal);
		return new StringLiteral(loc, strVal);
	}

	/**
	 * Build a "var" statement.
	 *
	 * @param loc
	 *            location in source code (file, line, column).
	 * @param name
	 *            name of variable being declared.
	 * @return tree node for a var statement.
	 */
	public static Statement buildVarStatement(final Location loc,
			final String name) {
		Message.log("TreeBuilder: VarStatement (" + name + ")");
		return new VarStatement(loc, name);
	}

	//
	// methods to detect "early" (i.e. semantic) errors
	//

	// helper function to detect "reference expected" errors and to
	// mark nodes that denote references as Lvals
	private static boolean producesReference(Node node) {
		if (node instanceof Identifier) {
			Identifier id = (Identifier) node;
			id.setIsLval();
			return true;
		} else if (node instanceof PropertyAccessorExpression) {
			return true;
		}
		return false;
	}

	/**
	 * Used to detect non-references on left-hand-side of assignment and also to
	 * mark identifier nodes as denoting Lvals (location rather than value).
	 *
	 * @param loc
	 *            location in source code (file, line, column).
	 * @param node
	 *            tree to be checked.
	 */
	public static void checkAssignmentDestination(Location loc, Node node) {
		if (!producesReference(node)) {
			Message.error(loc, "invalid left-hand side in assignment");
		}
	}

}
