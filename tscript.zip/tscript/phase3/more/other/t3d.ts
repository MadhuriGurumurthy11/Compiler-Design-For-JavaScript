x = 20;
y = 22;
console.log(x+y);


