F = {};

x = new F();
x.f = testThis;
x.f();
console.log(x.xyz);

