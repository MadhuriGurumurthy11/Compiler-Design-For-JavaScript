
var i;

i = {a : 42};

console.log(i["a"]);

