x = 20;
console.log(x+y);  // read of undeclared ID is an error


