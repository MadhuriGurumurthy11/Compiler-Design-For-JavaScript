
var x;

x = readln();

console.log(x);

