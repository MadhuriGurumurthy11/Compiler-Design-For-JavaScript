
var i;

i = {};
i.a = i;
i.b = 42;

console.log(i["a"]["a"]["a"]["a"]["a"]["a"]["a"]["a"]["a"]["b"]);

