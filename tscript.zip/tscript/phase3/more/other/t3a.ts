console.log(NaN);

