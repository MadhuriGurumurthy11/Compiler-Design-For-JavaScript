// Node reports "undefined ID"
// Firefox prints 42, as I would expect

this.x = 42;

console.log(x);

