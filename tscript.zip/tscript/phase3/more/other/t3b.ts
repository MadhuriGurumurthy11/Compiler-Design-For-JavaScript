console.log(Infinity);

