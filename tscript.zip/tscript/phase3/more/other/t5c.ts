F = {};

x = new testThis();
x.printXYZ();


