this.x = 42;

console.log(x);

