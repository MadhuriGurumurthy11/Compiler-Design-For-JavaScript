var F;

F = {};

var i;

i = new F();

