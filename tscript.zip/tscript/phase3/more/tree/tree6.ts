var f;

f = function() {this.c = this.a + this.b; };

