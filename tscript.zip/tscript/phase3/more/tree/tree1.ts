var i;

i = {};

i = {a : 42};
console.log (i.a);

i = {a : 42, b : 1066};
console.log(i["a"] + i["b"]);

