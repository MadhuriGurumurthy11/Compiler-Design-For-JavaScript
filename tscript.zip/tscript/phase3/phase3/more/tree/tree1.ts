var i;

i = {};

i = {a : 42};
print (i.a);

i = {a : 42, b : 1066};
print (i["a"] + i["b"]);

