
var x;

x = readln();
while (x != null)
{
  console.log(x);
  x = readln();
}

console.log(x);

