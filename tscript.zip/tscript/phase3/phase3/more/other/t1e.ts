var i;

i = {};
i[9] = 1066;
i[null] = 1914;

var j;
j = null;
console.log(i[8+1]);
console.log(i[j]);

