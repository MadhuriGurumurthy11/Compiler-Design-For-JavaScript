var i;
i=8;
console.log(i);
