var i;

 i={ a : "a" };
console.log(i.a);
//console.log(i[i.a] + i[i.b] + i[i.c]);

