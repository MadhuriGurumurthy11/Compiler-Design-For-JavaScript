var i;

i=function(){
console.log("hello");
};
i();


