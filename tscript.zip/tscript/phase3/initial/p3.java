import ts.Message;
import ts.support.*;
class p3 {
  public static void main(String args[])
  { 

 TSObject globalObject=TSObject.getGlobalObject();
try {
TSObject.getGlobalObject().put("NaN",  TSNumber.create(Double.NaN));
TSObject.getGlobalObject().put("Infinity",  TSNumber.create(Double.POSITIVE_INFINITY));
TSObject.getGlobalObject().put("undefined",  TSUndefined.value);
TSObject.getGlobalObject().put("this",TSValue.make(TSObject.getGlobalObject()));
TSObject.getGlobalObject().put("ths",TSObject.getGlobalObject());
    TSReadLn readLnInstance = new TSReadLn( );
    TSFunctionObject funcReadLn = new TSFunctionObject( readLnInstance,null );
    TSObject.getGlobalObject().put("readln", funcReadLn);

    TSNaN nanInstance = new TSNaN( );
    TSFunctionObject funcNaN = new TSFunctionObject( nanInstance, null);
    TSObject.getGlobalObject().put("isNaN", funcNaN);

    TSFinite infiniteInstance = new TSFinite( );
    TSFunctionObject funcInfinite = new TSFunctionObject( infiniteInstance,null );
    TSObject.getGlobalObject().put("isFinite", funcInfinite);

    TSTestThis testThisInstance=new TSTestThis();
    TSFunctionObject funcTestThis = new TSFunctionObject(testThisInstance,null );
TSObject obj = new TSObject();
obj.put("printXYZ", new TSFunctionObject(new TSPrintXYZ(), null));
funcTestThis.put("prototype", obj);
TSObject.getGlobalObject().put("testThis",funcTestThis);
    Message.setLineNumber(13);
TSObject.getGlobalObject().put("var_z_0",TSUndefined.value);
    TSValue var_z_0 = TSUndefined.value;
    Message.setLineNumber(0);
TSObject.getGlobalObject().put("undefined",TSUndefined.value);
    TSValue undefined = TSUndefined.value;
    Message.setLineNumber(3);
    Message.setLineNumber(3);
    TSObject temp1 = TSObject.create(null);
        
 TSObject.getGlobalObject().put("BasicObject",TSValue.make(temp1));
TSValue temp2 = TSObject.getGlobalObject().get("BasicObject");
if(temp2==null){
 throw new TSException(TSValue.make("undefined identifier:BasicObject"));
 }
    TSValue temp3 = temp2;
    Message.setLineNumber(3);
    temp3 = temp1;
    Message.setLineNumber(6);
    Message.setLineNumber(6);

 TSValue[] temp7 = new TSValue[0];
TSValue temp5 = TSObject.getGlobalObject().get("BasicObject");
if(temp5==null){
 throw new TSException(TSValue.make("undefined identifier:BasicObject"));
 }
    TSValue temp6 = temp5;
TSValue temp8 = temp6.callConstructor( true,temp6,temp7);

 TSObject.getGlobalObject().put("BattleOfHastingsPrototype",TSValue.make(temp8));
TSValue temp9 = TSObject.getGlobalObject().get("BattleOfHastingsPrototype");
if(temp9==null){
 throw new TSException(TSValue.make("undefined identifier:BattleOfHastingsPrototype"));
 }
    TSValue temp10 = temp9;
    Message.setLineNumber(6);
    temp10 = temp8;
    Message.setLineNumber(7);
TSValue temp12 = TSObject.getGlobalObject().get("BattleOfHastingsPrototype");
if(temp12==null){
 throw new TSException(TSValue.make("undefined identifier:BattleOfHastingsPrototype"));
 }
    TSValue temp13 = temp12;
    double temp14 = 1066.0;
    
 TSValue temp15 = temp13;
    temp15.put("date" ,TSValue.make(temp14));
    Message.setLineNumber(10);
    Message.setLineNumber(10);

 TSValue[] temp19 = new TSValue[0];
TSValue temp17 = TSObject.getGlobalObject().get("BasicObject");
if(temp17==null){
 throw new TSException(TSValue.make("undefined identifier:BasicObject"));
 }
    TSValue temp18 = temp17;
TSValue temp20 = temp18.callConstructor( true,temp18,temp19);

 TSObject.getGlobalObject().put("BattleOfHastings",TSValue.make(temp20));
TSValue temp21 = TSObject.getGlobalObject().get("BattleOfHastings");
if(temp21==null){
 throw new TSException(TSValue.make("undefined identifier:BattleOfHastings"));
 }
    TSValue temp22 = temp21;
    Message.setLineNumber(10);
    temp22 = temp20;
    Message.setLineNumber(11);
TSValue temp24 = TSObject.getGlobalObject().get("BattleOfHastings");
if(temp24==null){
 throw new TSException(TSValue.make("undefined identifier:BattleOfHastings"));
 }
    TSValue temp25 = temp24;
TSValue temp26 = TSObject.getGlobalObject().get("BattleOfHastingsPrototype");
if(temp26==null){
 throw new TSException(TSValue.make("undefined identifier:BattleOfHastingsPrototype"));
 }
    TSValue temp27 = temp26;
    
 TSValue temp28 = temp25;
    temp28.put("prototype" ,TSValue.make(temp27));
    Message.setLineNumber(14);
    Message.setLineNumber(14);

 TSValue[] temp32 = new TSValue[0];
TSValue temp30 = TSObject.getGlobalObject().get("BattleOfHastings");
if(temp30==null){
 throw new TSException(TSValue.make("undefined identifier:BattleOfHastings"));
 }
    TSValue temp31 = temp30;
TSValue temp33 = temp31.callConstructor( true,temp31,temp32);

 TSObject.getGlobalObject().put("z",TSValue.make(temp33));
    Message.setLineNumber(14);
    var_z_0 = temp33;
    Message.setLineNumber(16);
    Message.setLineNumber(16);
    TSValue temp34 = var_z_0;
    
 TSValue temp37 = temp34;
 String temp36= "date";
    TSValue temp35=temp37.get(TSValue.make(temp36).toStr().getInternal());
    System.out.println(temp35.toPrimitive().toStr().getInternal());
    Message.setLineNumber(19);
TSValue temp38 = TSObject.getGlobalObject().get("NaN");
if(temp38==null){
 throw new TSException(TSValue.make("undefined identifier:NaN"));
 }
    TSValue temp39 = temp38;
    System.out.println(temp39.toPrimitive().toStr().getInternal());
    Message.setLineNumber(20);
TSValue temp40 = TSObject.getGlobalObject().get("Infinity");
if(temp40==null){
 throw new TSException(TSValue.make("undefined identifier:Infinity"));
 }
    TSValue temp41 = temp40;
    System.out.println(temp41.toPrimitive().toStr().getInternal());
    Message.setLineNumber(21);
    TSValue temp42 = undefined;
    System.out.println(temp42.toPrimitive().toStr().getInternal());
    Message.setLineNumber(23);
TSValue temp43 = TSObject.getGlobalObject().get("NaN");
if(temp43==null){
 throw new TSException(TSValue.make("undefined identifier:NaN"));
 }
    TSValue temp44 = temp43;
TSValue temp45 = TSObject.getGlobalObject().get("Infinity");
if(temp45==null){
 throw new TSException(TSValue.make("undefined identifier:Infinity"));
 }
    TSValue temp46 = temp45;
    Message.setLineNumber(23);
    TSValue temp47 = (TSValue.make(temp44)).add(TSValue.make(temp46));
    System.out.println(temp47.toPrimitive().toStr().getInternal());
  }  catch(TSException e){
  Message.executionError(e.getEValue().toStr().getInternal());
  } 
  } 

}
