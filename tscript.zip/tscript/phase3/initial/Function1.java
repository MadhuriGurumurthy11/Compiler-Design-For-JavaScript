import ts.Message;
import ts.support.*;
public class Function1 implements TSCode{

public TSValue execute(boolean isConstructorCall, TSValue ths, TSValue[] args, TSEnvironment env) {

        TSValue temp1=TSObject.getGlobalObject().get("this");
    if(true)
	 return TSValue.make(temp1);
return TSUndefined.value;

   }
}
