import ts.Message;
import ts.support.*;
public class Function3 implements TSCode{

public TSValue execute(boolean isConstructorCall, TSValue ths, TSValue[] args, TSEnvironment env) {

        String temp36 = "F ";
    Message.setLineNumber(5);
    TSValue temp37=TSObject.getGlobalObject().get("this");
    
 TSValue temp40 = temp37;
 String temp39= "f";
    TSValue temp38=temp40.get(TSValue.make(temp39).toStr().getInternal());
    String temp41 = temp36 + temp38.toStr().getInternal();
    if(true)
	 return TSValue.make(temp41);
return TSUndefined.value;

   }
}
