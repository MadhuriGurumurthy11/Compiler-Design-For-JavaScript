
var x;
x = {};
console.log(this.x);

