import ts.Message;
import ts.support.*;
class p2 {
  public static void main(String args[])
  { 

 TSObject globalObject=TSObject.getGlobalObject();
try {
TSObject.getGlobalObject().put("NaN",  TSNumber.create(Double.NaN));
TSObject.getGlobalObject().put("Infinity",  TSNumber.create(Double.POSITIVE_INFINITY));
TSObject.getGlobalObject().put("undefined",  TSUndefined.value);
TSObject.getGlobalObject().put("this",TSValue.make(TSObject.getGlobalObject()));
TSObject.getGlobalObject().put("ths",TSObject.getGlobalObject());
    TSReadLn readLnInstance = new TSReadLn( );
    TSFunctionObject funcReadLn = new TSFunctionObject( readLnInstance,null );
    TSObject.getGlobalObject().put("readln", funcReadLn);

    TSNaN nanInstance = new TSNaN( );
    TSFunctionObject funcNaN = new TSFunctionObject( nanInstance, null);
    TSObject.getGlobalObject().put("isNaN", funcNaN);

    TSFinite infiniteInstance = new TSFinite( );
    TSFunctionObject funcInfinite = new TSFunctionObject( infiniteInstance,null );
    TSObject.getGlobalObject().put("isFinite", funcInfinite);

    TSTestThis testThisInstance=new TSTestThis();
    TSFunctionObject funcTestThis = new TSFunctionObject(testThisInstance,null );
TSObject obj = new TSObject();
obj.put("printXYZ", new TSFunctionObject(new TSPrintXYZ(), null));
funcTestThis.put("prototype", obj);
TSObject.getGlobalObject().put("testThis",funcTestThis);
    Message.setLineNumber(3);
TSObject.getGlobalObject().put("var_x_0",TSUndefined.value);
    TSValue var_x_0 = TSUndefined.value;
    Message.setLineNumber(8);
TSObject.getGlobalObject().put("var_Y_0",TSUndefined.value);
    TSValue var_Y_0 = TSUndefined.value;
    Message.setLineNumber(13);
TSObject.getGlobalObject().put("var_z_0",TSUndefined.value);
    TSValue var_z_0 = TSUndefined.value;
    Message.setLineNumber(0);
TSObject.getGlobalObject().put("undefined",TSUndefined.value);
    TSValue undefined = TSUndefined.value;
    Message.setLineNumber(4);
    Message.setLineNumber(4);
    TSObject temp1 = TSObject.create(null);
        double temp2 = 1066.0;
    temp1.put(("f"),TSValue.make(temp2));

 TSObject.getGlobalObject().put("x",TSValue.make(temp1));
    Message.setLineNumber(4);
    var_x_0 = temp1;
    Message.setLineNumber(9);
    Message.setLineNumber(9);
    TSObject temp4 = TSObject.create(null);
        TSValue temp5 = var_x_0;
    temp4.put(("prototype"),TSValue.make(temp5));

 TSObject.getGlobalObject().put("Y",TSValue.make(temp4));
    Message.setLineNumber(9);
    var_Y_0 = temp4;
    Message.setLineNumber(14);
    Message.setLineNumber(14);

 TSValue[] temp8 = new TSValue[0];
    TSValue temp7 = var_Y_0;
TSValue temp9 = temp7.callConstructor( true,temp7,temp8);

 TSObject.getGlobalObject().put("z",TSValue.make(temp9));
    Message.setLineNumber(14);
    var_z_0 = temp9;
    Message.setLineNumber(17);
    Message.setLineNumber(17);
    TSValue temp10 = var_z_0;
    
 TSValue temp13 = temp10;
 String temp12= "f";
    TSValue temp11=temp13.get(TSValue.make(temp12).toStr().getInternal());
    System.out.println(temp11.toPrimitive().toStr().getInternal());
  }  catch(TSException e){
  Message.executionError(e.getEValue().toStr().getInternal());
  } 
  } 

}
