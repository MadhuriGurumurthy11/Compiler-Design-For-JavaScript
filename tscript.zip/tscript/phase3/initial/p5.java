import ts.Message;
import ts.support.*;
class p5 {
  public static void main(String args[])
  { 

 TSObject globalObject=TSObject.getGlobalObject();
try {
TSObject.getGlobalObject().put("NaN",  TSNumber.create(Double.NaN));
TSObject.getGlobalObject().put("Infinity",  TSNumber.create(Double.POSITIVE_INFINITY));
TSObject.getGlobalObject().put("undefined",  TSUndefined.value);
TSObject.getGlobalObject().put("this",TSValue.make(TSObject.getGlobalObject()));
TSObject.getGlobalObject().put("ths",TSObject.getGlobalObject());
    TSReadLn readLnInstance = new TSReadLn( );
    TSFunctionObject funcReadLn = new TSFunctionObject( readLnInstance,null );
    TSObject.getGlobalObject().put("readln", funcReadLn);

    TSNaN nanInstance = new TSNaN( );
    TSFunctionObject funcNaN = new TSFunctionObject( nanInstance, null);
    TSObject.getGlobalObject().put("isNaN", funcNaN);

    TSFinite infiniteInstance = new TSFinite( );
    TSFunctionObject funcInfinite = new TSFunctionObject( infiniteInstance,null );
    TSObject.getGlobalObject().put("isFinite", funcInfinite);

    TSTestThis testThisInstance=new TSTestThis();
    TSFunctionObject funcTestThis = new TSFunctionObject(testThisInstance,null );
TSObject obj = new TSObject();
obj.put("printXYZ", new TSFunctionObject(new TSPrintXYZ(), null));
funcTestThis.put("prototype", obj);
TSObject.getGlobalObject().put("testThis",funcTestThis);
    Message.setLineNumber(0);
TSObject.getGlobalObject().put("undefined",TSUndefined.value);
    TSValue undefined = TSUndefined.value;
    Message.setLineNumber(1);
    Message.setLineNumber(1);
    TSObject temp1 = TSObject.create(null);
        
 TSObject.getGlobalObject().put("F",TSValue.make(temp1));
TSValue temp2 = TSObject.getGlobalObject().get("F");
if(temp2==null){
 throw new TSException(TSValue.make("undefined identifier:F"));
 }
    TSValue temp3 = temp2;
    Message.setLineNumber(1);
    temp3 = temp1;
    Message.setLineNumber(3);
    TSValue temp5=TSObject.getGlobalObject().get("this");
    double temp6 = 42.0;
    
 TSValue temp7 = temp5;
    temp7.put("x" ,TSValue.make(temp6));
    Message.setLineNumber(5);
    Message.setLineNumber(5);
    TSValue temp8=TSObject.getGlobalObject().get("this");
    
 TSValue temp11 = temp8;
 String temp10= "x";
    TSValue temp9=temp11.get(TSValue.make(temp10).toStr().getInternal());
    System.out.println(temp9.toPrimitive().toStr().getInternal());
    Message.setLineNumber(7);
    Message.setLineNumber(7);

 TSValue[] temp15 = new TSValue[0];
TSValue temp13 = TSObject.getGlobalObject().get("testThis");
if(temp13==null){
 throw new TSException(TSValue.make("undefined identifier:testThis"));
 }
    TSValue temp14 = temp13;
TSValue temp16 = temp14.callConstructor( true,temp14,temp15);

 TSObject.getGlobalObject().put("x",TSValue.make(temp16));
TSValue temp17 = TSObject.getGlobalObject().get("x");
if(temp17==null){
 throw new TSException(TSValue.make("undefined identifier:x"));
 }
    TSValue temp18 = temp17;
    Message.setLineNumber(7);
    temp18 = temp16;
    Message.setLineNumber(8);
    Message.setLineNumber(8);
TSValue[] temp24 = new TSValue[0];    Message.setLineNumber(8);
TSValue temp19 = TSObject.getGlobalObject().get("x");
if(temp19==null){
 throw new TSException(TSValue.make("undefined identifier:x"));
 }
    TSValue temp20 = temp19;
    
 TSValue temp23 = temp20;
 String temp22= "printXYZ";
    TSValue temp21=temp23.get(TSValue.make(temp22).toStr().getInternal());
TSValue temp26 = TSObject.getGlobalObject().get("x");
if(temp26==null){
 throw new TSException(TSValue.make("undefined identifier:x"));
 }
    TSValue temp27 = temp26;
TSValue temp25 = TSValue.make(temp21).callFunction( false,temp27,temp24)
;    Message.setLineNumber(10);
    Message.setLineNumber(10);

 TSValue[] temp31 = new TSValue[0];
TSValue temp29 = TSObject.getGlobalObject().get("F");
if(temp29==null){
 throw new TSException(TSValue.make("undefined identifier:F"));
 }
    TSValue temp30 = temp29;
TSValue temp32 = temp30.callConstructor( true,temp30,temp31);

 TSObject.getGlobalObject().put("x",TSValue.make(temp32));
TSValue temp33 = TSObject.getGlobalObject().get("x");
if(temp33==null){
 throw new TSException(TSValue.make("undefined identifier:x"));
 }
    TSValue temp34 = temp33;
    Message.setLineNumber(10);
    temp34 = temp32;
    Message.setLineNumber(11);
TSValue temp36 = TSObject.getGlobalObject().get("x");
if(temp36==null){
 throw new TSException(TSValue.make("undefined identifier:x"));
 }
    TSValue temp37 = temp36;
TSValue temp38 = TSObject.getGlobalObject().get("testThis");
if(temp38==null){
 throw new TSException(TSValue.make("undefined identifier:testThis"));
 }
    TSValue temp39 = temp38;
    
 TSValue temp40 = temp37;
    temp40.put("f" ,TSValue.make(temp39));
    Message.setLineNumber(12);
    Message.setLineNumber(12);
TSValue[] temp46 = new TSValue[0];    Message.setLineNumber(12);
TSValue temp41 = TSObject.getGlobalObject().get("x");
if(temp41==null){
 throw new TSException(TSValue.make("undefined identifier:x"));
 }
    TSValue temp42 = temp41;
    
 TSValue temp45 = temp42;
 String temp44= "f";
    TSValue temp43=temp45.get(TSValue.make(temp44).toStr().getInternal());
TSValue temp48 = TSObject.getGlobalObject().get("x");
if(temp48==null){
 throw new TSException(TSValue.make("undefined identifier:x"));
 }
    TSValue temp49 = temp48;
TSValue temp47 = TSValue.make(temp43).callFunction( false,temp49,temp46)
;    Message.setLineNumber(13);
    Message.setLineNumber(13);
TSValue temp50 = TSObject.getGlobalObject().get("x");
if(temp50==null){
 throw new TSException(TSValue.make("undefined identifier:x"));
 }
    TSValue temp51 = temp50;
    
 TSValue temp54 = temp51;
 String temp53= "xyz";
    TSValue temp52=temp54.get(TSValue.make(temp53).toStr().getInternal());
    System.out.println(temp52.toPrimitive().toStr().getInternal());
  }  catch(TSException e){
  Message.executionError(e.getEValue().toStr().getInternal());
  } 
  } 

}
