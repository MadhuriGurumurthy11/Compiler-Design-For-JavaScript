import ts.Message;
import ts.support.*;
public class Function4 implements TSCode{

public TSValue execute(boolean isConstructorCall, TSValue ths, TSValue[] args, TSEnvironment env) {

        Message.setLineNumber(6);
    TSValue temp52=TSObject.getGlobalObject().get("this");
    
 TSValue temp55 = temp52;
 String temp54= "f";
    TSValue temp53=temp55.get(TSValue.make(temp54).toStr().getInternal());
    if(true)
	 return TSValue.make(temp53);
return TSUndefined.value;

   }
}
