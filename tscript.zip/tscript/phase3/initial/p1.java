import ts.Message;
import ts.support.*;
class p1 {
  public static void main(String args[])
  { 

 TSObject globalObject=TSObject.getGlobalObject();
try {
TSObject.getGlobalObject().put("NaN",  TSNumber.create(Double.NaN));
TSObject.getGlobalObject().put("Infinity",  TSNumber.create(Double.POSITIVE_INFINITY));
TSObject.getGlobalObject().put("undefined",  TSUndefined.value);
TSObject.getGlobalObject().put("this",TSValue.make(TSObject.getGlobalObject()));
TSObject.getGlobalObject().put("ths",TSObject.getGlobalObject());
    TSReadLn readLnInstance = new TSReadLn( );
    TSFunctionObject funcReadLn = new TSFunctionObject( readLnInstance,null );
    TSObject.getGlobalObject().put("readln", funcReadLn);

    TSNaN nanInstance = new TSNaN( );
    TSFunctionObject funcNaN = new TSFunctionObject( nanInstance, null);
    TSObject.getGlobalObject().put("isNaN", funcNaN);

    TSFinite infiniteInstance = new TSFinite( );
    TSFunctionObject funcInfinite = new TSFunctionObject( infiniteInstance,null );
    TSObject.getGlobalObject().put("isFinite", funcInfinite);

    TSTestThis testThisInstance=new TSTestThis();
    TSFunctionObject funcTestThis = new TSFunctionObject(testThisInstance,null );
TSObject obj = new TSObject();
obj.put("printXYZ", new TSFunctionObject(new TSPrintXYZ(), null));
funcTestThis.put("prototype", obj);
TSObject.getGlobalObject().put("testThis",funcTestThis);
    Message.setLineNumber(2);
TSObject.getGlobalObject().put("var_i_0",TSUndefined.value);
    TSValue var_i_0 = TSUndefined.value;
    Message.setLineNumber(11);
TSObject.getGlobalObject().put("var_j_0",TSUndefined.value);
    double var_j_0 = 0;
    Message.setLineNumber(12);
TSObject.getGlobalObject().put("var_k_0",TSUndefined.value);
    double var_k_0 = 0;
    Message.setLineNumber(0);
TSObject.getGlobalObject().put("undefined",TSUndefined.value);
    TSValue undefined = TSUndefined.value;
    Message.setLineNumber(4);
    Message.setLineNumber(4);
    TSObject temp1 = TSObject.create(null);
        double temp2 = 12.0;
    temp1.put(("a"),TSValue.make(temp2));
    double temp3 = 10.0;
    temp1.put(("b"),TSValue.make(temp3));
    double temp4 = 20.0;
    temp1.put(("c"),TSValue.make(temp4));

 TSObject.getGlobalObject().put("i",TSValue.make(temp1));
    Message.setLineNumber(4);
    var_i_0 = temp1;
    Message.setLineNumber(5);
    Message.setLineNumber(5);
    TSValue temp5 = var_i_0;
    
 TSValue temp8 = temp5;
 String temp7= "a";
    TSValue temp6=temp8.get(TSValue.make(temp7).toStr().getInternal());
    Message.setLineNumber(5);
    TSValue temp9 = var_i_0;
    
 TSValue temp12 = temp9;
 String temp11= "b";
    TSValue temp10=temp12.get(TSValue.make(temp11).toStr().getInternal());
    Message.setLineNumber(5);
    TSValue temp13 = (TSValue.make(temp6)).add(TSValue.make(temp10));
    Message.setLineNumber(5);
    TSValue temp14 = var_i_0;
    
 TSValue temp17 = temp14;
 String temp16= "c";
    TSValue temp15=temp17.get(TSValue.make(temp16).toStr().getInternal());
    Message.setLineNumber(5);
    TSValue temp18 = (TSValue.make(temp13)).add(TSValue.make(temp15));
    System.out.println(temp18.toPrimitive().toStr().getInternal());
    Message.setLineNumber(7);
    Message.setLineNumber(7);
    TSObject temp20 = TSObject.create(null);
        String temp21 = "a";
    temp20.put(("a"),TSValue.make(temp21));
    String temp22 = "b";
    temp20.put(("b"),TSValue.make(temp22));
    String temp23 = "c";
    temp20.put(("c"),TSValue.make(temp23));

 TSObject.getGlobalObject().put("i",TSValue.make(temp20));
    Message.setLineNumber(7);
    var_i_0 = temp20;
    Message.setLineNumber(8);
    Message.setLineNumber(8);
    TSValue temp24 = var_i_0;
    
 TSValue temp27 = temp24;
 String temp26= "a";
    TSValue temp25=temp27.get(TSValue.make(temp26).toStr().getInternal());
    Message.setLineNumber(8);
    TSValue temp28 = var_i_0;
    
 TSValue temp31 = temp28;
 String temp30= "b";
    TSValue temp29=temp31.get(TSValue.make(temp30).toStr().getInternal());
    Message.setLineNumber(8);
    TSValue temp32 = (TSValue.make(temp25)).add(TSValue.make(temp29));
    Message.setLineNumber(8);
    TSValue temp33 = var_i_0;
    
 TSValue temp36 = temp33;
 String temp35= "c";
    TSValue temp34=temp36.get(TSValue.make(temp35).toStr().getInternal());
    Message.setLineNumber(8);
    TSValue temp37 = (TSValue.make(temp32)).add(TSValue.make(temp34));
    System.out.println(temp37.toPrimitive().toStr().getInternal());
    Message.setLineNumber(9);
    Message.setLineNumber(9);
    TSValue temp38 = var_i_0;
    
 TSValue temp41 = temp38;
 String temp40= "null";
    Message.setLineNumber(9);
    TSValue temp42 = var_i_0;
    
 TSValue temp45 = temp42;
 String temp44= "a";
    TSValue temp43=temp45.get(TSValue.make(temp44).toStr().getInternal());
    TSValue temp39=temp41.get((TSValue.make(temp43)).toStr().getInternal());
    Message.setLineNumber(9);
    TSValue temp46 = var_i_0;
    
 TSValue temp49 = temp46;
 String temp48= "null";
    Message.setLineNumber(9);
    TSValue temp50 = var_i_0;
    
 TSValue temp53 = temp50;
 String temp52= "b";
    TSValue temp51=temp53.get(TSValue.make(temp52).toStr().getInternal());
    TSValue temp47=temp49.get((TSValue.make(temp51)).toStr().getInternal());
    Message.setLineNumber(9);
    TSValue temp54 = (TSValue.make(temp39)).add(TSValue.make(temp47));
    Message.setLineNumber(9);
    TSValue temp55 = var_i_0;
    
 TSValue temp58 = temp55;
 String temp57= "null";
    Message.setLineNumber(9);
    TSValue temp59 = var_i_0;
    
 TSValue temp62 = temp59;
 String temp61= "c";
    TSValue temp60=temp62.get(TSValue.make(temp61).toStr().getInternal());
    TSValue temp56=temp58.get((TSValue.make(temp60)).toStr().getInternal());
    Message.setLineNumber(9);
    TSValue temp63 = (TSValue.make(temp54)).add(TSValue.make(temp56));
    System.out.println(temp63.toPrimitive().toStr().getInternal());
    Message.setLineNumber(13);
    double temp65 = 2.0;

 TSObject.getGlobalObject().put("j",TSValue.make(temp65));
    Message.setLineNumber(13);
    var_j_0 = temp65;
    Message.setLineNumber(14);
    double temp67 = 4.0;

 TSObject.getGlobalObject().put("k",TSValue.make(temp67));
    Message.setLineNumber(14);
    var_k_0 = temp67;
    Message.setLineNumber(15);
    Message.setLineNumber(15);
    TSObject temp69 = TSObject.create(null);
        double temp70 = 12.0;
    temp69.put(("a"),TSValue.make(temp70));
    double temp71 = var_j_0;
    double temp72 = 8.0;
    double temp73 = temp71 + temp72;
    temp69.put(("b"),TSValue.make(temp73));
    double temp74 = var_j_0;
    double temp75 = var_k_0;
    double temp76 = temp74 + temp75;
    double temp77 = 14.0;
    double temp78 = temp76 + temp77;
    temp69.put(("c"),TSValue.make(temp78));

 TSObject.getGlobalObject().put("i",TSValue.make(temp69));
    Message.setLineNumber(15);
    var_i_0 = temp69;
    Message.setLineNumber(16);
    Message.setLineNumber(16);
    TSValue temp79 = var_i_0;
    
 TSValue temp82 = temp79;
 String temp81= "a";
    TSValue temp80=temp82.get(TSValue.make(temp81).toStr().getInternal());
    Message.setLineNumber(16);
    TSValue temp83 = var_i_0;
    
 TSValue temp86 = temp83;
 String temp85= "b";
    TSValue temp84=temp86.get(TSValue.make(temp85).toStr().getInternal());
    Message.setLineNumber(16);
    TSValue temp87 = (TSValue.make(temp80)).add(TSValue.make(temp84));
    Message.setLineNumber(16);
    TSValue temp88 = var_i_0;
    
 TSValue temp91 = temp88;
 String temp90= "c";
    TSValue temp89=temp91.get(TSValue.make(temp90).toStr().getInternal());
    Message.setLineNumber(16);
    TSValue temp92 = (TSValue.make(temp87)).add(TSValue.make(temp89));
    System.out.println(temp92.toPrimitive().toStr().getInternal());
    Message.setLineNumber(18);
    TSValue temp94 = var_i_0;
    TSValue temp95 = var_i_0;
    
 TSValue temp96 = temp94;
    temp96.put("d" ,TSValue.make(temp95));
    Message.setLineNumber(19);
    Message.setLineNumber(19);
    TSValue temp98 = var_i_0;
    
 TSValue temp101 = temp98;
 String temp100= "d";
    TSValue temp99=temp101.get(TSValue.make(temp100).toStr().getInternal());
    double temp102 = 12.0;
    
 TSValue temp103 = temp99;
    temp103.put("a" ,TSValue.make(temp102));
    Message.setLineNumber(20);
    Message.setLineNumber(20);
    TSValue temp105 = var_i_0;
    
 TSValue temp108 = temp105;
 String temp107= "d";
    TSValue temp106=temp108.get(TSValue.make(temp107).toStr().getInternal());
    double temp109 = 10.0;
    
 TSValue temp110 = temp106;
    temp110.put("b" ,TSValue.make(temp109));
    Message.setLineNumber(21);
    Message.setLineNumber(21);
    TSValue temp112 = var_i_0;
    
 TSValue temp115 = temp112;
 String temp114= "d";
    TSValue temp113=temp115.get(TSValue.make(temp114).toStr().getInternal());
    double temp116 = 20.0;
    
 TSValue temp117 = temp113;
    temp117.put("c" ,TSValue.make(temp116));
    Message.setLineNumber(22);
    Message.setLineNumber(22);
    Message.setLineNumber(22);
    TSValue temp118 = var_i_0;
    
 TSValue temp121 = temp118;
 String temp120= "d";
    TSValue temp119=temp121.get(TSValue.make(temp120).toStr().getInternal());
    
 TSValue temp124 = temp119;
 String temp123= "a";
    TSValue temp122=temp124.get(TSValue.make(temp123).toStr().getInternal());
    Message.setLineNumber(22);
    Message.setLineNumber(22);
    TSValue temp125 = var_i_0;
    
 TSValue temp128 = temp125;
 String temp127= "d";
    TSValue temp126=temp128.get(TSValue.make(temp127).toStr().getInternal());
    
 TSValue temp131 = temp126;
 String temp130= "b";
    TSValue temp129=temp131.get(TSValue.make(temp130).toStr().getInternal());
    Message.setLineNumber(22);
    TSValue temp132 = (TSValue.make(temp122)).add(TSValue.make(temp129));
    Message.setLineNumber(22);
    Message.setLineNumber(22);
    TSValue temp133 = var_i_0;
    
 TSValue temp136 = temp133;
 String temp135= "d";
    TSValue temp134=temp136.get(TSValue.make(temp135).toStr().getInternal());
    
 TSValue temp139 = temp134;
 String temp138= "c";
    TSValue temp137=temp139.get(TSValue.make(temp138).toStr().getInternal());
    Message.setLineNumber(22);
    TSValue temp140 = (TSValue.make(temp132)).add(TSValue.make(temp137));
    System.out.println(temp140.toPrimitive().toStr().getInternal());
    Message.setLineNumber(23);
    Message.setLineNumber(23);
    Message.setLineNumber(23);
    TSValue temp141 = var_i_0;
    
 TSValue temp144 = temp141;
 String temp143= "null";
    String temp145 = "d";
    TSValue temp142=temp144.get((TSValue.make(temp145)).toStr().getInternal());
    
 TSValue temp148 = temp142;
 String temp147= "null";
    String temp149 = "a";
    TSValue temp146=temp148.get((TSValue.make(temp149)).toStr().getInternal());
    Message.setLineNumber(23);
    Message.setLineNumber(23);
    TSValue temp150 = var_i_0;
    
 TSValue temp153 = temp150;
 String temp152= "null";
    String temp154 = "d";
    TSValue temp151=temp153.get((TSValue.make(temp154)).toStr().getInternal());
    
 TSValue temp157 = temp151;
 String temp156= "null";
    String temp158 = "b";
    TSValue temp155=temp157.get((TSValue.make(temp158)).toStr().getInternal());
    Message.setLineNumber(23);
    TSValue temp159 = (TSValue.make(temp146)).add(TSValue.make(temp155));
    Message.setLineNumber(23);
    Message.setLineNumber(23);
    TSValue temp160 = var_i_0;
    
 TSValue temp163 = temp160;
 String temp162= "null";
    String temp164 = "d";
    TSValue temp161=temp163.get((TSValue.make(temp164)).toStr().getInternal());
    
 TSValue temp167 = temp161;
 String temp166= "null";
    String temp168 = "c";
    TSValue temp165=temp167.get((TSValue.make(temp168)).toStr().getInternal());
    Message.setLineNumber(23);
    TSValue temp169 = (TSValue.make(temp159)).add(TSValue.make(temp165));
    System.out.println(temp169.toPrimitive().toStr().getInternal());
    Message.setLineNumber(25);
    TSValue temp171 = var_i_0;
    double temp172 = 42.0;
    
 TSValue temp173 = temp171;
    temp173.put("a" ,TSValue.make(temp172));
    Message.setLineNumber(26);
    TSValue temp175 = var_i_0;
    double temp176 = 0.0;
    
 TSValue temp177 = temp175;
    temp177.put("b" ,TSValue.make(temp176));
    Message.setLineNumber(27);
    TSValue temp179 = var_i_0;
    double temp180 = 0.0;
    
 TSValue temp181 = temp179;
    temp181.put("c" ,TSValue.make(temp180));
    Message.setLineNumber(28);
    Message.setLineNumber(28);
    TSValue temp182 = var_i_0;
    
 TSValue temp185 = temp182;
 String temp184= "a";
    TSValue temp183=temp185.get(TSValue.make(temp184).toStr().getInternal());
    Message.setLineNumber(28);
    TSValue temp186 = var_i_0;
    
 TSValue temp189 = temp186;
 String temp188= "b";
    TSValue temp187=temp189.get(TSValue.make(temp188).toStr().getInternal());
    Message.setLineNumber(28);
    TSValue temp190 = (TSValue.make(temp183)).add(TSValue.make(temp187));
    Message.setLineNumber(28);
    TSValue temp191 = var_i_0;
    
 TSValue temp194 = temp191;
 String temp193= "c";
    TSValue temp192=temp194.get(TSValue.make(temp193).toStr().getInternal());
    Message.setLineNumber(28);
    TSValue temp195 = (TSValue.make(temp190)).add(TSValue.make(temp192));
    System.out.println(temp195.toPrimitive().toStr().getInternal());
    Message.setLineNumber(29);
    Message.setLineNumber(29);
    TSValue temp196 = var_i_0;
    
 TSValue temp199 = temp196;
 String temp198= "null";
    String temp200 = "a";
    TSValue temp197=temp199.get((TSValue.make(temp200)).toStr().getInternal());
    Message.setLineNumber(29);
    TSValue temp201 = var_i_0;
    
 TSValue temp204 = temp201;
 String temp203= "null";
    String temp205 = "b";
    TSValue temp202=temp204.get((TSValue.make(temp205)).toStr().getInternal());
    Message.setLineNumber(29);
    TSValue temp206 = (TSValue.make(temp197)).add(TSValue.make(temp202));
    Message.setLineNumber(29);
    TSValue temp207 = var_i_0;
    
 TSValue temp210 = temp207;
 String temp209= "null";
    String temp211 = "c";
    TSValue temp208=temp210.get((TSValue.make(temp211)).toStr().getInternal());
    Message.setLineNumber(29);
    TSValue temp212 = (TSValue.make(temp206)).add(TSValue.make(temp208));
    System.out.println(temp212.toPrimitive().toStr().getInternal());
  }  catch(TSException e){
  Message.executionError(e.getEValue().toStr().getInternal());
  } 
  } 

}
