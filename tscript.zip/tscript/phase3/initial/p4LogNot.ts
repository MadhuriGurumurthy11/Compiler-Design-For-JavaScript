
var x;
x=false;
console.log(!x);
