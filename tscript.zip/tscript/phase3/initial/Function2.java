import ts.Message;
import ts.support.*;
public class Function2 implements TSCode{

public TSValue execute(boolean isConstructorCall, TSValue ths, TSValue[] args, TSEnvironment env) {

        TSValue temp8=TSObject.getGlobalObject().get("this");
    if(true)
	 return TSValue.make(temp8);
return TSUndefined.value;

   }
}
