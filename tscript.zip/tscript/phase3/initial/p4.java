import ts.Message;
import ts.support.*;
class p4 {
  public static void main(String args[])
  { 

 TSObject globalObject=TSObject.getGlobalObject();
try {
TSObject.getGlobalObject().put("NaN",  TSNumber.create(Double.NaN));
TSObject.getGlobalObject().put("Infinity",  TSNumber.create(Double.POSITIVE_INFINITY));
TSObject.getGlobalObject().put("undefined",  TSUndefined.value);
TSObject.getGlobalObject().put("this",TSValue.make(TSObject.getGlobalObject()));
TSObject.getGlobalObject().put("ths",TSObject.getGlobalObject());
    TSReadLn readLnInstance = new TSReadLn( );
    TSFunctionObject funcReadLn = new TSFunctionObject( readLnInstance,null );
    TSObject.getGlobalObject().put("readln", funcReadLn);

    TSNaN nanInstance = new TSNaN( );
    TSFunctionObject funcNaN = new TSFunctionObject( nanInstance, null);
    TSObject.getGlobalObject().put("isNaN", funcNaN);

    TSFinite infiniteInstance = new TSFinite( );
    TSFunctionObject funcInfinite = new TSFunctionObject( infiniteInstance,null );
    TSObject.getGlobalObject().put("isFinite", funcInfinite);

    TSTestThis testThisInstance=new TSTestThis();
    TSFunctionObject funcTestThis = new TSFunctionObject(testThisInstance,null );
TSObject obj = new TSObject();
obj.put("printXYZ", new TSFunctionObject(new TSPrintXYZ(), null));
funcTestThis.put("prototype", obj);
TSObject.getGlobalObject().put("testThis",funcTestThis);
    Message.setLineNumber(2);
TSObject.getGlobalObject().put("var_x_0",TSUndefined.value);
    TSValue var_x_0 = TSUndefined.value;
    Message.setLineNumber(0);
TSObject.getGlobalObject().put("undefined",TSUndefined.value);
    TSValue undefined = TSUndefined.value;
    Message.setLineNumber(4);
    double temp1 = 1.0;

 TSObject.getGlobalObject().put("x",TSValue.make(temp1));
    TSValue temp2 = TSValue.make(temp1);
    Message.setLineNumber(4);
    var_x_0 = temp2;
    
 Message.setLineNumber(6);
        Message.setLineNumber(6);
    TSValue temp5 = var_x_0;
TSValue[] temp6 = {    (TSValue.make(temp5))};;TSValue temp3 = TSObject.getGlobalObject().get("isFinite");
if(temp3==null){
 throw new TSException(TSValue.make("undefined identifier:isFinite"));
 }
    TSValue temp4 = temp3;
TSValue temp7 = TSValue.make(temp4).callFunction( false, null,temp6);

 if(temp7.toBoolean().getInternal()==true){{    Message.setLineNumber(7);
        Message.setLineNumber(8);
    double temp8 = 42.0;
    System.out.println(TSNumber.create(temp8).toStr().getInternal());

}}
    
 Message.setLineNumber(11);
        Message.setLineNumber(11);
    TSValue temp11 = var_x_0;
TSValue[] temp12 = {    (TSValue.make(temp11))};;TSValue temp9 = TSObject.getGlobalObject().get("isNaN");
if(temp9==null){
 throw new TSException(TSValue.make("undefined identifier:isNaN"));
 }
    TSValue temp10 = temp9;
TSValue temp13 = TSValue.make(temp10).callFunction( false, null,temp12);

 if(temp13.toBoolean().getInternal()==true){{    Message.setLineNumber(12);
        Message.setLineNumber(13);
    double temp14 = 43.0;
    System.out.println(TSNumber.create(temp14).toStr().getInternal());

}}
    Message.setLineNumber(16);
    TSValue temp16 = var_x_0;
TSValue temp17 = TSObject.getGlobalObject().get("NaN");
if(temp17==null){
 throw new TSException(TSValue.make("undefined identifier:NaN"));
 }
    TSValue temp18 = temp17;
    Message.setLineNumber(16);
    TSValue temp19 = (TSValue.make(temp16)).add(TSValue.make(temp18));

 TSObject.getGlobalObject().put("x",TSValue.make(temp19));
    Message.setLineNumber(16);
    var_x_0 = temp19;
    
 Message.setLineNumber(18);
        Message.setLineNumber(18);
    TSValue temp22 = var_x_0;
TSValue[] temp23 = {    (TSValue.make(temp22))};;TSValue temp20 = TSObject.getGlobalObject().get("isFinite");
if(temp20==null){
 throw new TSException(TSValue.make("undefined identifier:isFinite"));
 }
    TSValue temp21 = temp20;
TSValue temp24 = TSValue.make(temp21).callFunction( false, null,temp23);

 if(temp24.toBoolean().getInternal()==true){{    Message.setLineNumber(19);
        Message.setLineNumber(20);
    double temp25 = 43.0;
    System.out.println(TSNumber.create(temp25).toStr().getInternal());

}}
    
 Message.setLineNumber(23);
        Message.setLineNumber(23);
    TSValue temp28 = var_x_0;
TSValue[] temp29 = {    (TSValue.make(temp28))};;TSValue temp26 = TSObject.getGlobalObject().get("isNaN");
if(temp26==null){
 throw new TSException(TSValue.make("undefined identifier:isNaN"));
 }
    TSValue temp27 = temp26;
TSValue temp30 = TSValue.make(temp27).callFunction( false, null,temp29);

 if(temp30.toBoolean().getInternal()==true){{    Message.setLineNumber(24);
        Message.setLineNumber(25);
    double temp31 = 42.0;
    System.out.println(TSNumber.create(temp31).toStr().getInternal());

}}
    Message.setLineNumber(28);
    TSValue temp33 = var_x_0;
TSValue temp34 = TSObject.getGlobalObject().get("Infinity");
if(temp34==null){
 throw new TSException(TSValue.make("undefined identifier:Infinity"));
 }
    TSValue temp35 = temp34;
    Message.setLineNumber(28);
    TSValue temp36 = (TSValue.make(temp33)).add(TSValue.make(temp35));

 TSObject.getGlobalObject().put("x",TSValue.make(temp36));
    Message.setLineNumber(28);
    var_x_0 = temp36;
    
 Message.setLineNumber(30);
        Message.setLineNumber(30);
    TSValue temp39 = var_x_0;
TSValue[] temp40 = {    (TSValue.make(temp39))};;TSValue temp37 = TSObject.getGlobalObject().get("isFinite");
if(temp37==null){
 throw new TSException(TSValue.make("undefined identifier:isFinite"));
 }
    TSValue temp38 = temp37;
TSValue temp41 = TSValue.make(temp38).callFunction( false, null,temp40);

 if(temp41.toBoolean().getInternal()==true){{    Message.setLineNumber(31);
        Message.setLineNumber(32);
    double temp42 = 43.0;
    System.out.println(TSNumber.create(temp42).toStr().getInternal());

}}
    
 Message.setLineNumber(35);
        Message.setLineNumber(35);
    TSValue temp45 = var_x_0;
TSValue[] temp46 = {    (TSValue.make(temp45))};;TSValue temp43 = TSObject.getGlobalObject().get("isNaN");
if(temp43==null){
 throw new TSException(TSValue.make("undefined identifier:isNaN"));
 }
    TSValue temp44 = temp43;
TSValue temp47 = TSValue.make(temp44).callFunction( false, null,temp46);

 if(temp47.toBoolean().getInternal()==true){{    Message.setLineNumber(36);
        Message.setLineNumber(37);
    double temp48 = 42.0;
    System.out.println(TSNumber.create(temp48).toStr().getInternal());

}}
    Message.setLineNumber(40);
    Message.setLineNumber(40);
TSValue[] temp52 = new TSValue[0];TSValue temp50 = TSObject.getGlobalObject().get("readln");
if(temp50==null){
 throw new TSException(TSValue.make("undefined identifier:readln"));
 }
    TSValue temp51 = temp50;
TSValue temp53 = TSValue.make(temp51).callFunction( false, null,temp52);

 TSObject.getGlobalObject().put("x",TSValue.make(temp53));
    Message.setLineNumber(40);
    var_x_0 = temp53;
    Message.setLineNumber(41);
while(true){    TSValue temp60 = var_x_0;
    TSValue temp61 = TSNull.value;
    Message.setLineNumber(41);
    TSValue temp62 = (TSValue.make(temp60)).equals(TSValue.make(temp61));
    Message.setLineNumber(41);
    TSValue temp63 = (TSValue.make(temp62)).logicalnot(TSValue.make(temp62));
if(temp63.toBoolean().getInternal() == false)break;
if (temp63.toBoolean().getInternal() == true){{    Message.setLineNumber(42);
        Message.setLineNumber(43);
    TSValue temp54 = var_x_0;
    System.out.println(temp54.toPrimitive().toStr().getInternal());

        Message.setLineNumber(44);
    Message.setLineNumber(44);
TSValue[] temp58 = new TSValue[0];TSValue temp56 = TSObject.getGlobalObject().get("readln");
if(temp56==null){
 throw new TSException(TSValue.make("undefined identifier:readln"));
 }
    TSValue temp57 = temp56;
TSValue temp59 = TSValue.make(temp57).callFunction( false, null,temp58);

 TSObject.getGlobalObject().put("x",TSValue.make(temp59));
    Message.setLineNumber(44);
    var_x_0 = temp59;

}}
 }
  }  catch(TSException e){
  Message.executionError(e.getEValue().toStr().getInternal());
  } 
  } 

}
