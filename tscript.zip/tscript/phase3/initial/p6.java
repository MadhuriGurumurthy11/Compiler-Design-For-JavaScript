import ts.Message;
import ts.support.*;
class p6 {
  public static void main(String args[])
  { 

 TSObject globalObject=TSObject.getGlobalObject();
try {
TSObject.getGlobalObject().put("NaN",  TSNumber.create(Double.NaN));
TSObject.getGlobalObject().put("Infinity",  TSNumber.create(Double.POSITIVE_INFINITY));
TSObject.getGlobalObject().put("undefined",  TSUndefined.value);
TSObject.getGlobalObject().put("this",TSValue.make(TSObject.getGlobalObject()));
TSObject.getGlobalObject().put("ths",TSObject.getGlobalObject());
    TSReadLn readLnInstance = new TSReadLn( );
    TSFunctionObject funcReadLn = new TSFunctionObject( readLnInstance,null );
    TSObject.getGlobalObject().put("readln", funcReadLn);

    TSNaN nanInstance = new TSNaN( );
    TSFunctionObject funcNaN = new TSFunctionObject( nanInstance, null);
    TSObject.getGlobalObject().put("isNaN", funcNaN);

    TSFinite infiniteInstance = new TSFinite( );
    TSFunctionObject funcInfinite = new TSFunctionObject( infiniteInstance,null );
    TSObject.getGlobalObject().put("isFinite", funcInfinite);

    TSTestThis testThisInstance=new TSTestThis();
    TSFunctionObject funcTestThis = new TSFunctionObject(testThisInstance,null );
TSObject obj = new TSObject();
obj.put("printXYZ", new TSFunctionObject(new TSPrintXYZ(), null));
funcTestThis.put("prototype", obj);
TSObject.getGlobalObject().put("testThis",funcTestThis);
    Message.setLineNumber(8);
TSObject.getGlobalObject().put("var_x_0",TSUndefined.value);
    TSValue var_x_0 = TSUndefined.value;
    Message.setLineNumber(0);
TSObject.getGlobalObject().put("undefined",TSUndefined.value);
    TSValue undefined = TSUndefined.value;
    Message.setLineNumber(1);
    Message.setLineNumber(1);
    TSCode temp3 = new Function1();
 
    TSValue temp2 = TSFunctionObject.create(temp3, null);

 TSObject.getGlobalObject().put("BasicObject",TSValue.make(temp2));
TSValue temp5 = TSObject.getGlobalObject().get("BasicObject");
if(temp5==null){
 throw new TSException(TSValue.make("undefined identifier:BasicObject"));
 }
    TSValue temp6 = temp5;
    Message.setLineNumber(1);
    temp6 = temp2;
    Message.setLineNumber(2);
    Message.setLineNumber(2);
    TSCode temp10 = new Function2();
 
    TSValue temp9 = TSFunctionObject.create(temp10, null);

 TSObject.getGlobalObject().put("F",TSValue.make(temp9));
TSValue temp12 = TSObject.getGlobalObject().get("F");
if(temp12==null){
 throw new TSException(TSValue.make("undefined identifier:F"));
 }
    TSValue temp13 = temp12;
    Message.setLineNumber(2);
    temp13 = temp9;
    Message.setLineNumber(3);
TSValue temp15 = TSObject.getGlobalObject().get("F");
if(temp15==null){
 throw new TSException(TSValue.make("undefined identifier:F"));
 }
    TSValue temp16 = temp15;
    Message.setLineNumber(3);

 TSValue[] temp19 = new TSValue[0];
TSValue temp17 = TSObject.getGlobalObject().get("BasicObject");
if(temp17==null){
 throw new TSException(TSValue.make("undefined identifier:BasicObject"));
 }
    TSValue temp18 = temp17;
TSValue temp20 = temp18.callConstructor( true,temp18,temp19);
    
 TSValue temp21 = temp16;
    temp21.put("prototype" ,TSValue.make(temp20));
    Message.setLineNumber(4);
    Message.setLineNumber(4);
TSValue temp23 = TSObject.getGlobalObject().get("F");
if(temp23==null){
 throw new TSException(TSValue.make("undefined identifier:F"));
 }
    TSValue temp24 = temp23;
    
 TSValue temp27 = temp24;
 String temp26= "prototype";
    TSValue temp25=temp27.get(TSValue.make(temp26).toStr().getInternal());
    double temp28 = 0.0;
    
 TSValue temp29 = temp25;
    temp29.put("f" ,TSValue.make(temp28));
    Message.setLineNumber(5);
    Message.setLineNumber(5);
TSValue temp31 = TSObject.getGlobalObject().get("F");
if(temp31==null){
 throw new TSException(TSValue.make("undefined identifier:F"));
 }
    TSValue temp32 = temp31;
    
 TSValue temp35 = temp32;
 String temp34= "prototype";
    TSValue temp33=temp35.get(TSValue.make(temp34).toStr().getInternal());
    Message.setLineNumber(5);
    TSCode temp43 = new Function3();
 
    TSValue temp42 = TSFunctionObject.create(temp43, null);
    
 TSValue temp45 = temp33;
    temp45.put("toString" ,TSValue.make(temp42));
    Message.setLineNumber(6);
    Message.setLineNumber(6);
TSValue temp47 = TSObject.getGlobalObject().get("F");
if(temp47==null){
 throw new TSException(TSValue.make("undefined identifier:F"));
 }
    TSValue temp48 = temp47;
    
 TSValue temp51 = temp48;
 String temp50= "prototype";
    TSValue temp49=temp51.get(TSValue.make(temp50).toStr().getInternal());
    Message.setLineNumber(6);
    TSCode temp57 = new Function4();
 
    TSValue temp56 = TSFunctionObject.create(temp57, null);
    
 TSValue temp59 = temp49;
    temp59.put("valueOf" ,TSValue.make(temp56));
    Message.setLineNumber(9);
    Message.setLineNumber(9);

 TSValue[] temp63 = new TSValue[0];
TSValue temp61 = TSObject.getGlobalObject().get("F");
if(temp61==null){
 throw new TSException(TSValue.make("undefined identifier:F"));
 }
    TSValue temp62 = temp61;
TSValue temp64 = temp62.callConstructor( true,temp62,temp63);

 TSObject.getGlobalObject().put("x",TSValue.make(temp64));
    Message.setLineNumber(9);
    var_x_0 = temp64;
    Message.setLineNumber(10);
    TSValue temp65 = var_x_0;
    System.out.println(temp65.toPrimitive().toStr().getInternal());
    Message.setLineNumber(12);
    String temp66 = "x is ";
    TSValue temp67 = var_x_0;
    String temp68 = temp66 + temp67.toStr().getInternal();
    System.out.println(temp68);
    Message.setLineNumber(13);
    String temp69 = "x+1 is ";
    TSValue temp70 = var_x_0;
    double temp71 = 1.0;
    Message.setLineNumber(13);
    TSValue temp72 = (TSValue.make(temp70)).add(TSValue.make(temp71));
    String temp73 = temp69 + temp72.toStr().getInternal();
    System.out.println(temp73);
    Message.setLineNumber(15);
    TSValue temp75 = var_x_0;
    double temp76 = 99.0;
    
 TSValue temp77 = temp75;
    temp77.put("f" ,TSValue.make(temp76));
    Message.setLineNumber(16);
    String temp78 = "x is ";
    TSValue temp79 = var_x_0;
    String temp80 = temp78 + temp79.toStr().getInternal();
    System.out.println(temp80);
    Message.setLineNumber(17);
    String temp81 = "x+1 is ";
    TSValue temp82 = var_x_0;
    double temp83 = 1.0;
    Message.setLineNumber(17);
    TSValue temp84 = (TSValue.make(temp82)).add(TSValue.make(temp83));
    String temp85 = temp81 + temp84.toStr().getInternal();
    System.out.println(temp85);
  }  catch(TSException e){
  Message.executionError(e.getEValue().toStr().getInternal());
  } 
  } 

}
