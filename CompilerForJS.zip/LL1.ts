var x;
x={};
var productionsArray;
productionsArray=new x();
productionsArray.count=0;

var startSymbol;
startSymbol=null;
var nonTerminals;
nonTerminals = " ";
var nonTerminalsArray;
nonTerminalsArray=new x();
nonTerminalsArray.count=0;
var terminals;
terminals = "";
var productionCount;
productionCount = 0;
var finalTerminals;
finalTerminals = "";
var finalNonTerminals;
finalNonTerminals="";
var i;
i=0;
var pCount;
pCount=0;
var productionCharacters;
productionCharacters=new x();
productionCharacters.count=0;

var productionsArrayForFirst;
productionsArrayForFirst=new x();
var grammarLine;
 grammarLine=readln();

while(!(grammarLine==null)){
	productionsArray[productionCount]=trim(grammarLine);
	productionsArrayForFirst[productionCount]=trim(grammarLine);
	
	productionsArray.count=productionsArray.count+1;
	productionCharacters[productionCount]=split(trim(grammarLine));
	var nonTerminal;
	nonTerminal = productionCharacters[productionCount][0];
	if ((indexOf(finalNonTerminals,nonTerminal)) < 0)
	{
		finalNonTerminals = finalNonTerminals + nonTerminal + " ";
		nonTerminalsArray[i]=nonTerminal;
		nonTerminalsArray.count=nonTerminalsArray.count+1;
		i=i+1;
	}
	var j;
	j = 1;
	while (j < (productionCharacters[productionCount].count)) 
	{
		var entry;
		entry=productionCharacters[productionCount][j];
		if ((indexOf(terminals,entry + " ")) < 0)
		{
			terminals = terminals + entry + " ";
		}
		j = j + 1;
	}
	productionCount = productionCount +1;
	productionCharacters.count=productionCharacters.count+1;
	grammarLine = readln();
} // End Reading File

startSymbol=productionCharacters[0][0];

var terminalsArray ;
terminalsArray= split(terminals," ");
i=0;
while (i < terminalsArray.count)
{
	var y;
	y=(indexOf(finalNonTerminals,terminalsArray[i]));
	if( y< 0)
	{
		finalTerminals = finalTerminals + terminalsArray[i] + " ";
	}
	i = i+1;
}

console.log("StartSymbol");
console.log(" ");
console.log(startSymbol);
console.log(" ");
console.log("Nonterminals");
console.log(" ");
console.log(finalNonTerminals);
console.log(" ");
console.log("Terminals");
console.log(" ");
console.log(finalTerminals);
console.log(" ");
//---------------------------------------------------------------------------------------------

// Identify the Null derivations
	  var nonNullTerminals;
	  nonNullTerminals = "";
	  var nullTerminals;
	  nullTerminals = "";
	  var nullDerives;
	  nullDerives="";
	  var nullArray;
	  nullArray=new x();

	 productionCount = 0;
	  while (productionCount < productionsArray.count)
	  {
		  var terminalFound;
		  terminalFound = false;
			grammarLine = productionsArray[productionCount];
		
			productionCount = productionCount +1;
			terminalsArray = split(grammarLine);
			nonTerminal = terminalsArray[0];
			j=0;
			
				if((terminalsArray.count)==2)
				{	
					if((indexOf(nullDerives,terminalsArray[1]))>(-1))
					{
						if((indexOf(nullDerives,nonTerminal))<0)
						{
							nullDerives=nullDerives+nonTerminal+" ";
						}
					}
				}
				if((terminalsArray.count)>1)
				{
					
					//S a
					var r;
					r=indexOf(finalTerminals,terminalsArray[1]);
					
					if(r>(-1))
					{
						nonNullTerminals=nonNullTerminals+nonTerminal+" ";
					}
					// S A B C
					else{
						
						var g;
						g=1;
							
							while(g<(terminalsArray.count))
							{
							var z;
							z=indexOf(nullDerives,terminalsArray[g]);
								if(z>(-1))
								{
								g=g+1;
									continue;
								}
								else{
								break;
								}
							}
							if(g==(terminalsArray.count)){
								var u;
								u=(indexOf(nullDerives,nonTerminal));
									if(u<0){
										nullDerives=nullDerives+nonTerminal+" ";
									}
							
							}
						}
							
				}
			 }

productionCount = 0;
var pc;
pc=0;
 var fNT;
 fNT=split(finalNonTerminals);
while (pc < (productionsArray.count))
{
productionCount=0;
	  while (productionCount < (productionsArray.count))
	  {
	  
	  	var g;
	  	g=1;
	  	grammarLine = productionsArray[productionCount];
		
			productionCount = productionCount +1;
			terminalsArray = split(grammarLine);
			nonTerminal = terminalsArray[0];
							
							while(g<(terminalsArray.count))
							{
								if(!((indexOf(nullDerives,terminalsArray[g]))<0))
								{
								g=g+1;
									continue;
								}
								else{
								break;
								}
							}
							if(g==(terminalsArray.count))
							{
								var z;
								z=(indexOf(nullDerives,nonTerminal));
								if(z<0){
									nullDerives=nullDerives+nonTerminal+" ";
								}
							}

	  
	  }
	  pc=pc+1;
}

nullArray=split(trim(nullDerives));

console.log("Null-Deriving Nonterminals");
console.log(" ");

var m1;
m1=0;
var m2;
m2=split(trim(nullDerives));
var m3;
m3=arrayLength(m2);
var strToDisp1;
strToDisp1="";
while(m1 < m3)
{
	strToDisp1=strToDisp1+m2[m1]+" ";
	m1=m1+1;
}
console.log(strToDisp1);
console.log(" ");
nullDerives=strToDisp1;
//-------------------------------------------------------------------------------------------------
var firstSet;
firstSet={};
	var prodArrayChars;
	var prodCount;
	prodCount=0;
	var pC;
	pC=arrayLength(productionsArray);
	var i;
	i=0;
	var first;
	first="";
	while(!(pC<1))
	{
		var firstStr;
		firstStr="";
		var nonTerminal;

		prodArrayChars=split(trim(productionsArray[prodCount]));

		nonTerminal=prodArrayChars[0];

		if((arrayLength(prodArrayChars)) >1)
		{
			
			if ((indexOf(finalTerminals,prodArrayChars[1])) > -1)
			{
				var aLen;
				aLen=arrayLength(firstSet);
				var m;
				m=0;
				
				if(aLen>0)
				{
					while(m<aLen)
					{	
	
						var str;
						str="";
						str=split(trim(firstSet[m]));
						
						//console.log(str[0]+" "+prodArrayChars[0]);
						if(str[0]==prodArrayChars[0])
						{
							firstStr=firstSet[m];
							if((indexOf(firstStr,prodArrayChars[1]))<0)
							{
							//console.log(firstStr+"******* "+prodArrayChars[1]);
								firstStr=firstStr+" "+prodArrayChars[1];
								firstSet[m]=firstStr;
							}
						}else{
							firstSet[i]=nonTerminal+" "+prodArrayChars[1];
							i=i+1;
						}
						m=m+1;
					}	
				}else
				{
				
					firstSet[i]=nonTerminal+" "+prodArrayChars[1];
					i=i+1;
				}
				
			}
		}
		pC=pC-1;
		prodCount=prodCount+1;
	}

	
	var toRun;
	toRun=false;
	
	var first;
	first="";
	var t5;
	t5=0;
	var pass;
	pass=1;
	var str2;
	str2="";
	var t9;
	t9=productionsArray.count;
	while(pass < (t9+1))
	{	
		var prodArrayChars;
		var prodCount;
		prodCount=0;
		var pC;
		pC=arrayLength(productionsArray);
		toRun=false;
		while(prodCount< pC)
		{
			var firstStr;
			firstStr="";
			var nonTerminal;
	
			prodArrayChars=split(trim(productionsArray[prodCount]));
			
			nonTerminal=prodArrayChars[0];
			//console.log("%%%%% "+nonTerminal);
			if((arrayLength(prodArrayChars)) >1)
			{
			
				if ((indexOf(finalNonTerminals,prodArrayChars[1])) > -1)
				{
					var str;
					str="";
					var fLen;
					fLen=arrayLength(firstSet);
					var t4;
					t4=0;
					while(t4< fLen)
					{
			
						str=split(trim(firstSet[t4]));
						if(str[0]==prodArrayChars[1])
						{
						//console.log("str[0] "+ str[0]+" >>> "+(str[0]==prodArrayChars[1]));
							firstStr=firstSet[t4];
							//console.log("*%%%%%%* "+firstStr+"%%%%%%%");
							var str1;
							str1="";
							
							//console.log("****** "+temp);
							str1=trim(subString(firstStr,1,125));
							//console.log("*$$$%%* "+str1);
								var t8;
								t8=true;
								var flagToAdd;
								flagToAdd=false;
								//This loop is to check if the first of the nonterminal is alreADY PRESENT.iF YES, THE FIRST  SET IS APPENEDED TO IT.
								var t5;
								t5=arrayLength(firstSet);
								var t6;
								t6=0;
								
								while(t6< t5)
								{
									var t7;
									t7="";
									t7=split(trim(firstSet[t6]));
								
									if(t7[0]==nonTerminal)
									{
									
										//console.log("****** "+firstSet[t6]+" >> "+str1);
										firstSet[t6]=firstSet[t6]+" "+str1;
										
										t8=false;
									flagToAdd=true;
										
									}
									
						//NUll derivings ---> first-------------------------------------------------------
							
					if((indexOf(nullDerives,prodArrayChars[1])) > -1)
					{
							var t13;
							t13=arrayLength(prodArrayChars);
							var t14;
							t14=1;
							while(t14 <t13)
							{
								
								if((indexOf(nullDerives,prodArrayChars[t14])) > -1)
								{
									var t15;
									t15=0;
									var t17;
									t17=t14+1;
									var t16;
									t16=arrayLength(firstSet);
									while(t15<t16)
									{
										if((arrayLength(firstSet)) >0)
										{
											
											str=split(trim(firstSet[t15]));
											
											str2="";
										
											str2=trim(subString(firstSet[t15],1,125));
										
											if((t17)<t13)
											{
												if(str[0]==prodArrayChars[t17])
												{
											
													var str3;
													if(flagToAdd)
													{
														//console.log("%%%%%% "+firstSet[t6]+ ", "+str2);
														firstSet[t6]=firstSet[t6]+" "+str2;
													}
												
												}
											}
										}
										t15=t15+1;
										
									}
								
								} else
								{
									var terminalCase;
									terminalCase="";
									if((indexOf(finalTerminals,prodArrayChars[t14])) > -1)
									{
										terminalCase=prodArrayChars[t14]+" ";
									
									}
								
								}
								
						//-------------------------------------------------------
								t14=t14+1;
							}

					}				

										t6=t6+1;
								}
							//}
							
							//iF NO ENTRY FOR THE NONTERMINAL IS THERE IN THE FIRST SET, THEN IT'S NEWLY ADDED.
							if(t8)
							{
								//console.log("&&&&& "+nonTerminal+" = "+ ", "+str1);
								firstSet[i]=nonTerminal+" "+str1+" "+terminalCase;
							//	console.log("firstSet[i] "+firstSet[i]);
								if(!flagToAdd){
									//console.log("&&&&& "+firstSet[i]+ ", "+str2);
									firstSet[i]=firstSet[i]+" "+str2;
									flagToAdd=false;
								}
								i=i+1;
							}
							
						} //CHECK THIS

						t4=t4+1;
					}
				}	
			}
			if(prodCount < pC)
			{
				prodCount=prodCount+1;
				//console.log("prodCount ="+prodCount);
			}
		}
		pass=pass+1;
	}


console.log("First Sets");
console.log("");
var finalFirstSet;
finalFirstSet={};
var t1;
t1=arrayLength(firstSet);
var m;
m=0;
while(m <t1)
{
	var t10;
	
	t10=split(trim(firstSet[m]));
	
	var Nt;
	Nt=t10[0];
	var finalStr;
	finalStr="";

	finalStr=Nt+" ";
	var t11;
	t11=0;
	var t12;
	t12=arrayLength(t10);
	while(t11<t12)
	{
		if((indexOf(finalStr,t10[t11]))< 0)
		{
			finalStr=(trim(finalStr))+" "+t10[t11];
		}
		t11=t11+1;
	}
	finalFirstSet[m]=finalStr;

	m=m+1;
	
}

var s1;
s1=arrayLength(finalFirstSet);
var s2;
s2=0;
var finalfinalFirstSet;
finalfinalFirstSet={};
while(s2 < s1)
{
	var s3;
	s3=split(trim(finalFirstSet[s2]));
	var s4;
	s4=0;
	var s5;
	s5=arrayLength(finalfinalFirstSet);
	
	if( s5 ==0)
	{
		finalfinalFirstSet[s4]=finalFirstSet[0];
		
	}else
	{
		while(s4 < s5)
		{
			var s6;
			s6=arrayLength(finalfinalFirstSet);
			var s7;
			s7=0;
			var flagtoadd;
			flagtoadd=true;
			while(s7 < s6)
			{
				var s8;
				s8=split(trim(finalfinalFirstSet[s7]));
				if(s8[0]==s3[0])
				{
					flagtoadd=false;
				}
				s7=s7+1;
			}
			if(flagtoadd)
				{
					finalfinalFirstSet[s6]=finalFirstSet[s2];
				}
			s4=s4+1;
		}
	}
	s2=s2+1;
}


t1=arrayLength(finalfinalFirstSet);
var m;
m=0;
while(m <t1)
{
	var s11;
	s11=0;
	var s12;
	s12=split(trim(finalfinalFirstSet[m]));
	var s13;
	s13=arrayLength(s12);
	var strToDisp;
	strToDisp="";
	while(s11 < s13)
	{
		if( s11 == 0)
		{
			strToDisp=s12[s11]+": ";
		}else
		{
			strToDisp=(trim(strToDisp))+" "+s12[s11]+" ";
		
		}
	
		s11=s11+1;
	}
	console.log(strToDisp);
	m=m+1;
}

//Adding those non-terminals that do not have firsts at all


var h1;
h1=split(trim(finalNonTerminals));
var h2;
h2=0;
var h3;
h3=arrayLength(h1);
var presentFlag;

var add;
add=arrayLength(finalfinalFirstSet);
while( h2 < h3)
{
	var h4;
	h4=0;
	var h5;
	h5=arrayLength(finalfinalFirstSet);
	presentFlag=false;
	while(h4 < h5)
	{
		var h6;
		h6=split(trim(finalfinalFirstSet[h4]));
	//	console.log(h1[h2]);
		if(h1[h2]==h6[0])
		{
			presentFlag=true;
		}
		h4=h4+1;
	}
	
	if(!presentFlag)
	{
	
		finalfinalFirstSet[add]=h1[h2]+":";
		console.log(finalfinalFirstSet[add]);
		add=add+1;
	}

 
 h2=h2+1;
}




console.log(" ");
var getFirst;

getFirst=function(nonTerminal, finalfinalFirstSet){

		var first;

		first="";

		var arrLen;

		arrLen=arrayLength(finalfinalFirstSet);

		var temp;

		temp=0;

		while(temp < arrLen){

			var str;

			str=split(finalfinalFirstSet[temp]);

			if(str[0]==nonTerminal){
			
			var v1;
			v1=split(trim(finalfinalFirstSet[temp]));
			var v2;
			v2=1;
			var v3;
			v3=arrayLength(v1);
			while(v2 < v3)
			{
								
				first=first+v1[v2]+" ";
				v2=v2+1;
				
			}
		}
		temp=temp+1;

		}

	return first;

};


//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//FOLLOW SET


console.log("Follow set");
console.log(" ");


var followSet;
followSet={};



var i;
i=-0;

followSet[i]=startSymbol+" EOF";
// S A B C
var t6;
t6=0;
var t7;
t7=productionsArray.count;
//console.log("&&& "+t7);


while( t6 < (t7+13))
{
	var t1;
	t1=0;
	
	while(t1 < t7)
	{
		
		var productions;
		productions=productionsArray[t1];
		var prodSplit;
		prodSplit=split(trim(productions));
		var prodSplitLen;
		prodSplitLen=(arrayLength(prodSplit));
		//console.log("*** ="+productions);
		if(prodSplitLen >1) //one if
		{
			var t2;
			t2=1;
			while( t2 < prodSplitLen)
			{
				if((indexOf(finalNonTerminals,prodSplit[t2])) > -1 ) //if brinjal
				{
					
					//Check if follow set already contains an entry of the nonterminal
					
					var contains;
					contains=false;
					var t4;
					t4=0;
					var t5;
					t5=arrayLength(followSet);
				
					while(t4 < t5){
						var followSplit;
						//NULL
						followSplit=split(followSet[t4]);
						
						if(followSplit[0] == prodSplit[t2] )
						{
							contains=true;
						}
					
					t4=t4+1;
					}
					if(!contains)
					{
	
						i=i+1;
						followSet[i]=prodSplit[t2];
						//console.log("!!!!!!!!!!!!!!! "+followSet[i]+" ------> "+prodSplit[t2]);
					}
					
					var t3;
					t3=t2+1;
					if(t3<prodSplitLen) //if peas
					{
						if((indexOf(finalTerminals,prodSplit[t3])) > -1) //if carrot
						{
						
								if((indexOf(followSet[i],prodSplit[t3])) < 0) //if mango
								{
									var t8;
									t8=split(trim(followSet[i]));
									//console.log(" prodSplit[t3] "+prodSplit[t3]+" ------> "+prodSplit[t2]+" -------- > "+t8[0]);
									if(t8[0]==prodSplit[t2])
									{
									//console.log(" followSet[i] "+followSet[i]+" ------> "+prodSplit[t2]+" -------- > "+t8[0]);
										followSet[i]=followSet[i]+" "+prodSplit[t3];
									}
									else //else apple
									{
										var t9;
										t9=0;
										var t10;
										t10=arrayLength(followSet);
										while(t9 < t10)
										{
											var t11;
											t11=split(trim(followSet[t9]));
											if(t11[0]==prodSplit[t2])
											{
												if((indexOf(followSet[t9],prodSplit[t3])) < 0)
												{
													//console.log("&&&&&&&&&&&& "+followSet[t9]+" $$$$$$$ "+prodSplit[t3]);
													followSet[t9]=followSet[t9]+" "+prodSplit[t3];
												}
											}
											t9=t9+1;
										}
									} //else apple
								} //if mango
							//}			
						}//if carrot

						else //beans
						{
						//S A B
							if((indexOf(finalNonTerminals,prodSplit[t3])) > -1) //if beetroot
							{
							
								var firstofNT;
								firstofNT=getFirst(prodSplit[t3],finalfinalFirstSet);
								
								var t22;
								t22=0;
								var t23;
								t23=arrayLength(followSet);
								while(t22 < t23)
								{
									var t24;
									t24=split(trim(followSet[t22]));
									if(t24[0]==prodSplit[t2]) // watermelon
									{
										var t25;
										t25=split(trim(firstofNT));
										var t26;
										t26=0;
										var t27;
										t27=arrayLength(t25);
										while(t26 < t27)
										{
											if((indexOf(followSet[t22],t25[t26])) < 0)
											{
											// console.log("$$$$$$$$$ prodSplit[t3] "+t25[t26]);
												followSet[t22]=followSet[t22]+" "+t25[t26];
											}
										t26=t26+1;
										}
									}  // watermelon
									t22=t22+1;
								}							
								
							} //beetroot
						
						
						} //beans
				
					}  //if peas
				} //if brinjal
				
				if( (t2+1) == prodSplitLen)
				{
					if((indexOf(finalNonTerminals,prodSplit[t2])) > -1)
					{
						var t12;
						t12=0;
						var t13;
						t13=arrayLength(followSet);
						var mainNt;
						mainNt=prodSplit[0];
						while(t12 < t13)
						{
							var t17;
							t17=split(trim(followSet[t12]));
							if(t17[0]==mainNt)
							{
								var followStr;
								followStr="";
								var temp;
								temp=split(trim(followSet[t12]));
								var tempLen;
								tempLen=arrayLength(temp);
								var temp1;
								temp1=1;
								while(temp1 < tempLen)
								{
									
									followStr=followStr+temp[temp1]+" ";
									
									temp1=temp1+1;
								}
								//followStr=subString(followSet[t12],1,125);
								
								var t14;
								t14=0;
								var t15;
								t15=arrayLength(followSet);
								while(t14 < t15)
								{
									var t16;
									t16=split(trim(followSet[t14]));
									if(t16[0]==prodSplit[t2])
									{
										var t20;
										t20=split(trim(followStr));
										var t21;
										t21=arrayLength(t20);
										var t19;
										t19=0;
										while(t19 < t21)
										{
											//console.log(followStr+" ======== "+followSet[t14]+" ***** "+t20[t19]);
											if((indexOf(followSet[t14],t20[t19]))< 0)
											{
												followSet[t14]=followSet[t14]+" "+t20[t19];
											}
											t19=t19+1;
										}

									}
									t14=t14+1;
								}
							}
							t12=t12+1;
						}
					}				
				}
				
				t2=t2+1;
			}
	
		} //one if
			//console.log(" t1 = "+t1);
		t1=t1+1;
	
	}
	//console.log(" t6 = "+t6);
	t6=t6+1;
}

//NULLDERIVES of Follow Set

var t40;
t40=0;
var t41;
t41=productionsArray.count;
var flag;

while(t40 < t41) //banana
{
	var pSplit;
	pSplit=split(trim(productionsArray[t40]));
	var pSplitLen;
	pSplitLen=arrayLength(pSplit);
	var t42;
	t42=1;
	
	while(t42 < pSplitLen) //blueberry
	{
		flag=true;
		var t43;
		t43=t42+1;
		if(t43 < pSplitLen) //pepper
		{
			while((indexOf(nullDerives,pSplit[t43]))> -1) //carrot
			{
			//console.log(" ....."+pSplit[t43]+"....");
						//add follow to follow
							if((t43+1) == pSplitLen) //sweet potato
							{
								
								var t60;
								t60=pSplit[0];
								var t61;
								t61=0;
								var t62;
								t62=arrayLength(followSet);
				
								while(t61 < t62)
								{
									var t63;
									t63=split(trim(followSet[t61]));
									
									if(t63[0]==t60)
									{
										var fStr;
										fStr="";
										var fStr1;
										fStr1=split(trim(followSet[t61]));
										var fStrLen;
										fStrLen=arrayLength(fStr1);
										var mad;
										mad=1;
										while(mad < fStrLen)
										{
											fStr=fStr+fStr1[mad]+" ";
										
											mad=mad+1;
										}
										
										
										var t64;
										t64=0;
										while( t64 < t62)
										{
											var t65;
											t65=split(trim(followSet[t64]));
											//console.log("here "+fStr);
											if(t65[0]==pSplit[t42])
											{
												var time;
												time=followSet[t64];
												followSet[t64]=time+" "+fStr;
												
											}
											//console.log("&&&&&&&&&&&&&&&&&");
						
											t64=t64+1;	
										}
				
									}
									t61=t61+1;
								}
								
							} //sweet potato
		
				if((t43+1) < pSplitLen)
				{
					if((indexOf(finalNonTerminals,pSplit[(t43+1)]))> -1)//pumpkin
					{
					
						//console.log(pSplit[t43+1]);
						var t44;
						t44=getFirst(pSplit[t43+1],finalfinalFirstSet);
						//console.log(t44);
						
						// add it to follow	
						var t45;
						t45=0;
						var t46;
						t46=arrayLength(followSet);
						while(t45 < t46) //chillies
						{
							
							var t47;
							t47=split(trim(followSet[t45]));
							
							if( t47[0]==pSplit[t42])
							{
							//console.log("**** "+followSet[t45]);
								var t48;
								t48=split(trim(t44));
								var t49;
								t49=0;
								var t50;
								t50=arrayLength(t48);
								while(t49< t50)
								{
									//if((indexOf(followSet[45],t48[t49]))< -1)
									//{								
										followSet[t45]=followSet[t45]+" "+t44;
									//}
									t49=t49+1;
								}
							
							}
							t45=t45+1;
						} //chillies
					}//pumpkin
					else{

						if((indexOf(finalTerminals,pSplit[(t43+1)]))> -1)//spinach
						{
						//Add to pSplit[t42]
						
							var d1;
							d1=0;
							var d2;
							d2=arrayLength(followSet);
							while( d1 < d2)
							{
								var d3;
								d3=split(trim(followSet[d1]));
								if(d3[0]==pSplit[t42])
								{
									followSet[d1]=(trim(followSet[d1]))+" "+pSplit[(t43+1)];
								}
								d1=d1+1;
							}
					
						}//spinach
					}
				}
				else{
					flag=false;
					// S A B C
				}
				
				if(flag)
				{
					if( (t43+1) < pSplitLen)
					{
						t43=t43+1;	
	
					}
					else{
						break;
					}
				}else
				{
					break;
				
				}
			} // carrot
			
			//Code in draft 2
			
			
		} //pepper
		t42=t42+1;
		flag=true;
	} //blueberry
	t40=t40+1;
} //banana

//ADDING FOLLOW TO FOLLOW
//tryingToFixhw14
t1=arrayLength(followSet);
var m;
m=0;
while(m <t1)
{
	var s11;
	s11=0;
	var s12;
	s12=split(trim(followSet[m]));
	var s13;
	s13=arrayLength(s12);
	var strToDisp;
	strToDisp="";
	while(s11 < s13)
	{
		if( s11 == 0)
		{
			strToDisp=s12[s11]+": ";
		}else
		{
			if((indexOf(strToDisp,s12[s11]))< 0)
			{
				strToDisp=(trim(strToDisp))+" "+s12[s11]+" ";
			}
		
		}
	
		s11=s11+1;
	}
	console.log(strToDisp);
	m=m+1;
}

//adding those non terminals which do not have follow
var h1;
h1=split(trim(finalNonTerminals));
var h2;
h2=0;
var h3;
h3=arrayLength(h1);
var presentFlag;

var add;
add=arrayLength(followSet);
while( h2 < h3)
{
	var h4;
	h4=0;
	var h5;
	h5=arrayLength(followSet);
	presentFlag=false;
	while(h4 < h5)
	{
		var h6;
		h6=split(trim(followSet[h4]));
	//	console.log(h1[h2]);
		if(h1[h2]==h6[0])
		{
			presentFlag=true;
		}
		h4=h4+1;
	}
	
	if(!presentFlag)
	{
	
		followSet[add]=h1[h2]+":";
		console.log(followSet[add]);
		add=add+1;
	}

 
 h2=h2+1;
}





console.log(" ");


var getFollow;

getFollow=function(nonTerminal, followSet){

		var follow;

		follow="";

		var arrLenFollow;

		arrLenFollow=arrayLength(followSet);

		var tempF;

		tempF=0;

		while(tempF < arrLenFollow){

			var strF;

			strF=split(followSet[tempF]);

			if(strF[0]==nonTerminal){
			
			var v1F;
			v1F=split(trim(followSet[tempF]));
			var v2F;
			v2F=1;
			var v3F;
			v3F=arrayLength(v1F);
			while(v2F < v3F)
			{
								
				follow=follow+v1F[v2F]+" ";
				v2F=v2F+1;
				
			}
		}
		tempF=tempF+1;

		}

	return follow;

};




//------------------------------------------------------------------------------------------------------------------------------------------------

var predictSet;
predictSet={};

var n1;
n1=productionsArray.count;
var n2;
n2=0;
while(n2 < n1)//gauva
{

	var n3;
	n3=split(trim(productionsArray[n2]));
	var n8;
	n8=arrayLength(n3);
	var n4;
	n4=arrayLength(n3);
	var g;
	g="";
	if(n8 > 1) //purple
	{

		if((indexOf(finalNonTerminals,n3[1])) > -1) //brown
		{
			//console.log(" n2= "+productionsArray[n2]);
			g=getFirst(n3[1],finalfinalFirstSet);
				
			if((indexOf(nullDerives,n3[1])) > -1) //gray
			{
			
				var n5;
				n5=1;
				while((indexOf(nullDerives, n3[n5]))> -1) //black
				{
					
					
					//add follow to follow
					if((n5+1) == n4) //potato
					{
								
						var n60;
						n60=n3[0];
						var n61;
						n61=getFollow(n60,followSet);
						g=g+" "+n61;
						
						
					} //potato
				
					
					if((n5+1) < n4)
					{
					
						if((indexOf(finalNonTerminals,n3[(n5+1)])) > -1) //brown
						{
						
							var h;
							h=getFirst(n3[n5+1],finalfinalFirstSet);
							g=g+" "+h;
						}
						else
						{
							if((indexOf(finalTerminals,n3[(n5+1)])) > -1) //brown
							{
								g=g+" "+n3[(n5+1)];
							}
						
						}					
					}
				
					if( (n5+1) < n4)
					{
						n5=n5+1;
					}else
					{
						
						break;
					}
				}//black
				
			}//gray
		
		} //brown
			
		else
		{
			g=g+" "+n3[1];
		}
		
		//console.log(" ^^^^^^^ ");
	} //purple
	else
	{
	
	//add follow 
		var n70;
		n70=n3[0];
		var n71;
		n71=getFollow(n70,followSet);
		g=g+" "+n71;
	
	
	}

	//console.log("****** "+ productionsArray[n2]+" >>>> "+g);
	predictSet[productionsArray[n2]]=g;
	n2=n2+1;
} //gauva


console.log("Predict Sets");
console.log("");

var finalPredictSet;
finalPredictSet={};

var p1;
p1=0;
var p2;
p2=productionsArray.count;
while(p1< p2)
{
	var prodForPredict;
	prodForPredict=trim(productionsArray[p1]);

	console.log(productionsArray[p1]);
	var predictVal;
	predictVal=predictSet[prodForPredict];
	
	var predictValue;
	predictValue="";
	var z1;
	z1=0;
	var z2;
	z2=split(trim(predictVal));
	var z3;
	z3=arrayLength(z2);
	while(z1 < z3)
	{
		if((indexOf(predictValue,z2[z1]))< 0)
		{
			predictValue=(trim(predictValue))+" "+z2[z1]+" ";
		
		}
	
		z1=z1+1;
	}
	
	finalPredictSet[prodForPredict]=predictValue;
	console.log(trim(predictValue));
		console.log(" ");
	p1=p1+1;
}
//console.log("");

var getPredict;

getPredict=function(production, finalPredictSet){

		var predictAns;

		predictAns=finalPredictSet[production];

	return predictAns;

};










//--------------------------------------------------------------------------------------------------------------------------

var a1;
a1=productionsArray.count;
var a2;
a2=0;
var ll1Flag;
ll1Flag=true;

while(a2 < a1) //coconut
{
	var a3;
	a3=split(trim(productionsArray[a2]));
	var ll1;
	ll1="";
	
	var a16;
	a16=getPredict(productionsArray[a2],finalPredictSet);
	ll1=a16;
	
	var a5;
	a5=a2+1;
	while((a5) < a1)
	{
		var a4;
		a4=split(trim(productionsArray[a5]));
		//console.log(" ****** "+a3[0]+" ===== "+a4[0]);
		if(a3[0]==a4[0]) //daffodil
		{
			var a6;
			a6=getPredict(productionsArray[a5],finalPredictSet);
			//console.log("))))) "+a6);
			var a7;
			a7=split(trim(a6));
			var a8;
			a8=0;
			var a9;
			a9=arrayLength(a7);
			while(a8 < a9)
			{
			 	//console.log(" .... "+ll1+" ...."+a7[a8]+"*****");

				if(!(a7[a8] == ""))
			 	{
					if((indexOf(ll1,a7[a8]))< 0)
					{
					
						ll1=ll1+" "+a7[a8];
					}else{
					//console.log("$$$$$$");
				
					ll1Flag=false;
				
				}
				
				}
				
				if(ll1Flag)
				{
					if((a8+1) < a9)
					{
						a8=a8+1;
					}else
					{
						break;
					}	
				}
				else{
					break;
				}
			}
	
		}//daffodil
		a5=a5+1;
	}


	if(ll1Flag)
	{
		if((a2+1) <a1)
		{
			a2=a2+1;
		}
		else
		{
			break;
		}
	}else{
		break;
	}


} //coconut

if(ll1Flag)
{
	console.log("The grammar is LL(1).");
}
else
{
	console.log("The grammar is NOT LL(1).");
}

