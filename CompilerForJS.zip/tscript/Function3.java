import ts.Message;
import ts.support.*;
public class Function3 implements TSCode{

public TSValue execute(boolean isConstructorCall, TSValue ths, TSValue[] args, TSEnvironment env) {

    Message.setLineNumber(1431);
    TSValue var_predictAns_1 =TSUndefined.value;
TSValue[] params=new TSValue[0];

 TSValue formal_production_1 = (0 < args.length ? args[0] : TSUndefined.value);

 TSValue formal_finalPredictSet_1 = (1 < args.length ? args[1] : TSUndefined.value);
    Message.setLineNumber(1433);
    Message.setLineNumber(1433);
    TSValue temp3251 = formal_finalPredictSet_1;
    
 TSValue temp3254 = temp3251;
 String temp3253= "null";
    TSValue temp3255 = formal_production_1;
    TSValue temp3252=temp3254.get((TSValue.make(temp3255)).toStr().getInternal());
    Message.setLineNumber(1433);
    var_predictAns_1 = temp3252;
        TSValue temp3256 = var_predictAns_1;
    if(true)
	 return TSValue.make(temp3256);
return TSUndefined.value;

   }
}
