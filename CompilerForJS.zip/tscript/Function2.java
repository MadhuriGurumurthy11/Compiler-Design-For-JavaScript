import ts.Message;
import ts.support.*;
public class Function2 implements TSCode{

public TSValue execute(boolean isConstructorCall, TSValue ths, TSValue[] args, TSEnvironment env) {

    Message.setLineNumber(1240);
    TSValue var_strF_1 =TSUndefined.value;
    Message.setLineNumber(1246);
    TSValue var_v1F_1 =TSUndefined.value;
    Message.setLineNumber(1248);
    double var_v2F_1 =0;
    Message.setLineNumber(1234);
    double var_tempF_1 =0;
    Message.setLineNumber(1250);
    TSValue var_v3F_1 =TSUndefined.value;
    Message.setLineNumber(1230);
    TSValue var_arrLenFollow_1 =TSUndefined.value;
    Message.setLineNumber(1226);
    String var_follow_1 ="";
TSValue[] params=new TSValue[0];

 TSValue formal_nonTerminal_1 = (0 < args.length ? args[0] : TSUndefined.value);

 TSValue formal_followSet_1 = (1 < args.length ? args[1] : TSUndefined.value);
    Message.setLineNumber(1228);
    String temp2830 = "";
    Message.setLineNumber(1228);
    var_follow_1 = temp2830;
    Message.setLineNumber(1232);
    Message.setLineNumber(1232);
    TSValue temp2834 = formal_followSet_1;
TSValue[] temp2835 = {    (TSValue.make(temp2834))};;TSValue temp2832 = TSObject.getGlobalObject().get("arrayLength");
if(temp2832==null){
 throw new TSException(TSValue.make("undefined identifier:arrayLength"));
 }
    TSValue temp2833 = temp2832;
TSValue temp2836 = TSValue.make(temp2833).callFunction( false, null,temp2835);
    Message.setLineNumber(1232);
    var_arrLenFollow_1 = temp2836;
    Message.setLineNumber(1236);
    double temp2838 = 0.0;
    Message.setLineNumber(1236);
    var_tempF_1 = temp2838;
    Message.setLineNumber(1238);
while(true){    double temp2899 = var_tempF_1;
    TSValue temp2900 = var_arrLenFollow_1;
    Message.setLineNumber(1238);
    TSValue temp2901 = (TSValue.make(temp2899)).lesserThan(TSValue.make(temp2900));
if(temp2901.toBoolean().getInternal() == false)break;
if (temp2901.toBoolean().getInternal() == true){{    Message.setLineNumber(1238);
    
        Message.setLineNumber(1242);
    Message.setLineNumber(1242);
    Message.setLineNumber(1242);
    TSValue temp2842 = formal_followSet_1;
    
 TSValue temp2845 = temp2842;
 String temp2844= "null";
    double temp2846 = var_tempF_1;
    TSValue temp2843=temp2845.get((TSValue.make(temp2846)).toStr().getInternal());
TSValue[] temp2847 = {    (TSValue.make(temp2843))};;TSValue temp2840 = TSObject.getGlobalObject().get("split");
if(temp2840==null){
 throw new TSException(TSValue.make("undefined identifier:split"));
 }
    TSValue temp2841 = temp2840;
TSValue temp2848 = TSValue.make(temp2841).callFunction( false, null,temp2847);
    Message.setLineNumber(1242);
    var_strF_1 = temp2848;

        
 Message.setLineNumber(1244);
        Message.setLineNumber(1244);
    TSValue temp2849 = var_strF_1;
    
 TSValue temp2852 = temp2849;
 String temp2851= "null";
    double temp2853 = 0.0;
    TSValue temp2850=temp2852.get((TSValue.make(temp2853)).toStr().getInternal());
    TSValue temp2854 = formal_nonTerminal_1;
    Message.setLineNumber(1244);
    TSValue temp2855 = (TSValue.make(temp2850)).equals(TSValue.make(temp2854));

 if(temp2855.toBoolean().getInternal()==true){{    Message.setLineNumber(1244);
    
        Message.setLineNumber(1247);
    Message.setLineNumber(1247);
    Message.setLineNumber(1247);
    Message.setLineNumber(1247);
    TSValue temp2861 = formal_followSet_1;
    
 TSValue temp2864 = temp2861;
 String temp2863= "null";
    double temp2865 = var_tempF_1;
    TSValue temp2862=temp2864.get((TSValue.make(temp2865)).toStr().getInternal());
TSValue[] temp2866 = {    (TSValue.make(temp2862))};;TSValue temp2859 = TSObject.getGlobalObject().get("trim");
if(temp2859==null){
 throw new TSException(TSValue.make("undefined identifier:trim"));
 }
    TSValue temp2860 = temp2859;
TSValue temp2867 = TSValue.make(temp2860).callFunction( false, null,temp2866);
TSValue[] temp2868 = {    (TSValue.make(temp2867))};;TSValue temp2857 = TSObject.getGlobalObject().get("split");
if(temp2857==null){
 throw new TSException(TSValue.make("undefined identifier:split"));
 }
    TSValue temp2858 = temp2857;
TSValue temp2869 = TSValue.make(temp2858).callFunction( false, null,temp2868);
    Message.setLineNumber(1247);
    var_v1F_1 = temp2869;

    
        Message.setLineNumber(1249);
    double temp2871 = 1.0;
    Message.setLineNumber(1249);
    var_v2F_1 = temp2871;

    
        Message.setLineNumber(1251);
    Message.setLineNumber(1251);
    TSValue temp2875 = var_v1F_1;
TSValue[] temp2876 = {    (TSValue.make(temp2875))};;TSValue temp2873 = TSObject.getGlobalObject().get("arrayLength");
if(temp2873==null){
 throw new TSException(TSValue.make("undefined identifier:arrayLength"));
 }
    TSValue temp2874 = temp2873;
TSValue temp2877 = TSValue.make(temp2874).callFunction( false, null,temp2876);
    Message.setLineNumber(1251);
    var_v3F_1 = temp2877;

        Message.setLineNumber(1252);
while(true){    double temp2892 = var_v2F_1;
    TSValue temp2893 = var_v3F_1;
    Message.setLineNumber(1252);
    TSValue temp2894 = (TSValue.make(temp2892)).lesserThan(TSValue.make(temp2893));
if(temp2894.toBoolean().getInternal() == false)break;
if (temp2894.toBoolean().getInternal() == true){{    Message.setLineNumber(1253);
        Message.setLineNumber(1255);
    String temp2879 = var_follow_1;
    Message.setLineNumber(1255);
    TSValue temp2880 = var_v1F_1;
    
 TSValue temp2883 = temp2880;
 String temp2882= "null";
    double temp2884 = var_v2F_1;
    TSValue temp2881=temp2883.get((TSValue.make(temp2884)).toStr().getInternal());
    String temp2885 = temp2879 + temp2881.toStr().getInternal();
    String temp2886 = " ";
    String temp2887 = temp2885 + temp2886;
    Message.setLineNumber(1255);
    var_follow_1 = temp2887;

        Message.setLineNumber(1256);
    double temp2889 = var_v2F_1;
    double temp2890 = 1.0;
    double temp2891 = temp2889 + temp2890;
    Message.setLineNumber(1256);
    var_v2F_1 = temp2891;

}}
 }

}}

        Message.setLineNumber(1260);
    double temp2896 = var_tempF_1;
    double temp2897 = 1.0;
    double temp2898 = temp2896 + temp2897;
    Message.setLineNumber(1260);
    var_tempF_1 = temp2898;

}}
 }
        String temp2902 = var_follow_1;
    if(true)
	 return TSValue.make(temp2902);
return TSUndefined.value;

   }
}
