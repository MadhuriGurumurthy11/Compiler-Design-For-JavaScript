// "the meaning of life, the universe, and everything"
//
// Among many compiler writers the tradition is that the first program
// you compile with your new compiler produces a single output, 42.

console.log(42);

