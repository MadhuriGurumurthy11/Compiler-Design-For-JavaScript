// test a variable that is never assigned to

var x;

console.log(x);

console.log(x+1);

