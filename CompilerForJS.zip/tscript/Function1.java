import ts.Message;
import ts.support.*;
public class Function1 implements TSCode{

public TSValue execute(boolean isConstructorCall, TSValue ths, TSValue[] args, TSEnvironment env) {

    Message.setLineNumber(677);
    TSValue var_str_1 =TSUndefined.value;
    Message.setLineNumber(683);
    TSValue var_v1_1 =TSUndefined.value;
    Message.setLineNumber(685);
    double var_v2_1 =0;
    Message.setLineNumber(687);
    TSValue var_v3_1 =TSUndefined.value;
    Message.setLineNumber(663);
    String var_first_1 ="";
    Message.setLineNumber(671);
    double var_temp_1 =0;
    Message.setLineNumber(667);
    TSValue var_arrLen_1 =TSUndefined.value;
TSValue[] params=new TSValue[0];

 TSValue formal_nonTerminal_1 = (0 < args.length ? args[0] : TSUndefined.value);

 TSValue formal_finalfinalFirstSet_1 = (1 < args.length ? args[1] : TSUndefined.value);
    Message.setLineNumber(665);
    String temp1542 = "";
    Message.setLineNumber(665);
    var_first_1 = temp1542;
    Message.setLineNumber(669);
    Message.setLineNumber(669);
    TSValue temp1546 = formal_finalfinalFirstSet_1;
TSValue[] temp1547 = {    (TSValue.make(temp1546))};;TSValue temp1544 = TSObject.getGlobalObject().get("arrayLength");
if(temp1544==null){
 throw new TSException(TSValue.make("undefined identifier:arrayLength"));
 }
    TSValue temp1545 = temp1544;
TSValue temp1548 = TSValue.make(temp1545).callFunction( false, null,temp1547);
    Message.setLineNumber(669);
    var_arrLen_1 = temp1548;
    Message.setLineNumber(673);
    double temp1550 = 0.0;
    Message.setLineNumber(673);
    var_temp_1 = temp1550;
    Message.setLineNumber(675);
while(true){    double temp1611 = var_temp_1;
    TSValue temp1612 = var_arrLen_1;
    Message.setLineNumber(675);
    TSValue temp1613 = (TSValue.make(temp1611)).lesserThan(TSValue.make(temp1612));
if(temp1613.toBoolean().getInternal() == false)break;
if (temp1613.toBoolean().getInternal() == true){{    Message.setLineNumber(675);
    
        Message.setLineNumber(679);
    Message.setLineNumber(679);
    Message.setLineNumber(679);
    TSValue temp1554 = formal_finalfinalFirstSet_1;
    
 TSValue temp1557 = temp1554;
 String temp1556= "null";
    double temp1558 = var_temp_1;
    TSValue temp1555=temp1557.get((TSValue.make(temp1558)).toStr().getInternal());
TSValue[] temp1559 = {    (TSValue.make(temp1555))};;TSValue temp1552 = TSObject.getGlobalObject().get("split");
if(temp1552==null){
 throw new TSException(TSValue.make("undefined identifier:split"));
 }
    TSValue temp1553 = temp1552;
TSValue temp1560 = TSValue.make(temp1553).callFunction( false, null,temp1559);
    Message.setLineNumber(679);
    var_str_1 = temp1560;

        
 Message.setLineNumber(681);
        Message.setLineNumber(681);
    TSValue temp1561 = var_str_1;
    
 TSValue temp1564 = temp1561;
 String temp1563= "null";
    double temp1565 = 0.0;
    TSValue temp1562=temp1564.get((TSValue.make(temp1565)).toStr().getInternal());
    TSValue temp1566 = formal_nonTerminal_1;
    Message.setLineNumber(681);
    TSValue temp1567 = (TSValue.make(temp1562)).equals(TSValue.make(temp1566));

 if(temp1567.toBoolean().getInternal()==true){{    Message.setLineNumber(681);
    
        Message.setLineNumber(684);
    Message.setLineNumber(684);
    Message.setLineNumber(684);
    Message.setLineNumber(684);
    TSValue temp1573 = formal_finalfinalFirstSet_1;
    
 TSValue temp1576 = temp1573;
 String temp1575= "null";
    double temp1577 = var_temp_1;
    TSValue temp1574=temp1576.get((TSValue.make(temp1577)).toStr().getInternal());
TSValue[] temp1578 = {    (TSValue.make(temp1574))};;TSValue temp1571 = TSObject.getGlobalObject().get("trim");
if(temp1571==null){
 throw new TSException(TSValue.make("undefined identifier:trim"));
 }
    TSValue temp1572 = temp1571;
TSValue temp1579 = TSValue.make(temp1572).callFunction( false, null,temp1578);
TSValue[] temp1580 = {    (TSValue.make(temp1579))};;TSValue temp1569 = TSObject.getGlobalObject().get("split");
if(temp1569==null){
 throw new TSException(TSValue.make("undefined identifier:split"));
 }
    TSValue temp1570 = temp1569;
TSValue temp1581 = TSValue.make(temp1570).callFunction( false, null,temp1580);
    Message.setLineNumber(684);
    var_v1_1 = temp1581;

    
        Message.setLineNumber(686);
    double temp1583 = 1.0;
    Message.setLineNumber(686);
    var_v2_1 = temp1583;

    
        Message.setLineNumber(688);
    Message.setLineNumber(688);
    TSValue temp1587 = var_v1_1;
TSValue[] temp1588 = {    (TSValue.make(temp1587))};;TSValue temp1585 = TSObject.getGlobalObject().get("arrayLength");
if(temp1585==null){
 throw new TSException(TSValue.make("undefined identifier:arrayLength"));
 }
    TSValue temp1586 = temp1585;
TSValue temp1589 = TSValue.make(temp1586).callFunction( false, null,temp1588);
    Message.setLineNumber(688);
    var_v3_1 = temp1589;

        Message.setLineNumber(689);
while(true){    double temp1604 = var_v2_1;
    TSValue temp1605 = var_v3_1;
    Message.setLineNumber(689);
    TSValue temp1606 = (TSValue.make(temp1604)).lesserThan(TSValue.make(temp1605));
if(temp1606.toBoolean().getInternal() == false)break;
if (temp1606.toBoolean().getInternal() == true){{    Message.setLineNumber(690);
        Message.setLineNumber(692);
    String temp1591 = var_first_1;
    Message.setLineNumber(692);
    TSValue temp1592 = var_v1_1;
    
 TSValue temp1595 = temp1592;
 String temp1594= "null";
    double temp1596 = var_v2_1;
    TSValue temp1593=temp1595.get((TSValue.make(temp1596)).toStr().getInternal());
    String temp1597 = temp1591 + temp1593.toStr().getInternal();
    String temp1598 = " ";
    String temp1599 = temp1597 + temp1598;
    Message.setLineNumber(692);
    var_first_1 = temp1599;

        Message.setLineNumber(693);
    double temp1601 = var_v2_1;
    double temp1602 = 1.0;
    double temp1603 = temp1601 + temp1602;
    Message.setLineNumber(693);
    var_v2_1 = temp1603;

}}
 }

}}

        Message.setLineNumber(697);
    double temp1608 = var_temp_1;
    double temp1609 = 1.0;
    double temp1610 = temp1608 + temp1609;
    Message.setLineNumber(697);
    var_temp_1 = temp1610;

}}
 }
        String temp1614 = var_first_1;
    if(true)
	 return TSValue.make(temp1614);
return TSUndefined.value;

   }
}
