import ts.Message;
import ts.support.*;
public class Function1 implements TSCode{

public TSValue execute(boolean isConstructorCall, TSValue ths, TSValue[] args, TSEnvironment env) {

    Message.setLineNumber(544);
    TSValue var_str_1 =TSUndefined.value;
    Message.setLineNumber(538);
    double var_temp_1 =0;
    Message.setLineNumber(534);
    TSValue var_arrLen_1 =TSUndefined.value;
    Message.setLineNumber(530);
    TSValue var_first_1 =TSUndefined.value;
TSValue[] params=new TSValue[0];

 TSValue formal_nonTerminal_1 = (0 < args.length ? args[0] : TSUndefined.value);

 TSValue formal_finalFirstSet_1 = (1 < args.length ? args[1] : TSUndefined.value);
    Message.setLineNumber(532);
    String temp1233 = "";
    TSValue temp1234 = TSValue.make(temp1233);
    Message.setLineNumber(532);
    var_first_1 = temp1234;
    Message.setLineNumber(536);
    Message.setLineNumber(536);
    TSValue temp1238 = formal_finalFirstSet_1;
TSValue[] temp1239 = {    (TSValue.make(temp1238))};;TSValue temp1236 = TSObject.getGlobalObject().get("arrayLength");
if(temp1236==null){
 throw new TSException(TSValue.make("undefined identifier:arrayLength"));
 }
    TSValue temp1237 = temp1236;
TSValue temp1240 = TSValue.make(temp1237).callFunction( false, null,temp1239);
    Message.setLineNumber(536);
    var_arrLen_1 = temp1240;
    Message.setLineNumber(540);
    double temp1242 = 0.0;
    Message.setLineNumber(540);
    var_temp_1 = temp1242;
    Message.setLineNumber(542);
while(true){    double temp1276 = var_temp_1;
    TSValue temp1277 = var_arrLen_1;
    Message.setLineNumber(542);
    TSValue temp1278 = (TSValue.make(temp1276)).lesserThan(TSValue.make(temp1277));
if(temp1278.toBoolean().getInternal() == false)break;
if (temp1278.toBoolean().getInternal() == true){{    Message.setLineNumber(542);
    
        Message.setLineNumber(546);
    Message.setLineNumber(546);
    Message.setLineNumber(546);
    TSValue temp1246 = formal_finalFirstSet_1;
    
 TSValue temp1249 = temp1246;
 String temp1248= "null";
    double temp1250 = var_temp_1;
    TSValue temp1247=temp1249.get((TSValue.make(temp1250)).toStr().getInternal());
TSValue[] temp1251 = {    (TSValue.make(temp1247))};;TSValue temp1244 = TSObject.getGlobalObject().get("split");
if(temp1244==null){
 throw new TSException(TSValue.make("undefined identifier:split"));
 }
    TSValue temp1245 = temp1244;
TSValue temp1252 = TSValue.make(temp1245).callFunction( false, null,temp1251);
    Message.setLineNumber(546);
    var_str_1 = temp1252;

        
 Message.setLineNumber(548);
        Message.setLineNumber(548);
    TSValue temp1253 = var_str_1;
    
 TSValue temp1256 = temp1253;
 String temp1255= "null";
    double temp1257 = 0.0;
    TSValue temp1254=temp1256.get((TSValue.make(temp1257)).toStr().getInternal());
    TSValue temp1258 = formal_nonTerminal_1;
    Message.setLineNumber(548);
    TSValue temp1259 = (TSValue.make(temp1254)).equals(TSValue.make(temp1258));

 if(temp1259.toBoolean().getInternal()==true){{    Message.setLineNumber(548);
        Message.setLineNumber(550);
    Message.setLineNumber(550);
    Message.setLineNumber(550);
    TSValue temp1263 = formal_finalFirstSet_1;
    
 TSValue temp1266 = temp1263;
 String temp1265= "null";
    double temp1267 = var_temp_1;
    TSValue temp1264=temp1266.get((TSValue.make(temp1267)).toStr().getInternal());
    double temp1268 = 4.0;
    double temp1269 = 125.0;
TSValue[] temp1270 = {    (TSValue.make(temp1264)), (TSValue.make(temp1268)), (TSValue.make(temp1269))};;TSValue temp1261 = TSObject.getGlobalObject().get("subString");
if(temp1261==null){
 throw new TSException(TSValue.make("undefined identifier:subString"));
 }
    TSValue temp1262 = temp1261;
TSValue temp1271 = TSValue.make(temp1262).callFunction( false, null,temp1270);
    Message.setLineNumber(550);
    var_first_1 = temp1271;

}}

        Message.setLineNumber(553);
    double temp1273 = var_temp_1;
    double temp1274 = 1.0;
    double temp1275 = temp1273 + temp1274;
    Message.setLineNumber(553);
    var_temp_1 = temp1275;

}}
 }
        TSValue temp1279 = var_first_1;
    if(true)
	 return TSValue.make(temp1279);
return TSUndefined.value;

   }
}
