package ts.tree;

/**
 * enum for binary operator names
 *
 */
public enum Binop {
	ADD, SUBTRACT, ASSIGN, MULTIPLY, DIVISION, LESSTHAN, GREATERTHAN, EQUALS
}
