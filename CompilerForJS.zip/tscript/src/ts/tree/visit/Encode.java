/**
l * Traverse an AST to generate Java code.
 *
 */

package ts.tree.visit;

import ts.Message;
import ts.support.TSEnvironment;
import ts.support.TSException;
import ts.support.TSNumber;
import ts.support.TSObject;
import ts.support.TSString;
import ts.support.TSValue;
import ts.tree.*;
import ts.tree.type.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Does a traversal of the AST to generate Java code to execute the program
 * represented by the AST.
 * <p>
 * Uses a static nested class, Encode.ReturnValue, for the type parameter. This
 * class contains two String fields: one for the temporary variable containing
 * the result of executing code for an AST node; one for the code generated for
 * the AST node.
 * <p>
 * The "visit" method is overloaded for each tree node type.
 */
public final class Encode extends TreeVisitorBase<Encode.ReturnValue> {

	int functionCounter = 0;
	// List<VarStatement> symbolTable = new ArrayList<VarStatement>();
	int nestedFunctionNo = 0;

	public ArrayList<String> functionList = new ArrayList<String>();

	/**
	 * Static nested class to represent the return value of the Encode methods.
	 * Contains the following fields:
	 * <ul>
	 * <li>a String containing the result operand name
	 * <li>a String containing the code to be generated
	 * </ul>
	 * Only expressions generate results, so the result operand name will be
	 * null in other cases, such as statements.
	 */
	static public class ReturnValue {
		/** the result operand name. */
		public String result;

		/** the code to be generated. */
		public String code;

		// initialize both fields
		private ReturnValue() {
			result = null;
			code = null;
		}

		/**
		 * Construct an encode return value for non-expressions.
		 *
		 * @param code
		 *            the code to be placed in the return value
		 */
		public ReturnValue(final String code) {
			this();
			this.code = code;
		}

		/**
		 * Construct an encode return value for most expressions.
		 *
		 * @param result
		 *            the result operand code.
		 * @param code
		 *            the code to be generated.
		 */
		public ReturnValue(final String result, final String code) {
			this();
			this.result = result;
			this.code = code;
		}
	}

	// simple counter for expression temps
	private int nextTemp = 0;

	/**
	 * Initiate an encode traversal with the output indented two spaces and the
	 * increment indentation amount set to two spaces.
	 */
	public Encode() {
		this(2, 2);
	}

	// initial indentation value
	private final int initialIndentation;

	// current indentation amount
	private int indentation;

	// how much to increment the indentation by at each level
	// using an increment of zero would mean no indentation
	private final int increment;

	// increase indentation by one level
	private void increaseIndentation() {
		indentation += increment;
	}

	// decrease indentation by one level
	private void decreaseIndentation() {
		indentation -= increment;
	}

	/**
	 * Initiate an encode traversal with the output indented by a specific
	 * amount and the increment indentation amount set to a specific amount.
	 *
	 * @param initialIndentation
	 *            the initial indentation amount.
	 * @param increment
	 *            the increment indentation amount.
	 */
	public Encode(final int initialIndentation, final int increment) {
		// setup indentation
		this.initialIndentation = initialIndentation;
		this.indentation = initialIndentation;
		this.increment = increment;
	}

	// generate a string of spaces for current indentation level
	private String indent() {
		String ret = "";
		for (int i = 0; i < indentation; i++) {
			ret += " ";
		}
		return ret;
	}

	/**
	 * Generate the main method signature.
	 * 
	 * @return the main method signature.
	 */
	public String mainMethodSignature() {

		return "public static void main(String args[])";
	}

	/**
	 * Generate and return prologue code for the main method body.
	 *
	 * @param filename
	 *            source filename.
	 * @return the prologue code for the main method body.
	 */
	public String mainPrologue(String filename) {
		String ret = "";

		ret += indent() + "{ \n";
		ret += "\n TSObject globalObject=TSObject.getGlobalObject();\n";

		ret += "try {\n";
		// ret += indent() + "TSValue undefined=TSUndefined.value;\n";
		increaseIndentation();

		ret += "TSObject.getGlobalObject().put(\"NaN\",  TSNumber.create(Double.NaN));\n";
		ret += "TSObject.getGlobalObject().put(\"Infinity\",  TSNumber.create(Double.POSITIVE_INFINITY));\n";
		ret += "TSObject.getGlobalObject().put(\"undefined\",  TSUndefined.value);\n";

		ret += "TSObject.getGlobalObject().put(\"this\",TSValue.make(TSObject.getGlobalObject()));\n";
		ret += "TSObject.getGlobalObject().put(\"ths\",TSObject.getGlobalObject());\n";

		// ---------------------------------------------------------------------------------------------------
		ret += indent() + "TSReadLn readLnInstance = new TSReadLn( );\n";
		ret += indent()
				+ "TSFunctionObject funcReadLn = new TSFunctionObject( readLnInstance,null );\n";
		ret += indent()
				+ "TSObject.getGlobalObject().put(\"readln\", funcReadLn);\n\n";

		// ---------------------------------------------------------------------------------------------------
		ret += indent() + "TSNaN nanInstance = new TSNaN( );\n";
		ret += indent()
				+ "TSFunctionObject funcNaN = new TSFunctionObject( nanInstance, null);\n";
		ret += indent()
				+ "TSObject.getGlobalObject().put(\"isNaN\", funcNaN);\n\n";
		// ---------------------------------------------------------------------------------------------------
		ret += indent() + "TSFinite infiniteInstance = new TSFinite( );\n";

		ret += indent()
				+ "TSFunctionObject funcInfinite = new TSFunctionObject( infiniteInstance,null );\n";
		ret += indent()
				+ "TSObject.getGlobalObject().put(\"isFinite\", funcInfinite);\n\n";
		// ---------------------------------------------------------------------------------------------------

		ret += indent() + "TSTestThis testThisInstance=new TSTestThis();\n";
		ret += indent()
				+ "TSFunctionObject funcTestThis = new TSFunctionObject(testThisInstance,null );\n";

		ret += "TSObject obj = new TSObject();\n";
		ret += "obj.put(\"printXYZ\", new TSFunctionObject(new TSPrintXYZ(), null));\n";
		ret += "funcTestThis.put(\"prototype\", obj);\n";
		ret += "TSObject.getGlobalObject().put(\"testThis\",funcTestThis);\n";

		// ----------------------------------------------------------------------------------------------------
		ret += indent() + "TSStringTrim strTrim = new TSStringTrim( );\n";
		ret += indent()
				+ "TSFunctionObject strTrimFunction = new TSFunctionObject( strTrim,null);\n";

		ret += "TSObject.getGlobalObject().put(\"trim\",strTrimFunction);\n";

		// ---------------------------------------------------------------------------------------------------

		ret += indent() + "TSStringSplit stringSplit = new TSStringSplit( );\n";
		ret += indent()
				+ "TSFunctionObject splitFunction = new TSFunctionObject( stringSplit,null );\n";
		ret += "TSObject.getGlobalObject().put(\"split\",splitFunction);\n";

		// ---------------------------------------------------------------------------------------------------

		ret += indent() + "TSSubstring subString = new TSSubstring( );\n";
		ret += indent()
				+ "TSFunctionObject subStringFunction = new TSFunctionObject( subString,null);\n";

		ret += "TSObject.getGlobalObject().put(\"subString\",subStringFunction);\n";

		// ---------------------------------------------------------------------------------------------------

		ret += indent() + "TSArrayLength arrayLength = new TSArrayLength( );\n";
		ret += indent()
				+ "TSFunctionObject arrayLengthFunction = new TSFunctionObject( arrayLength,null );\n";
		ret += "TSObject.getGlobalObject().put(\"arrayLength\",arrayLengthFunction);\n";

		// ---------------------------------------------------------------------------------------------------
		ret += indent()
				+ "TSStringIndexOf strIndexOf = new TSStringIndexOf( );\n";
		ret += indent()
				+ "TSFunctionObject strIndexOfFunction = new TSFunctionObject( strIndexOf,null);\n";

		ret += "TSObject.getGlobalObject().put(\"indexOf\",strIndexOfFunction);\n";

		// --------------------------------------------------------------------------------------------------
		return ret;
	}

	/**
	 * Generate and return epilogue code for the main method body.
	 *
	 * @return the epilogue code for the main method body.
	 */
	public String mainEpilogue() {
		decreaseIndentation();
		String ret = "";
		ret += indent() + "}";
		ret += indent() + "catch(TSException e){\n";
		ret += indent()
				+ "Message.executionError(e.getEValue().toStr().getInternal());\n";
		ret += indent() + "} \n";
		ret += indent() + "} \n";
		return ret;
	}

	// return string for name of next expression temp
	private String getTemp() {
		String ret = "temp" + nextTemp;
		nextTemp += 1;
		return ret;
	}

	// given AST Type, return for the matching Java type
	private String getJavaType(Type type) {
		if (type.isNumberType()) {
			return "double";
		} else if (type.isStringType()) {
			return "String";
		}
		return "TSValue";
	}

	/**
	 * Visit a list of ASTs and generate code for each of them in order. Uses a
	 * wildcard for generality: list of Statements, list of Expressions, etc.
	 * Returns a list containing the generated code for each element of the
	 * input list.
	 */
	@Override
	public List<Encode.ReturnValue> visitEach(final Iterable<?> nodes) {
		List<Encode.ReturnValue> ret = new ArrayList<Encode.ReturnValue>();

		for (final Object node : nodes) {
			ret.add(visitNode((Tree) node));
		}
		return ret;
	}

	/** Generate and return code for a binary operator. */
	@Override
	public Encode.ReturnValue visit(final BinaryOperator binaryOperator) {

		String leftResult = "";
		String rightResult = "";
		String code = "";
		Expression left = binaryOperator.getLeft();
		Expression right = binaryOperator.getRight();
		// generate code to evaluate left subtree
		if (binaryOperator.getOp() != Binop.ASSIGN) {
			Encode.ReturnValue leftReturnValue = visitNode(left);
			code = leftReturnValue.code;
			leftResult = leftReturnValue.result;

			// generate code to evaluate right subtree
			Encode.ReturnValue rightReturnValue = visitNode(right);
			code += rightReturnValue.code;
			rightResult = rightReturnValue.result;
		}

		//
		// now generate code to do the binary operator itself
		//

		// name of Java variable to receive the result value
		String result = getTemp();

		// try to do optimized code generation first
		final Binop op = binaryOperator.getOp();
		final Type type = binaryOperator.getType();
		final String opString = binaryOperator.getOpString();

		switch (op) {

		case ADD:

			// if result type is Number then both operands are Numbers
			// so just perform Java add and leave result as a Java double
			if (type.isNumberType()) {
				code += indent() + "double " + result + " = " + leftResult
						+ " + " + rightResult + ";\n";
				return new Encode.ReturnValue(result, code);
			}

			// if result type is String, then one of the operands is a String
			// but the other might not be a String, and might even be Unknown
			if (type.isStringType()) {
				// if the type of the subtree is known now to be Number, then
				// need to convert it to a TSString in order to get the
				// Javascript conversion of Number to String because the
				// conversion is different than the Java conversion of double
				// to String.
				if (left.getType().isNumberType()) {
					leftResult = "TSNumber.create(" + leftResult + ")";
				}
				if (right.getType().isNumberType()) {
					rightResult = "TSNumber.create(" + rightResult + ")";
				}

				// if the type of a subtree is not known now to be String, then
				// need to make sure it will be converted to String if necessary
				if (!left.getType().isStringType()) {
					leftResult += ".toStr().getInternal()";
				}
				if (!right.getType().isStringType()) {
					rightResult += ".toStr().getInternal()";
				}

				// generate code to do Java string concatentation
				code += indent() + "String " + result + " = " + leftResult
						+ " + " + rightResult + ";\n";
				return new Encode.ReturnValue(result, code);
			}

			// otherwise need to do unoptimized code generation
			break;

		case SUBTRACT:

			// if result type is Number then both operands are Numbers
			// so just perform Java add and leave result as a Java double
			if (left.getType().isNumberType() && right.getType().isNumberType()) {

				code += indent() + "double " + result + " = " + leftResult
						+ " - " + rightResult + ";\n";

				code += indent() + "Message.setLineNumber("
						+ binaryOperator.getLineNumber() + ");\n";
				return new Encode.ReturnValue(result, code);
			}

			// otherwise need to do unoptimized code generation
			break;

		case ASSIGN:

			if (left instanceof PropertyAccessorExpression) {
				PropertyAccessorExpression prop = (PropertyAccessorExpression) left;

				// TODO:
				Encode.ReturnValue binLeft = visitNode(prop.getMemberExpr());
				code += binLeft.code;
				Expression binRight = binaryOperator.getRight();
				Encode.ReturnValue rightValue = visitNode(binRight);
				code += rightValue.code;
				String result1 = rightValue.result;

				String temp1 = getTemp();
				code += indent() + "\n TSValue " + temp1 + " = "
						+ binLeft.result + ";\n";

				// code += indent() + temp1 + ".put(\"" + prop.getId()
				// + "\" ,TSValue.make(" + result1 + "));\n";
				// result = result1 + "";

				if (prop.getId() != null) {
					code += indent() + temp1 + ".put(\"" + prop.getId()
							+ "\" ,TSValue.make(" + result1 + "));\n";
					result = result1 + "";
				} else {
					ReturnValue expReturnValue = visitNode(prop.getExp());
					code += expReturnValue.code;
					code += indent() + temp1 + ".put((TSValue.make("
							+ expReturnValue.result
							+ ")).toStr().getInternal() ,(TSValue.make("
							+ result1 + ")));\n";
					result = result1 + "";
				}

				return new Encode.ReturnValue(result, code);
			}

			// Need to handle assignment of Number or String to a variable
			// of ambiguous type. Need to check type of right child against
			// type of left child.
			else {

				// generate code to evaluate right subtree
				Encode.ReturnValue rightReturnValue = visitNode(right);
				code += rightReturnValue.code;
				rightResult = rightReturnValue.result;

				if (left instanceof Identifier) {

					Identifier i = (Identifier) left;

					if (i.getVarNode() != null
							&& i.getVarNode().getFunctionDepth() == 0)
						code += "\n TSObject.getGlobalObject().put(\""
								+ i.getName() + "\"" + ",TSValue.make("
								+ rightResult + "));\n";
				}

				Encode.ReturnValue leftReturnValue = visitNode(left);
				code += leftReturnValue.code;
				leftResult = leftReturnValue.result;

				if (left.getType().isUnknownType()
						&& !right.getType().isUnknownType()) {

					// need to generate code to make a TSValue and then assign
					String rightResult2 = getTemp();
					code += indent() + "TSValue " + rightResult2
							+ " = TSValue.make(" + rightResult + ");\n";
					code += indent() + "Message.setLineNumber("
							+ binaryOperator.getLineNumber() + ");\n";
					code += indent() + leftResult + " = " + rightResult2
							+ ";\n";
				} else {
					code += indent() + "Message.setLineNumber("
							+ binaryOperator.getLineNumber() + ");\n";
					// otherwise types match so just do the assignment
					code += indent() + leftResult + " = " + rightResult + ";\n";
				}
			}
			// and in either case return the value from the right child
			// which can be a Java type
			return new Encode.ReturnValue(rightResult, code);

		case MULTIPLY:

			// if the type of a subtree is not known now to be Number, then
			// need to make sure it will be converted to Number if necessary
			if (!left.getType().isNumberType()) {
				leftResult = "TSValue.make(" + leftResult
						+ ").toNumber().getInternal()";
			}
			if (!right.getType().isNumberType()) {
				rightResult = "TSValue.make(" + rightResult
						+ ").toNumber().getInternal()";
			}
			code += indent() + "Message.setLineNumber("
					+ binaryOperator.getLineNumber() + ");\n";
			// now generate a Java multiply
			code += indent() + "double " + result + " = " + leftResult + " * "
					+ rightResult + ";\n";
			return new Encode.ReturnValue(result, code);

		case DIVISION:

			// if the type of a subtree is not known now to be Number, then
			// need to make sure it will be converted to Number if necessary
			if (!left.getType().isNumberType()) {
				leftResult = "TSValue.make(" + leftResult
						+ ").toNumber().getInternal()";
				code += indent() + "Message.setLineNumber("
						+ binaryOperator.getLineNumber() + ");\n";
			}
			if (!right.getType().isNumberType()) {
				rightResult = "TSValue.make(" + rightResult
						+ ").toNumber().getInternal()";
				code += indent() + "Message.setLineNumber("
						+ binaryOperator.getLineNumber() + ");\n";
			}

			// now generate a Java multiply
			code += indent() + "double " + result + " = " + leftResult + " / "
					+ rightResult + ";\n";
			return new Encode.ReturnValue(result, code);

		case LESSTHAN:

			break;

		case GREATERTHAN:

			break;

		case EQUALS:

			break;
		// case DOT:
		// break;
		default:
			Message.bug("unexpected operator: " + opString);
		}

		//
		// if control reaches here then do unoptimized code generation
		//
		code += indent() + "Message.setLineNumber("
				+ binaryOperator.getLineNumber() + ");\n";
		// one of the subtrees might be a Java value at run-time so
		// need to generate code that will convert it to a TSValue if necessary
		String methodName = getMethodNameForBinaryOperator(binaryOperator);
		code += indent() + "TSValue " + result + " = (TSValue.make("
				+ leftResult + "))." + methodName + "(TSValue.make("
				+ rightResult + "));\n";

		return new Encode.ReturnValue(result, code);
	}

	// support routine for handling binary operators
	private static String getMethodNameForBinaryOperator(
			final BinaryOperator opNode) {
		final Binop op = opNode.getOp();

		switch (op) {
		case ADD:
			return "add";
		case SUBTRACT:
			return "subtract";
		case MULTIPLY:
			return "multiply";
		case DIVISION:
			return "divide";
		case LESSTHAN:
			return "lesserThan";
		case GREATERTHAN:
			return "greaterThan";
		case EQUALS:
			return "equals";
			// case DOT:
			// return "dot";
		default:
			Message.bug("unexpected operator: " + opNode.getOpString());
		}
		// cannot reach
		return null;
	}

	/** Generate and return code for a unary operator. */
	@Override
	public Encode.ReturnValue visit(final UnaryOperator unaryOperator) {

		// generate code to evaluate right subtree
		Expression right = unaryOperator.getRight();
		Encode.ReturnValue rightReturnValue = visitNode(right);
		String code = rightReturnValue.code;
		String rightResult = rightReturnValue.result;

		//
		// now generate code to do the unary operator itself
		//

		// name of Java variable to receive the result value
		String result = getTemp();

		// try to do optimized code generation first
		final Unop op = unaryOperator.getOp();
		final String opString = unaryOperator.getOpString();
		switch (op) {

		case LOGICALNOT:

			break;
		case UNARYMINUS:
			if (right.getType().isNumberType()) {

				// generate code to do Java string concatenation
				code += indent() + "double " + result + " = -(" + rightResult
						+ ");\n";

				code += indent() + "Message.setLineNumber("
						+ unaryOperator.getLineNumber() + ");\n";
				return new Encode.ReturnValue(result, code);
			} else if (right.getType().isStringType()) {

				String tempVal1 = getTemp();
				code += indent() + "TSValue " + tempVal1 + " = TSValue.make("
						+ rightResult + ");\n";

				code += indent() + "Message.setLineNumber("
						+ unaryOperator.getLineNumber() + ");\n";
				code += indent() + "double " + result + "=-((" + tempVal1
						+ ").toNumber().getInternal());\n";
				return new Encode.ReturnValue(result, code);
			} else {

				String tempVal = getTemp();
				code += indent() + "TSValue " + tempVal + " = TSValue.make("
						+ rightResult + ");\n";

				code += indent() + "Message.setLineNumber("
						+ unaryOperator.getLineNumber() + ");\n";
				// String tempVal1 = getTemp();
				code += indent() + "double " + result + "=-((" + tempVal
						+ ").toNumber().getInternal());\n";
				// code += indent() + "TSValue " + result + "=TSValue.make("
				// + tempVal1 + ");\n";
				return new Encode.ReturnValue(result, code);
			}

		default:
			Message.bug("unexpected operator: " + opString);
		}

		//
		// if control reaches here then do unoptimized code generation
		//

		// one of the subtrees might be a Java value at run-time so
		// need to generate code that will convert it to a TSValue if necessary
		String methodName = getMethodNameForUnaryOperator(unaryOperator);
		code += indent() + "Message.setLineNumber("
				+ unaryOperator.getLineNumber() + ");\n";
		code += indent() + "TSValue " + result + " = (TSValue.make("
				+ rightResult + "))." + methodName + "(TSValue.make("
				+ rightResult + "));\n";

		return new Encode.ReturnValue(result, code);
	}

	// support routine for handling unary operators
	private static String getMethodNameForUnaryOperator(
			final UnaryOperator opNode) {
		final Unop op = opNode.getOp();

		switch (op) {
		case LOGICALNOT:
			return "logicalnot";

		default:
			Message.bug("unexpected operator: " + opNode.getOpString());
		}
		// cannot reach
		return null;
	}

	/** Generate and return code for an expression statement. */
	@Override
	public Encode.ReturnValue visit(
			final ExpressionStatement expressionStatement) {
		Encode.ReturnValue exp = visitNode(expressionStatement.getExp());
		String code = indent() + "Message.setLineNumber("
				+ expressionStatement.getLineNumber() + ");\n";
		code += exp.code;
		return new Encode.ReturnValue(code);
	}

	/** Generate and return code for an block statement. */
	@Override
	public Encode.ReturnValue visit(final BlockStatement blockStatement) {

		String code = "";
		code += indent() + "Message.setLineNumber("
				+ blockStatement.getLineNumber() + ");\n";
		if (blockStatement.getStatementList() == null
				|| blockStatement.getStatementList().size() == 0) {
			code += indent();
		} else {
			code += visitTheBlock(blockStatement.getStatementList());
		}

		return new Encode.ReturnValue("{" + code + "}");

	}

	/**
	 * Supporting method for block statement
	 * 
	 * @param statementList
	 */
	private String visitTheBlock(List<Statement> statementList) {
		String code = "";

		if (statementList.size() > 0) {
			for (int i = 0; i < statementList.size(); i++) {

				Encode.ReturnValue result = visitNode(statementList.get(i));
				code += indent() + result.code + "\n";

			}
		}
		return code;
	}

	/** Generate and return code for a while statement. */
	@Override
	public Encode.ReturnValue visit(final WhileStatement whileStatement) {

		Encode.ReturnValue stmtVal = visitNode(whileStatement.getStmt());
		String code = "";
		Encode.ReturnValue conditionVal = visitNode(whileStatement.getExp());

		code = indent() + "Message.setLineNumber("
				+ whileStatement.getLineNumber() + ");\n";
		code = code + "while(true){";

		code += conditionVal.code + "if(" + conditionVal.result
				+ ".toBoolean().getInternal() == false)" + "break;\n" + "if ("
				+ conditionVal.result + ".toBoolean().getInternal() == true)"
				+ "{" + stmtVal.code + "}\n }\n";
		return new Encode.ReturnValue(code);
	}

	/**
	 * Generate and return code for a if-else statement
	 * 
	 * @param ifElseStatement
	 *            Contains the statements with if and else.
	 */
	public Encode.ReturnValue visit(final IfElseStatement ifElseStatement) {

		Encode.ReturnValue conditionVal = visitNode(ifElseStatement.getExp());
		Encode.ReturnValue ifStmt = visitNode(ifElseStatement.getIfStmt());
		String code = "";
		code += indent() + "\n Message.setLineNumber("
				+ ifElseStatement.getLineNumber() + ");\n";

		if (ifElseStatement.getElseStmt() == null) {

			code += indent() + conditionVal.code + "\n if("
					+ conditionVal.result + ".toBoolean().getInternal()=="
					+ true + "){" + ifStmt.code + "}\n";
		} else {
			Encode.ReturnValue elseStmt = visitNode(ifElseStatement
					.getElseStmt());

			code += indent() + conditionVal.code + "\n if("
					+ conditionVal.result + ".toBoolean().getInternal()=="
					+ true + "){" + ifStmt.code + "}\n" + "else{"
					+ elseStmt.code + "}\n";
		}

		return new Encode.ReturnValue(code);

	}

	/**
	 * Generate and return code for BreakStatement
	 * 
	 * @param breakStatement
	 *            represents the break and the identifier associated with it, if
	 *            any.
	 */
	public Encode.ReturnValue visit(final BreakStatement breakStatement) {

		String code = "";
		code += indent() + "Message.setLineNumber("
				+ breakStatement.getLineNumber() + ");\n";

		code += indent() + " if(true) break;\n";
		// }

		return new Encode.ReturnValue(code);
	}

	/**
	 * Generate and return code for ContinueStatement
	 * 
	 * @param continueStatement
	 *            represents the continue and the identifier associated with it,
	 *            if any.
	 */
	public Encode.ReturnValue visit(final ContinueStatement continueStatement) {

		String code = "";
		code += indent() + "Message.setLineNumber("
				+ continueStatement.getLineNumber() + ");\n";

		code += indent() + " if(true) continue;\n";
		// }

		return new Encode.ReturnValue(code);
	}

	/**
	 * Generate and return code for a Empty statement
	 * 
	 * @param emptyStatement
	 * 
	 *            The statement with empty statement.
	 */
	public Encode.ReturnValue visit(final EmptyStatement emptyStatement) {
		String code = "";
		code += indent() + "Message.setLineNumber("
				+ emptyStatement.getLineNumber() + ");\n";

		code += indent() + "\n";

		return new Encode.ReturnValue(code);

	}

	/**
	 * Generate and return code for a throw statement
	 * 
	 * @param throwStatement
	 * 
	 *            The statement with throw statement.
	 */
	public Encode.ReturnValue visit(final ThrowStatement throwStatement) {
		String code = "";
		Encode.ReturnValue exp1 = visitNode(throwStatement.getExp());
		code = indent() + "Message.setLineNumber("
				+ throwStatement.getLineNumber() + ");\n";
		code += exp1.code;
		String toSendString = getTemp();
		code += indent() + "TSValue " + toSendString + "=TSValue.make("
				+ exp1.result + ");\n";
		code += "if(true)\n throw new TSException(" + toSendString + ");\n";
		return new Encode.ReturnValue(code);

	}

	/**
	 * Generate and return code for a try statement
	 * 
	 * @param tryStatement
	 * 
	 *            The statement with try statement.
	 */
	public Encode.ReturnValue visit(final TryStatement tryStatement) {

		Encode.ReturnValue stmt = visitNode(tryStatement.getBlockStmt());
		String code = indent() + "try{" + stmt.code + "}\n";
		if (tryStatement.getCatchStmt() != null) {
			Encode.ReturnValue cStmt = visitNode(tryStatement.getCatchStmt());
			code += indent() + cStmt.code;
		}
		if (tryStatement.getFinallyStmt() != null) {
			Encode.ReturnValue finStmt = visitNode(tryStatement
					.getFinallyStmt());
			code += indent() + finStmt.code;
		}
		return new Encode.ReturnValue(code);
	}

	/**
	 * Generate and return code for a catch statement
	 * 
	 * @param catchStatement
	 * 
	 *            The statement with catch statement.
	 */
	public Encode.ReturnValue visit(final CatchStatement catchStatement) {

		String code = "catch(TSException " + catchStatement.getCIdentifier()
				+ "){ \n";

		Encode.ReturnValue stmt = visitNode(catchStatement.getBlockStmt());

		code += indent() + " \n TSValue catch_"
				+ catchStatement.getCIdentifier() + " = "
				+ catchStatement.getCIdentifier() + ".getEValue();\n";
		code += stmt.code + " \n }\n";
		return new Encode.ReturnValue(code);

	}

	/**
	 * Generate and return code for a finally statement
	 * 
	 * @param finallyStatement
	 * 
	 *            The statement with finally statement.
	 */
	public Encode.ReturnValue visit(final FinallyStatement finallyStatement) {
		Encode.ReturnValue exp = visitNode(finallyStatement
				.getFinallyBlckStmt());
		String code = indent() + "finally{ \n";
		code += exp.code + " }\n \n";
		return new Encode.ReturnValue(code);
	}

	/**
	 * Generate and return code for a return statement
	 * 
	 * @param returnStatement
	 * 
	 *            The statement with return statement.
	 */
	public Encode.ReturnValue visit(final ReturnStatement returnStatement) {
		// if (functionCounter == 0) {
		// Message.syntaxError(returnStatement.getLoc());
		// }
		String code = "";
		Expression exp = returnStatement.getExp();
		if (exp == null) {
			code += indent() + "return TSUndefined.value;\n";
		} else {
			Encode.ReturnValue returnVisitNode = visitNode(exp);
			code += indent() + returnVisitNode.code;
			code += indent() + "if(true)\n\t return TSValue.make("
					+ returnVisitNode.result + ");\n";
		}
		return new Encode.ReturnValue(code);

	}

	int nest = 0;

	public Encode.ReturnValue visit(final FunctionExpression functionExpression) {

		String code = "";
		code += indent() + "Message.setLineNumber("
				+ functionExpression.getLineNumber() + ");\n";

		ArrayList<Statement> fbody = functionExpression.getFunctionBody();
		String tempstr = "";

		functionCounter++;

		List<VarStatement> vars = functionExpression.getFunctionVars();
		String capturedVar = "";
		int i = 0;
		if (vars != null)
			for (VarStatement varStatement : vars) {

				String[] splitStr = varStatement.getTempName().split("_");

				if ((!varStatement.getTempName().contains("formal"))
						&& splitStr[2].equals(functionCounter + "")) {
					// if this var node is redundant, then skip it
					if (varStatement.isRedundant()) {
						return new Encode.ReturnValue("");
					}
					tempstr += indent() + "Message.setLineNumber("
							+ varStatement.getLineNumber() + ");\n";

					// if this variable was never used, then Type will be null.
					// in that case treat as if the type is unknown
					Type type = varStatement.getType();
					if (type == null || type.isUnknownType()) {

						tempstr += indent() + "TSValue "
								+ varStatement.getTempName()
								+ " =TSUndefined.value;\n";
					} else {

						String jType = getJavaType(type);
						if (jType.equals("double")) {
							tempstr += indent() + jType + " "
									+ varStatement.getTempName() + " =0"
									+ ";\n";
						} else if (jType.equals("String")) {
							tempstr += indent() + jType + " "
									+ varStatement.getTempName() + " =\"\""
									+ ";\n";
						} else {
							tempstr += indent() + jType + " "
									+ varStatement.getTempName() + ";\n";
						}
					}

				}
				if (varStatement.isCaptured()) {
					capturedVar += indent() + "environ.";
					int depthDiff = functionCounter
							- varStatement.getFunctionDepth();
					for (int m = 0; m < depthDiff; m++) {
						capturedVar += "outer.";
					}

					capturedVar += "params[" + i + "] = TSValue.make("
							+ visitNode(varStatement).code + ");\n";
					i++;
				}

			}

		List<String> fprm = functionExpression.getFormalParameterList();

		if (fprm != null) {
			tempstr += "TSValue[] params=new TSValue[" + (i < 0 ? 0 : i)
					+ "];\n";

			for (int k = 0; k < fprm.size(); k++) {

				//
				// tempstr += "\n  System.out.println(\"hello \"+args[" + k
				// + "].toNumber().getInternal()); \n";

				tempstr += "\n TSValue formal_" + fprm.get(k) + "_"
						+ functionCounter + " = " + "(" + k
						+ " < args.length ? args[" + k
						+ "] : TSUndefined.value);\n";
			}
		}

		if (fbody != null) {
			for (int k = 0; k < fbody.size(); k++) {
				Encode.ReturnValue rval = visitNode(fbody.get(k));
				tempstr += rval.code;
			}
		}
		tempstr += "return TSUndefined.value;\n";
		// tempstr += indent() + " } \n";
		// tempstr += "}";

		functionList.add(tempstr);
		functionCounter--;

		String result = getTemp();

		String temp = getTemp();

		code += indent() + "TSCode " + temp + " = new Function" + (nest + 1)
				+ "();\n";
		nest++;
		code += capturedVar + " \n";
		String envTemp = getTemp();

		code += indent() + "TSValue " + result + " = TSFunctionObject.create("
				+ temp + ", null);\n";

		// functionCounter--;
		return new Encode.ReturnValue(result, code);
	}

	public Encode.ReturnValue visit(final CallExpression callExpression) {
		String code = "";
		code += indent() + "Message.setLineNumber("
				+ callExpression.getLineNumber() + ");\n";
		Encode.ReturnValue expVal = visitNode(callExpression.getCallExp());

		String returnString = "{" + indent();

		// make the arguments of the call expression
		if (callExpression.getArguments() != null) {
			for (int i = 0; i < callExpression.getArguments().size(); i++) {
				Encode.ReturnValue exp = visitNode(callExpression
						.getArguments().get(i));
				code += exp.code;

				returnString += "(TSValue.make(" + exp.result + "))";
				if (i < callExpression.getArguments().size() - 1)
					returnString += ", ";
			}
			returnString += "};";

			if (callExpression.getArguments().size() == 0) {
				returnString = "new TSValue[0]";
			}

		} else {
			// No arguments
			returnString = "new TSValue[0]";
		}

		String resultToBeReturned = getTemp();
		code += "TSValue[] " + resultToBeReturned + " = " + returnString + ";";
		String temp = expVal.result;
		code += expVal.code;
		String result = getTemp();
		if (callExpression.getCallExp() instanceof PropertyAccessorExpression) {
			// code += "TSValue "
			// + result
			// + " = TSValue.make("
			// + temp
			// +
			// ").callConstructor( true,
			// TSValue.make(TSObject.getTSObject.getGlobalObject()().getPropertyMap().get(\"ths\")),"
			// + resultToBeReturned + ");";
			PropertyAccessorExpression p = (PropertyAccessorExpression) callExpression
					.getCallExp();
			Encode.ReturnValue pLeft = visitNode(p.getMemberExpr());
			code += pLeft.code;
			code += "TSValue " + result + " = TSValue.make(" + temp
					+ ").callFunction( false," + pLeft.result + ","
					+ resultToBeReturned + ")\n;";
		} else {
			code += "TSValue " + result + " = TSValue.make(" + temp
					+ ").callFunction( false, null," + resultToBeReturned
					+ ");\n";
		}

		return new Encode.ReturnValue(result, code);
	}

	/**
	 * Generate and return code for a function body statement
	 * 
	 * @param functionBody
	 * 
	 *            The statement with function body.
	 */
	public Encode.ReturnValue visit(final FunctionBody functionBody) {
		String code = "";

		ArrayList<Statement> bodyStmts = functionBody.getBody();
		if (bodyStmts != null) {
			for (Statement s : bodyStmts) {
				code += visitNode(s).code;
			}
		}

		return new Encode.ReturnValue(code);
	}

	// ----------------------------------------------------------------------------------------------

	/** Generate and return code for an ObjectLiteral. */
	@Override
	public Encode.ReturnValue visit(final ObjectLiteral objectLiteral) {

		String code = "";
		code += indent() + "Message.setLineNumber("
				+ objectLiteral.getLineNumber() + ");\n";
		String temp = getTemp();
		code += indent() + "TSObject " + temp + " = TSObject.create(null);\n";

		code += indent() + "";
		if (objectLiteral.getPropertyNameAndValueList() == null
				|| objectLiteral.getPropertyNameAndValueList().size() == 0) {
			code += indent();
		} else {
			for (PropertyPair p : objectLiteral.getPropertyNameAndValueList()) {
				Encode.ReturnValue pCode = visitNode(p.getPropertyValue());

				code += pCode.code;
				code += indent() + temp + ".put((\"" + p.getPropertyName()
						+ "\"),TSValue.make(" + pCode.result + "));\n";
			}
		}

		return new Encode.ReturnValue(temp, code);

	}

	/** Generate and return code for an PropertyAccessorExpression. */
	public Encode.ReturnValue visit(final PropertyAccessorExpression propAccess) {
		String code = indent() + "Message.setLineNumber("
				+ propAccess.getLineNumber() + ");\n";

		String id = propAccess.getId();

		Expression exp = propAccess.getMemberExpr();
		Encode.ReturnValue propAcessvistnode = visitNode(exp);

		String result = getTemp();
		String temp2 = getTemp();

		String temp1 = getTemp();
		code += propAcessvistnode.code;
		code += indent() + "\n TSValue " + temp1 + " = "
				+ propAcessvistnode.result + ";\n";

		// if (id != null)
		code += " String " + temp2 + "= \"" + id + "\";\n";
		if (propAccess.getExp() != null) {
			Encode.ReturnValue temp3 = visitNode(propAccess.getExp());
			code += temp3.code;
			code += indent() + "TSValue " + result + "=" + temp1
					+ ".get((TSValue.make(" + temp3.result
					+ ")).toStr().getInternal());\n";

		} else {
			code += indent() + "TSValue " + result + "=" + temp1
					+ ".get(TSValue.make(" + temp2
					+ ").toStr().getInternal());\n";
		}
		// }

		return new Encode.ReturnValue(result, code);
	}

	public Encode.ReturnValue visit(final NewExpression newExpression) {
		String code = indent() + "Message.setLineNumber("
				+ newExpression.getLineNumber() + ");\n";
		Expression ex = newExpression.getMemberExp();
		Encode.ReturnValue expVal = visitNode(ex);
		String returnString = "";
		// make the arguments of the call expression
		if (newExpression.getArguments() != null) {
			for (int i = 0; i < newExpression.getArguments().size(); i++) {
				Encode.ReturnValue exp = visitNode(newExpression.getArguments()
						.get(i));
				code += exp.code;

				if (i != newExpression.getArguments().size()
						&& i < newExpression.getArguments().size())
					returnString += exp.result + ",";
				else
					returnString += exp.result;
			}

			returnString += "}";

			if (newExpression.getArguments().size() == 0) {
				returnString = "new TSValue[0]";
			}
		} else {
			// No arguments
			returnString = "new TSValue[0]";
		}
		String resultToBeReturned = getTemp();
		code += "\n TSValue[] " + resultToBeReturned + " = " + returnString
				+ ";\n";
		String temp = expVal.result;
		code += expVal.code;
		String result = getTemp();
		code += "TSValue " + result + " = " + temp + ".callConstructor( true,"
				+ expVal.result + "," + resultToBeReturned + ");\n";
		// System.out.println( code );
		return new Encode.ReturnValue(result, code);

	}

	/** Generate and return code for an thisLiteral. */
	@Override
	public Encode.ReturnValue visit(final ThisLiteral thisLiteral) {
		// returns a global object.
		String result = getTemp();
		String code = indent() + "TSValue " + result
				+ "=TSObject.getGlobalObject().get(\""
				+ thisLiteral.getThisValue() + "\");\n";
		// TSObjectEnvironmentRecord.getTSObject.getGlobalObject()()
		return new Encode.ReturnValue(result, code);
	}

	// -----------------------------------------------------------------------------------------------
	/** Generate and return code for an identifier. */
	@Override
	public Encode.ReturnValue visit(final Identifier identifier) {
		String result = null;
		String code = "";

		// info about the variable is stored in the VarStatement node
		// that declared it
		VarStatement varNode = identifier.getVarNode();

		// if there is no link back to the Var declaration then
		// the identifier is not declared
		if (varNode == null) {

			// code += " if(true) \n " + indent();
			String temp = getTemp();

			code += "TSValue " + temp + " = TSObject.getGlobalObject().get(\""
					+ identifier.getName() + "\");\n";

			code += "if("
					+ temp
					+ "==null){\n throw new TSException(TSValue.make(\"undefined identifier:"
					+ identifier.getName() + "\"));\n }\n";
			// +
			// "throw new TSException(TSString.create(\"undefined identifier: "
			// + identifier.getName() + "\"));\n";
			result = getTemp();
			code += indent() + "TSValue " + result + " = " + temp + ";\n";
		}
		// otherwise identifier is declared
		else {
			String codegenName = varNode.getTempName();
			Type type = varNode.getType();

			// does the identifier denote the address of a variable or its
			// value?
			if (identifier.isLval()) {
				// just need the variable's address (so no code needs to be
				// generated)
				result = codegenName;
			} else {
				// need to deref the variable to get its value
				String jType = getJavaType(type);
				result = getTemp();
				code += indent() + jType + " " + result + " = " + codegenName
						+ ";\n";
			}
		}

		return new Encode.ReturnValue(result, code);
	}

	/** Generate and return code for a numeric literal. */
	@Override
	public Encode.ReturnValue visit(final NumericLiteral numericLiteral) {
		String result = getTemp();
		String code = indent() + "double " + result + " = "
				+ numericLiteral.getValue() + ";\n";

		return new Encode.ReturnValue(result, code);
	}

	/** Generate and return code for a boolean literal. */
	@Override
	public Encode.ReturnValue visit(final BooleanLiteral booleanLiteral) {
		String result = getTemp();
		String tempVal = getTemp();
		String code = indent() + "boolean " + tempVal + " = "
				+ booleanLiteral.getValue() + ";\n";
		code += "Message.setLineNumber(" + booleanLiteral.getLineNumber()
				+ ");\n";
		code += indent() + "TSValue " + result + " = TSBoolean.create("
				+ tempVal + ");\n";
		return new Encode.ReturnValue(result, code);
	}

	/** Generate and return code for a null literal. */
	@Override
	public Encode.ReturnValue visit(final NullLiteral nullLiteral) {
		String result = getTemp();
		String code = indent() + "TSValue " + result + " = TSNull.value;\n";
		return new Encode.ReturnValue(result, code);
	}

	/** Generate and return code for a print statement. */
	@Override
	public Encode.ReturnValue visit(final PrintStatement printStatement) {
		Type type = printStatement.getExp().getType();
		Encode.ReturnValue exp = visitNode(printStatement.getExp());
		String code = indent() + "Message.setLineNumber("
				+ printStatement.getLineNumber() + ");\n";
		code += exp.code;
		if (type.isNumberType()) {
			// need to apply Javascript Number -> String conversion
			code += indent() + "System.out.println(TSNumber.create("
					+ exp.result + ").toStr().getInternal());\n";
		} else if (type.isStringType()) {
			code += indent() + "System.out.println(" + exp.result + ");\n";
		} else {
			code += indent() + "System.out.println(" + exp.result
					+ ".toPrimitive().toStr().getInternal());\n";
		}
		return new Encode.ReturnValue(code);
	}

	/** Generate and return code for a program. */
	@Override
	public Encode.ReturnValue visit(final Program program) {
		String code = "";

		// ----------------------------------------------------------------------------
		List<VarStatement> vars = program.getVarNodes();
		String newCode = "";
		for (VarStatement varStatement : vars) {

			// if this var node is redundant, then skip it
			if (varStatement.isRedundant()) {
				return new Encode.ReturnValue("");
			}
			newCode += indent() + "Message.setLineNumber("
					+ varStatement.getLineNumber() + ");\n";

			if (varStatement.getFunctionDepth() == 0)
				newCode += "TSObject.getGlobalObject().put(\""
						+ varStatement.getTempName()
						+ "\",TSUndefined.value);\n";

			// if this variable was never used, then Type will be null.
			// in that case treat as if the type is unknown
			Type type = varStatement.getType();
			if (type == null || type.isUnknownType()) {

				newCode += indent() + "TSValue " + varStatement.getTempName()
						+ " = TSUndefined.value;\n";
			} else {

				String jType = getJavaType(type);
				if (jType.equals("double")) {
					newCode += indent() + jType + " "
							+ varStatement.getTempName() + " = 0" + ";\n";
				} else if (jType.equals("String")) {
					newCode += indent() + jType + " "
							+ varStatement.getTempName() + " = \"\"" + ";\n";
				} else {
					newCode += indent() + jType + " "
							+ varStatement.getTempName() + ";\n";
				}
			}
			// if(varStatement.getFunctionDepth()==0){
			// TSObject.getTSObject.getGlobalObject()().put(varStatement.getName(),
			// TSValue.make(value));
			// }
		}
		// --------------------------------------------------------------------------------

		for (Encode.ReturnValue value : visitEach(program.getList())) {
			code += value.code;
		}
		return new Encode.ReturnValue(newCode + code);
	}

	/** Generate and return code for a string literal. */
	@Override
	public Encode.ReturnValue visit(final StringLiteral stringLiteral) {
		String result = getTemp();
		String code = indent() + "String " + result + " = \""
				+ stringLiteral.getValue() + "\";\n";

		return new Encode.ReturnValue(result, code);
	}

	/** Generate and return code for a var statement. */
	@Override
	public Encode.ReturnValue visit(final VarStatement varStatement) {

		return new Encode.ReturnValue("");
	}

}
