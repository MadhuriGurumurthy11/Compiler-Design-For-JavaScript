package ts.tree.visit;

import ts.Location;
import ts.Message;
import ts.parse.TreeBuilder;
import ts.support.TSObject;
import ts.support.TSValue;
import ts.tree.*;
import ts.tree.type.*;

import java.util.ArrayList;
import java.util.Deque;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Analyze an AST. The goal is to do simple type inferencing and to identify
 * where variables will be stored at run-time. For now, they they will be stored
 * in a Java local, but later this code will need to be updated to support
 * variables captured by a closure, and global variables stored as properties of
 * the global object.
 * <p>
 * When the analyzer is created, a pass number is provided to the constructor,
 * which must be either 1 (first pass) or 2 (second pass). The first pass
 * connects Identifier nodes to the VarStatement nodes where the identifier was
 * declared. Information is accumulated in the VarStatement node about the
 * variable, including its function depth (how deeply nested is the function
 * that contains the declaration) and its type. A second pass is needed because
 * if the type is ambiguous for a variable, then its initial uses may not
 * reflect the ambiguous type that was found later. The expression trees
 * containing these Identifier nodes need to have their types updated in the
 * second pass.
 * <p>
 * Using Tree for the type parameter to allow subtrees to be altered by visiting
 * them. The return type can be assigned to the fields of a node as the
 * traversal returns back to it. This capability is actually not being used, but
 * it might be useful later.
 * <p>
 * The "visit" method is overloaded for each tree node type.
 */
public final class Analyze extends TreeVisitorBase<Tree> {

	/**
	 * The symbol table. It is a map of variable names to stacks of VarStatement
	 * nodes.
	 */
	private Map<String, Deque<VarStatement>> symbolTable;

	/** The current function declaration depth. Always zero now. */
	private int functionDepth = 0;
	int loopCount = 0;
	/**
	 * The pass being implemented by this instance of the analyze visitor. Must
	 * be either 1 (first pass) or 2 (second pass).
	 */
	private int pass;

	/**
	 * Create an AST analyzer.
	 *
	 * @param pass
	 *            pass number to be implemented by this analyze visitor, which
	 *            must be either 1 (first pass) or 2 (second pass).
	 */
	public Analyze(int pass) {
		if (pass < 1 || pass > 2) {
			throw new IllegalArgumentException("illegal pass number");
		}
		this.pass = pass;
		symbolTable = new HashMap<String, Deque<VarStatement>>();

		Deque<VarStatement> dummyVar = new LinkedList<VarStatement>();
		Location loc = new Location("", 0, 0);
		VarStatement var = (VarStatement) TreeBuilder.buildVarStatement(loc,
				"undefined");
		var.setTempName("undefined");
		var.setType(UnknownType.getInstance());
		dummyVar.addFirst(var);
		symbolTable.put(var.getName(), dummyVar);

	}

	/**
	 * Visit a list of ASTs and dump them in order.
	 */
	@Override
	public List<Tree> visitEach(final Iterable<?> nodes) {
		for (final Object node : nodes) {
			visitNode((Tree) node);
		}
		return null;
	}

	/** Analyze a binary operator. */
	@Override
	public Tree visit(final BinaryOperator binaryOperator) {
		// recurse left and then right
		binaryOperator
				.setLeft((Expression) visitNode(binaryOperator.getLeft()));
		// Expression binRight = binaryOperator.getRight();
		// Expression temp = (Expression) visitNode(binRight);
		// binaryOperator.setRight(temp);

		binaryOperator.setRight((Expression) visitNode(binaryOperator
				.getRight()));

		// now do type analysis
		Binop op = binaryOperator.getOp();
		Type leftType = binaryOperator.getLeft().getType();
		Type rightType = binaryOperator.getRight().getType();

		switch (op) {
		case ADD:
			// if either operand is a string, then result is a string
			if (leftType.isStringType() || rightType.isStringType()) {
				binaryOperator.setType(StringType.getInstance());
			}
			// if both are numbers, then result is number
			else if (leftType.isNumberType() && rightType.isNumberType()) {
				binaryOperator.setType(NumberType.getInstance());
			}
			// otherwise can't tell now what result type will be
			else {
				binaryOperator.setType(UnknownType.getInstance());
			}
			break;

		case SUBTRACT:
			binaryOperator.setType(NumberType.getInstance());
			break;
		case ASSIGN:
			// type of the result is the type of the right-hand side
			binaryOperator.setType(rightType);
			// if the left-hand side is an identifier, then on pass 1
			// update its declaring VarStatement node (if there is one)
			if ((pass == 1) && (binaryOperator.getLeft() instanceof Identifier)) {
				Identifier id = (Identifier) binaryOperator.getLeft();
				VarStatement node = id.getVarNode();
				// might not be declared
				if (node != null) {
					// update the type information recorded so far for variable
					Type oldType = node.getType();
					if (oldType == null) {
						// no type seen before
						node.setType(rightType);
					} else {
						// if old type does not match the current type, then
						// the type is ambigous
						if (!oldType.isSameType(rightType)) {
							// so label the variable as having unknown type
							node.setType(UnknownType.getInstance());
						}
					}
				}
			}
			break;
		case MULTIPLY:
			// always produces a number
			binaryOperator.setType(NumberType.getInstance());
			break;

		case DIVISION:
			// always produces a number
			binaryOperator.setType(NumberType.getInstance());
			break;

		case LESSTHAN:
			binaryOperator.setType(UnknownType.getInstance());
			break;

		case GREATERTHAN:
			binaryOperator.setType(UnknownType.getInstance());
			break;

		case EQUALS:
			binaryOperator.setType(UnknownType.getInstance());
			break;
		// case DOT:
		// binaryOperator.setType(UnknownType.getInstance());
		// break;
		default:
			Message.bug("unexpected binary operator");
		}

		// return this node so it can be re-assigned by its parent
		return binaryOperator;
	}

	/** Analyze a Unary operator. */
	@Override
	public Tree visit(final UnaryOperator unaryOperator) {
		// recurse right
		unaryOperator
				.setRight((Expression) visitNode(unaryOperator.getRight()));

		// now do type analysis
		Unop op = unaryOperator.getOp();

		switch (op) {
		case LOGICALNOT:
			unaryOperator.setType(UnknownType.getInstance());
			break;

		case UNARYMINUS:

			unaryOperator.setType(NumberType.getInstance());
			break;
		default:
			Message.bug("unexpected unary operator");
		}

		// return this node so it can be re-assigned by its parent
		return unaryOperator;
	}

	/** Analyze an expression statement. */
	@Override
	public Tree visit(final ExpressionStatement expressionStatement) {
		visitNode(expressionStatement.getExp());
		return null;
	}

	/** Analyze an identifier. */
	@Override
	public Tree visit(final Identifier identifier) {
		// if it is the second pass then only need to copy the type from
		// the Var node.
		if (pass == 2) {
			VarStatement varNode = identifier.getVarNode();
			if (varNode == null) {
				// identifier is not defined, so set its type to unknown
				identifier.setType(UnknownType.getInstance());
			} else {
				Type type = varNode.getType();
				if (type == null) {
					// variable was never assigned so set the type to unknown
					identifier.setType(UnknownType.getInstance());
				} else {
					// otherwise use the type in the var node
					identifier.setType(type);
				}
			}
			// that is all we need to do for pass 2
			return identifier;
		}

		//
		// all the following code is only executed on pass 1
		//

		// lookup the name in the symbol table
		Deque<VarStatement> stack = symbolTable.get(identifier.getName());
		if (stack != null) {
			VarStatement varNode = stack.peekFirst();
			if (varNode != null) {
				// record the declaration tree node into the identifier tree
				// node so
				// that code generator has access to what is learned about this
				// variable
				identifier.setVarNode(varNode);

				// check the type field of the Var node
				// if it is null, and the identifier represents an Rval, then
				// this is a use of the variable before it is assigned to,
				// meaning
				// that it will contain the undefined value, so its type needs
				// to be set to Unknown, since the variable lifetime is not
				// always Number or always String
				if (varNode.getType() == null && !identifier.isLval()) {
					varNode.setType(UnknownType.getInstance());
					identifier.setType(UnknownType.getInstance());
				} else {
					// otherwise set this type to be the type from the var node
					identifier.setType(varNode.getType());
				}
			} else {
				// identifier is not defined, so set its type to Unknown
				identifier.setType(UnknownType.getInstance());
			}
		} else {
			// identifier is not defined, so set its type to Unknown
			identifier.setType(UnknownType.getInstance());
		}

		// return the node so that it can be re-assigned by its parent
		return identifier;
	}

	/** Analyze a numeric literal. */
	@Override
	public Tree visit(final NumericLiteral numericLiteral) {
		// always has Number type
		numericLiteral.setType(NumberType.getInstance());

		// return the node so that it can be re-assigned by its parent
		return numericLiteral;
	}

	/** Analyze a boolean literal. */
	@Override
	public Tree visit(final BooleanLiteral booleanLiteral) {
		// always has Boolean type, which is represented by UnknownType
		booleanLiteral.setType(UnknownType.getInstance());

		// return the node so that it can be re-assigned by its parent
		return booleanLiteral;
	}

	/** Analyze a null literal. */
	@Override
	public Tree visit(final NullLiteral nullLiteral) {
		// always has null type, which is represented by UnknownType
		nullLiteral.setType(UnknownType.getInstance());

		// return the node so that it can be re-assigned by its parent
		return nullLiteral;
	}

	/** Analyze a print statement. */
	@Override
	public Tree visit(final PrintStatement printStatement) {
		visitNode(printStatement.getExp());
		return null;
	}

	/** Analyze a block statement. */
	@Override
	public Tree visit(final BlockStatement blockStatement) {
		// functionDepth++;

		List<Statement> stmtList = blockStatement.getStatementList();
		if (stmtList != null && stmtList.size() > 0) {
			for (Statement stmt : stmtList) {
				visitNode(stmt);
			}
		}

		// functionDepth--;
		return null;
	}

	/** Analyze a while statement. */
	@Override
	public Tree visit(final WhileStatement whileStatement) {
		loopCount++;
		Expression exp = whileStatement.getExp();

		visitNode(exp);

		Statement stmt = whileStatement.getStmt();

		if (stmt != null) {
			visitNode(stmt);
		}
		loopCount--;
		return null;
	}

	/** Analyze a if-else statement. */
	@Override
	public Tree visit(final IfElseStatement ifelseStatement) {

		Expression exp = ifelseStatement.getExp();

		visitNode(exp);

		Statement ifStmt = ifelseStatement.getIfStmt();

		if (ifStmt != null) {
			visitNode(ifStmt);
		}

		Statement elseStmt = ifelseStatement.getElseStmt();

		if (elseStmt != null) {
			visitNode(elseStmt);
		}
		return null;
	}

	/** Analyze a break statement. */
	@Override
	public Tree visit(final BreakStatement breakStatement) {

		if (loopCount == 0) {
			Message.executionError("Illegal break");
		}
		return null;
	}

	/** Analyze a continue statement. */
	@Override
	public Tree visit(final ContinueStatement continueStatement) {
		if (loopCount == 0) {
			Message.executionError("Illegal continue");
		}
		return null;
	}

	/** Analyze an empty statement. */
	@Override
	public Tree visit(final EmptyStatement emptyStatement) {
		return null;
	}

	/** Analyze a throw statement. */
	@Override
	public Tree visit(final ThrowStatement throwStatement) {

		Expression exp = throwStatement.getExp();

		visitNode(exp);

		return null;
	}

	/** Analyze a try statement. */
	@Override
	public Tree visit(final TryStatement tryStatement) {

		Statement tryStmt = tryStatement.getBlockStmt();

		visitNode(tryStmt);

		Statement catchStmt = tryStatement.getCatchStmt();

		if (catchStmt != null) {
			visitNode(catchStmt);
		}

		Statement finallyStmt = tryStatement.getFinallyStmt();

		if (finallyStmt != null) {
			visitNode(finallyStmt);
		}
		return null;
	}

	/** Analyze a catch statement. */
	@Override
	public Tree visit(final CatchStatement catchStatement) {

		Statement catchStmt = catchStatement.getBlockStmt();

		// if (symbolTable.get(catchStatement.getCIdentifier()) == null) {

		// }

		// is there a stack for this name already in the symbol table?
		Deque<VarStatement> stack = symbolTable.get(catchStatement
				.getCIdentifier());
		if (stack == null) {
			// need to create the stack and insert it into the map
			stack = new LinkedList<VarStatement>();

			VarStatement catchVar = (VarStatement) TreeBuilder
					.buildVarStatement(catchStatement.getLoc(),
							catchStatement.getCIdentifier());
			catchVar.setTempName("catch_" + catchStatement.getCIdentifier());
			catchVar.setType(UnknownType.getInstance());
			stack.add(catchVar);

			symbolTable.put(catchStatement.getCIdentifier(), stack);
		}

		// is there a declaration for this variable at the same function depth?
		// if so, then mark this declaration as redundant.
		// else push the current VarStatment onto the stack
		else {

			VarStatement catchVar = (VarStatement) TreeBuilder
					.buildVarStatement(catchStatement.getLoc(),
							catchStatement.getCIdentifier());
			catchVar.setTempName("catch_" + catchStatement.getCIdentifier());
			catchVar.setType(UnknownType.getInstance());
			stack.addFirst(catchVar);
		}

		visitNode(catchStmt);

		Deque<VarStatement> varEntry = symbolTable.get(catchStatement
				.getCIdentifier());
		Deque<VarStatement> varEntry1 = symbolTable.get(catchStatement
				.getCIdentifier());
		for (VarStatement v : varEntry) {
			if (v.getTempName().equals(
					"catch_" + catchStatement.getCIdentifier())) {
				varEntry1.remove(v);
			}
		}
		symbolTable.put(catchStatement.getCIdentifier(), varEntry1);

		return null;
	}

	/** Analyze a finally statement. */
	@Override
	public Tree visit(final FinallyStatement finallyStatement) {

		Statement finallyStmt = finallyStatement.getFinallyBlckStmt();

		visitNode(finallyStmt);

		return null;
	}

	// --------------------------------------------------------------------------------------------------
	/** Analyze a return statement. */
	@Override
	public Tree visit(final ReturnStatement returnStatement) {

		Expression exp = returnStatement.getExp();

		if (exp != null)
			visitNode(exp);

		return null;
	}

	/** Analyze a FunctionBody statement. */
	@Override
	public Tree visit(final FunctionBody functionBody) {

		ArrayList<Statement> stmts = functionBody.getBody();

		if (stmts != null)
			for (Statement s : stmts) {
				visitNode(s);
			}

		return functionBody;
	}

	/** Analyze a CallExpression statement. */
	@Override
	public Tree visit(final CallExpression callExpression) {

		Expression exp = callExpression.getCallExp();
		callExpression.setType(UnknownType.getInstance());
		if (exp != null)
			visitNode(exp);

		List<Expression> argExps = callExpression.getArguments();

		if (argExps != null) {
			for (Expression e : argExps) {
				visitNode(e);
			}
		}

		return callExpression;
	}

	/** Analyze a FunctionExpression statement. */
	@Override
	public Tree visit(final FunctionExpression functExpression) {

		String fIdentifier = functExpression.getFunctionIdentifier();
		functExpression.setType(UnknownType.getInstance());
		int whielLoopDepth = loopCount;

		loopCount = 0;
		if (fIdentifier != null) {
			Deque<VarStatement> stack = symbolTable.get(fIdentifier);
			if (stack == null) {
				// need to create the stack and insert it into the map
				stack = new LinkedList<VarStatement>();

				VarStatement funcVar = (VarStatement) TreeBuilder
						.buildVarStatement(functExpression.getLoc(),
								fIdentifier);
				funcVar.setTempName(fIdentifier);
				funcVar.setFunctionDepth(functionDepth);
				funcVar.setType(UnknownType.getInstance());
				stack.add(funcVar);

				symbolTable.put(fIdentifier, stack);
			}

			else {

				VarStatement funcVar = (VarStatement) TreeBuilder
						.buildVarStatement(functExpression.getLoc(),
								fIdentifier);
				funcVar.setTempName(fIdentifier);

				if (stack.getFirst().getFunctionDepth() < functionDepth) {
					funcVar.setIsCaptured();
				}
				funcVar.setFunctionDepth(functionDepth);
				funcVar.setType(UnknownType.getInstance());
				stack.addFirst(funcVar);
			}
		}
		functionDepth++;
		List<String> fArgsList = functExpression.getFormalParameterList();

		if (fArgsList != null) {
			for (String s : fArgsList) {

				Deque<VarStatement> stack = symbolTable.get(s);
				if (stack == null) {
					// need to create the stack and insert it into the map
					stack = new LinkedList<VarStatement>();

					VarStatement funcVar = (VarStatement) TreeBuilder
							.buildVarStatement(functExpression.getLoc(), s);
					funcVar.setTempName("formal_" + s + "_" + functionDepth);
					funcVar.setFunctionDepth(functionDepth);
					funcVar.setType(UnknownType.getInstance());
					stack.add(funcVar);

					symbolTable.put(s, stack);
				}

				// is there a declaration for this variable at the same function
				// depth?
				// if so, then mark this declaration as redundant.
				// else push the current VarStatment onto the stack
				else {

					VarStatement funcVar = (VarStatement) TreeBuilder
							.buildVarStatement(functExpression.getLoc(), s);
					funcVar.setTempName("formal_" + s + "_" + functionDepth);
					funcVar.setFunctionDepth(functionDepth);
					funcVar.setType(UnknownType.getInstance());
					stack.addFirst(funcVar);
				}

				// }
			}
		}

		ArrayList<Statement> fBody = functExpression.getFunctionBody();

		if (fBody != null) {
			for (Statement s : fBody) {
				visitNode(s);
			}
		}

		loopCount = whielLoopDepth;
		// functionDepth = fDepth;

		List<VarStatement> vars = new ArrayList<VarStatement>();

		for (Entry<String, Deque<VarStatement>> entry : symbolTable.entrySet()) {

			Deque<VarStatement> v = entry.getValue();

			for (VarStatement varStmt : v) {
				if (varStmt.getFunctionDepth() == functionDepth) {
					vars.add(varStmt);
				}
			}
		}

		functExpression.setFunctionVars(vars);
		for (VarStatement v : vars) {

			List<VarStatement> varStmts = new CopyOnWriteArrayList<VarStatement>();
			for (VarStatement v1 : symbolTable.get(v.getName())) {
				varStmts.add(v1);
			}
			for (VarStatement var : varStmts) {
				if ((var.getName().equals(v.getName()))
						&& (var.getFunctionDepth() == functionDepth)
						&& (var.getTempName().equals("var_" + var.getName()
								+ "_" + var.getFunctionDepth()))) {
					varStmts.remove(var);
				}
			}
			Deque<VarStatement> varStatements = new LinkedList<VarStatement>();
			for (VarStatement v2 : varStmts) {
				varStatements.add(v2);
			}
			symbolTable.put(v.getName(), varStatements);
		}

		if (fIdentifier != null) {
			symbolTable.remove(fIdentifier);
		}
		if (fArgsList != null) {
			for (String s : fArgsList) {

				Deque<VarStatement> varEntry = symbolTable.get(s);
				Deque<VarStatement> varEntry1 = symbolTable.get(s);
				for (VarStatement v : varEntry) {
					if (v.getTempName().equals(
							"formal_" + s + "_" + functionDepth)) {
						varEntry1.remove(v);
					}
				}
				symbolTable.put(s, varEntry1);

			}
		}

		functExpression.setType(UnknownType.getInstance());
		functionDepth--;
		return functExpression;
	}

	// -----------------------Phase 3-------------------

	/** Analyze a ObjectLiteral. */
	@Override
	public Tree visit(final ObjectLiteral objectLiteral) {

		// objectLiteral.setType(UnknownType.getInstance());

		ArrayList<PropertyPair> propertyList = objectLiteral
				.getPropertyNameAndValueList();

		if (propertyList != null)
			for (int i = 0; i < propertyList.size(); i++) {
				visitNode(propertyList.get(i));
			}

		objectLiteral.setType(UnknownType.getInstance());
		return objectLiteral;
	}

	/** Analyze a PropertyPair. */
	@Override
	public Tree visit(final PropertyPair property) {

		// property.setType(UnknownType.getInstance());
		visitNode(property.getPropertyValue());
		property.setType(UnknownType.getInstance());
		return property;
	}

	/** Analyze a Property accesor. */
	@Override
	public Tree visit(final PropertyAccessorExpression propertyAccessor) {
		propertyAccessor.setType(UnknownType.getInstance());
		visitNode(propertyAccessor.getMemberExpr());

		if (propertyAccessor.getExp() != null) {
			visitNode(propertyAccessor.getExp());
		}
		// propertyAccessor.setType(UnknownType.getInstance());
		return propertyAccessor;
	}

	/** Analyze a NewExpression. */
	@Override
	public Tree visit(final NewExpression newExpression) {
		newExpression.setType(UnknownType.getInstance());
		visitNode(newExpression.getMemberExp());

		if (newExpression.getArguments() != null)
			for (Expression n : newExpression.getArguments()) {
				visitNode(n);
			}

		return newExpression;
	}

	/** Analyze a This. */
	@Override
	public Tree visit(final ThisLiteral thisLiteral) {
		thisLiteral.setType(UnknownType.getInstance());

		return thisLiteral;
	}

	// ---------------------------------------------------------------------------------------------------
	/** Analyze a program. */
	@Override
	public Tree visit(final Program program) {
		visitEach(program.getList());

		List<VarStatement> vars = new ArrayList<VarStatement>();
		for (Entry<String, Deque<VarStatement>> entry : symbolTable.entrySet()) {

			Deque<VarStatement> v = entry.getValue();

			for (VarStatement varStmt : v) {
				vars.add(varStmt);
			}
		}
		program.setVarNodes(vars);

		return null;
	}

	/** Analyze a string literal. */
	@Override
	public Tree visit(final StringLiteral stringLiteral) {
		// always has String type
		stringLiteral.setType(StringType.getInstance());

		// return the node so that it can be re-assigned by its parent
		return stringLiteral;
	}

	/** Analyze a var statement. */
	@Override
	public Tree visit(final VarStatement varStatement) {
		// there is nothing to do if this is pass 2
		if (pass == 2) {
			return null;
		}

		//
		// the following code is only executed on pass 1
		//
		if (functionDepth < 0) {
			functionDepth = 0;
		}
		// record the current function depth
		varStatement.setFunctionDepth(functionDepth);

		// generate a temp name to use at codegen time
		varStatement.setTempName("var_" + varStatement.getName() + "_"
				+ functionDepth);
		// if(functionDepth==0){
		// TSObject.getGlobalObject().put(varStatement.getName(),
		// TSValue.make(value));
		// }

		// is there a stack for this name already in the symbol table?
		Deque<VarStatement> stack = symbolTable.get(varStatement.getName());
		if (stack == null) {
			// need to create the stack and insert it into the map
			stack = new LinkedList<VarStatement>();
			symbolTable.put(varStatement.getName(), stack);
		}

		// is there a declaration for this variable at the same function depth?
		// if so, then mark this declaration as redundant.
		VarStatement top = stack.peekFirst();
		if ((top != null) && (top.getFunctionDepth() == functionDepth)) {
			varStatement.setIsRedundant();
		}
		// else push the current VarStatment onto the stack
		else {
			stack.addFirst(varStatement);
		}

		return null;
	}

}
