package ts.tree;

import ts.Location;
import ts.tree.visit.TreeVisitor;

/**
 * @author Madhuri Gurumurthy
 * 
 *         AST Finally statement node
 * 
 */
public class FinallyStatement extends Statement {
	private Statement finallyBlckStmt;

	public FinallyStatement(Location loc, final Statement stm1) {
		super(loc);
		this.finallyBlckStmt = stm1;
	}

	/**
	 * @return the finallyBlckStmt
	 * 
	 *         Return the block statement
	 */
	public Statement getFinallyBlckStmt() {
		return finallyBlckStmt;
	}

	@Override
	public <T> T apply(TreeVisitor<T> visitor) {
		return visitor.visit(this);
	}

}
