package ts.tree;

import java.util.ArrayList;
import java.util.List;

import ts.Location;
import ts.tree.visit.TreeVisitor;

/**
 * @author Madhuri Gurumurthy
 * 
 *         AST catch statement node
 * 
 */
public class CatchStatement extends Statement {

	private Statement blockStmt;
	private String cIdentifier;

	List<VarStatement> catchVars = null;

	/**
	 * 
	 * @param loc
	 *            source code location of catch statement
	 * @param blockStmt
	 *            Block statement associated with the catch
	 * @param cIdentifier
	 *            catch identifier
	 * 
	 */
	public CatchStatement(Location loc, Statement blockStmt, String cIdentifier) {
		super(loc);
		this.blockStmt = blockStmt;
		this.cIdentifier = cIdentifier;
	}

	/**
	 * @return the blockStmt
	 */
	public Statement getBlockStmt() {
		return blockStmt;
	}

	/**
	 * @param blockStmt
	 *            the blockStmt to set
	 */
	public void setBlockStmt(Statement blockStmt) {
		this.blockStmt = blockStmt;
	}

	/**
	 * @return the cIdentifier
	 */
	public String getCIdentifier() {
		return cIdentifier;
	}

	/**
	 * @param cIdentifier
	 * 
	 *            the cIdentifier to set
	 */
	public void setCIdentifier(String cIdentifier) {
		this.cIdentifier = cIdentifier;
	}

	/**
	 * @return the catchVars
	 * 
	 *         Return the vars of the catch block;
	 */
	public List<VarStatement> getCatchVars() {
		return catchVars;
	}

	/**
	 * @param catchVars
	 *            the catchVars to set
	 */
	public void setCatchVars(List<VarStatement> catchVars) {
		this.catchVars = catchVars;
	}

	@Override
	public <T> T apply(TreeVisitor<T> visitor) {
		return visitor.visit(this);
	}

}
