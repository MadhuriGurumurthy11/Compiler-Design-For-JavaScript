package ts.tree;

import ts.Location;
import ts.tree.visit.TreeVisitor;

/**
 * @author Madhuri Gurumurthy
 * 
 *         AST function expression node
 * 
 */
public class PropertyPair extends Expression {

	String propertyName;
	Expression propertyValue;

	public PropertyPair(Location loc, String propertyName2,
			Expression propertyValue2) {
		super(loc);
		this.propertyName = propertyName2;
		this.propertyValue = propertyValue2;
	}

	/**
	 * @return the propertyName
	 */
	public String getPropertyName() {
		return propertyName;
	}

	/**
	 * @param propertyName
	 *            the propertyName to set
	 */
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	/**
	 * @return the propertyValue
	 */
	public Expression getPropertyValue() {
		return propertyValue;
	}

	/**
	 * @param propertyValue
	 *            the propertyValue to set
	 */
	public void setPropertyValue(Expression propertyValue) {
		this.propertyValue = propertyValue;
	}

	@Override
	public <T> T apply(TreeVisitor<T> visitor) {
		return visitor.visit(this);
	}

}
