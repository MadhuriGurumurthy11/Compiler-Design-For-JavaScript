package ts.tree;

import ts.Location;
import ts.tree.type.Type;
import ts.tree.visit.TreeVisitor;

/**
 * @author Madhuri Gurumurthy
 *
 *         AST throw node
 */
public class ThrowStatement extends Statement {

	private Expression exp;

	public ThrowStatement(Location loc, Expression exp) {
		super(loc);
		this.exp = exp;
	}

	/**
	 * @return the exp
	 * 
	 *         Return the expression .
	 */
	public Expression getExp() {
		return exp;
	}

	/**
	 * @param exp
	 *            the expression to set
	 */
	public void setExp(Expression exp) {
		this.exp = exp;
	}

	@Override
	public <T> T apply(TreeVisitor<T> visitor) {
		return visitor.visit(this);
	}

}
