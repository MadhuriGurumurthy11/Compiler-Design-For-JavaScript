package ts.tree;

import ts.Location;
import ts.tree.visit.TreeVisitor;

/**
 * @author Madhuri Gurumurthy
 * 
 *         AST Return statement node
 * 
 */
public class ReturnStatement extends Statement {

	private Expression exp;

	/**
	 * 
	 * @param loc
	 *            source code location of Try Statement
	 * @param exp
	 *            Expression associated with the return
	 */
	public ReturnStatement(Location loc, Expression exp) {
		super(loc);
		this.exp = exp;
	}

	/**
	 * 
	 * @return the expression
	 */
	public Expression getExp() {
		return exp;
	}

	/**
	 * 
	 * @param exp
	 *            expression to be set.
	 */
	public void setExp(Expression exp) {
		this.exp = exp;
	}

	@Override
	public <T> T apply(TreeVisitor<T> visitor) {
		return visitor.visit(this);
	}

}
