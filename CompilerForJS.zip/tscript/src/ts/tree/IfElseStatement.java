/**
 * 
 */
package ts.tree;

import ts.Location;
import ts.tree.visit.TreeVisitor;

/**
 * @author Madhuri Gurumurthy
 *
 *         AST if else node
 */
public class IfElseStatement extends Statement {

	private Expression exp;
	private Statement ifStmt;

	private Statement elseStmt;

	public IfElseStatement(Location loc, Expression exp, Statement stmt1,
			Statement stmt2) {
		super(loc);
		this.exp = exp;
		this.ifStmt = stmt1;
		this.elseStmt = stmt2;
	}

	/**
	 * Get the expression subtree of the node.
	 *
	 * @return the expression subtree.
	 */
	public Expression getExp() {
		return exp;
	}

	/**
	 * @return the ifStmt
	 */
	public Statement getIfStmt() {
		return ifStmt;
	}

	/**
	 * @return the elseStmt
	 */
	public Statement getElseStmt() {
		return elseStmt;
	}

	@Override
	public <T> T apply(TreeVisitor<T> visitor) {
		return visitor.visit(this);
	}

}
