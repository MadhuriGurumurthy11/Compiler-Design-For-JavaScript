/**
 * 
 */
package ts.support;

/**
 * @author Madhuri Gurumurthy
 *
 *         Supporting class for throw and try
 */
@SuppressWarnings("serial")
public class TSException extends RuntimeException {
	public TSValue eValue;

	public TSException(final TSValue value) {
		super();
		this.eValue = value;
	}

	public TSValue getEValue() {
		return eValue;
	}
}
