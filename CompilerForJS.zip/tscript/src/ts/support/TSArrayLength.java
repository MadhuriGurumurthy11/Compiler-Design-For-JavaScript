package ts.support;

import java.util.Map;

/**
 * 
 * @author Madhuri Gurumurthy
 *
 *         This class provides support for string length function
 */
public class TSArrayLength implements TSCode {

	public TSValue findLengthOfArray(TSValue ths, TSValue[] arguments) {

		if (arguments[0] instanceof TSString) {

			return TSNumber.create(1.0);
		} else {
			TSObject obj = (TSObject) arguments[0];
			int size = obj.propertyMap.size();
			if (obj.propertyMap.containsKey("count"))
				return TSNumber.create(size - 1);
			else
				return TSNumber.create(size);
		}
	}

	@Override
	public TSValue execute(boolean isConstructorCall, TSValue ths,
			TSValue[] arguments, TSEnvironment env) {
		return findLengthOfArray(ths, arguments);
	}
}
