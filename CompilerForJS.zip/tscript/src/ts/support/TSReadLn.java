package ts.support;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import ts.Message;

/**
 * @author Madhuri Gurumurthy
 * 
 *         Represent a non standard built-in function to read a line from input
 *         stream
 */
public class TSReadLn implements TSCode {

	// public static TSReadLn instance = new TSReadLn( );

	// provide support to read lines from stdin
	private static BufferedReader in = new BufferedReader(
			new InputStreamReader(System.in));

	public static TSValue doReadln() {
		try {
			String line = in.readLine();

			if (line == null) // EOF?
			{
				return TSNull.value;
			} else {
				return TSString.make(line); // readLine strips off
													// newline
			}

		} catch (IOException ioe) {
			Message.executionError("I/O exception in readln");
		}
		return null;
	}

	@Override
	public TSValue execute(boolean isConstructorCall, TSValue ths,
			TSValue[] arguments, TSEnvironment env) {

		return doReadln();
	}
}
