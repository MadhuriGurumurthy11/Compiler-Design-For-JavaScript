package ts.support;

import ts.Message;
import ts.tree.Expression;
import ts.tree.visit.Encode;

/**
 * The super class for all Tscript values.
 */
public abstract class TSValue {
	//
	// conversions (section 9)
	//

	/**
	 * Convert to Primitive. Override only in TSObject. Otherwise just return
	 * "this". Note: type hint is not implemented.
	 *
	 * @return the "this" value
	 */
	public TSPrimitive toPrimitive() {
		TSPrimitive prim = null;
		try {
			prim = (TSPrimitive) this;
		} catch (Exception e) {
			throw new TSException(
					TSString.make("TypeError: callFunction() applied to non-function value"));
		}
		return prim;
	}

	abstract public TSNumber toNumber();

	abstract public TSBoolean toBoolean();

	/**
	 * Convert to String. Override for all primitive types. It can't be called
	 * toString because of Object.toString.
	 *
	 * @return produced TSString value
	 */
	public TSString toStr() {
		TSPrimitive prim = this.toPrimitive();
		return prim.toStr();
	}

	//
	// binary operators (sections 11.5-11.11)
	//

	/**
	 * Perform a multiply. "this" is the left operand and the right operand is
	 * given by the parameter. Both operands are converted to Number before the
	 * multiply.
	 *
	 * @param right
	 *            value to be multiplied
	 * @return the result of the multiplication
	 */
	public final TSNumber multiply(final TSValue right) {
		TSNumber leftValue = this.toNumber();
		TSNumber rightValue = right.toNumber();
		return TSNumber.create(leftValue.getInternal()
				* rightValue.getInternal());
	}

	/**
	 * Perform an addition. "this" is the left operand and the right operand is
	 * given by the parameter. Both operands are converted to Number before the
	 * addition.
	 *
	 * @param right
	 *            value to be added
	 * @return the result of the addition
	 */
	public final TSPrimitive add(final TSValue right) {
		TSPrimitive leftValue = this.toPrimitive();
		TSPrimitive rightValue = right.toPrimitive();

		// if one of the operands is a string, then the operation is string
		// concatentation and the other operand must first be converted to
		// a string
		if (leftValue instanceof TSString) {
			return TSString.create(((TSString) leftValue).getInternal()
					+ rightValue.toStr().getInternal());
		} else if (rightValue instanceof TSString) {
			return TSString.create(leftValue.toStr().getInternal()
					+ ((TSString) rightValue).getInternal());
		}

		// othewise the operation is numeric addition
		return TSNumber.create(leftValue.toNumber().getInternal()
				+ rightValue.toNumber().getInternal());
	}

	/**
	 * Perform a subtraction. "this" is the left operand and the right operand
	 * is given by the parameter. Both operands are converted to Number before
	 * the subtraction.
	 *
	 * @param right
	 *            value to be subtracted
	 * @return the result of the subtraction
	 */
	public final TSPrimitive subtract(final TSValue right) {
		TSPrimitive leftValue = this.toPrimitive();
		TSPrimitive rightValue = right.toPrimitive();

		return TSNumber.create(leftValue.toNumber().getInternal()
				- rightValue.toNumber().getInternal());

		// double leftValue = this.toNumber().getInternal();
		// double rightValue = right.toNumber().getInternal();
		//
		// // TODO:
		// // System.out.println("l= " + leftValue + " r= " + rightValue);
		//
		// if (Double.isNaN(leftValue) || Double.isNaN(rightValue)) {
		// return TSNumber.create(Double.NaN);
		// } else if ((leftValue == Double.NEGATIVE_INFINITY && rightValue ==
		// Double.POSITIVE_INFINITY)
		// || (leftValue == Double.POSITIVE_INFINITY && rightValue ==
		// Double.NEGATIVE_INFINITY)) {
		// return TSNumber.create(Double.NaN);
		// } else if (leftValue == Double.NEGATIVE_INFINITY
		// && rightValue == Double.NEGATIVE_INFINITY) {
		// return TSNumber.create(Double.NEGATIVE_INFINITY);
		// } else if (leftValue == Double.POSITIVE_INFINITY
		// && rightValue == Double.POSITIVE_INFINITY) {
		// return TSNumber.create(Double.POSITIVE_INFINITY);
		// } else if (Double.isInfinite(leftValue)
		// && !Double.isInfinite(rightValue)) {
		// return TSNumber.create(leftValue);
		// } else if (Double.isInfinite(rightValue)
		// && !Double.isInfinite(leftValue)) {
		// return TSNumber.create(rightValue);
		// } else if (leftValue == -0.0 && rightValue == -0.0) {
		// return TSNumber.create(-0.0);
		// } else if (leftValue == +0.0 && rightValue == +0.0) {
		// return TSNumber.create(+0.0);
		// } else if (leftValue == +0.0 && rightValue == -0.0) {
		// return TSNumber.create(+0.0);
		// } else if (leftValue == -0.0 && rightValue == +0.0) {
		// return TSNumber.create(+0.0);
		// } else if (leftValue == 0.0 && rightValue != 0) {
		// return TSNumber.create(rightValue);
		// } else if (rightValue == 0.0 && leftValue != 0) {
		// return TSNumber.create(leftValue);
		// } else
		// return TSNumber.create(leftValue - rightValue);
	}

	/**
	 * Perform a division. "this" is the left operand and the right operand is
	 * given by the parameter. Both operands are converted to Number before the
	 * division.
	 * 
	 * @param right
	 *            value to be divided
	 * @return the result of the division
	 */
	public final TSNumber divide(final TSValue right) {
		// TSNumber leftValue = this.toNumber();
		// TSNumber rightValue = right.toNumber();
		// return TSNumber.create(leftValue.getInternal()
		// / rightValue.getInternal());

		double leftValue = this.toNumber().getInternal();
		double rightValue = right.toNumber().getInternal();
		if (Double.isNaN(leftValue) || Double.isNaN(rightValue)) {
			return TSNumber.create(Double.NaN);
		} else if (Double.isInfinite(leftValue)
				&& Double.isInfinite(rightValue)) {
			TSNumber.create(Double.NaN);
		} else if (leftValue == Double.POSITIVE_INFINITY && rightValue == 0) {
			return TSNumber.create(Double.POSITIVE_INFINITY);
		} else if (leftValue == Double.NEGATIVE_INFINITY && rightValue == 0) {
			return TSNumber.create(Double.NEGATIVE_INFINITY);
		} else if (leftValue == Double.POSITIVE_INFINITY && rightValue > 0
				|| leftValue == Double.NEGATIVE_INFINITY && rightValue < 0) {
			return TSNumber.create(Double.POSITIVE_INFINITY);
		} else if (leftValue == Double.POSITIVE_INFINITY && rightValue < 0
				|| leftValue == Double.NEGATIVE_INFINITY && rightValue > 0) {
			return TSNumber.create(Double.NEGATIVE_INFINITY);
		} else if (rightValue == Double.POSITIVE_INFINITY && leftValue > 0
				|| rightValue == Double.NEGATIVE_INFINITY && leftValue < 0) {
			return TSNumber.create(+0.0);
		} else if (rightValue == Double.POSITIVE_INFINITY && leftValue < 0
				|| rightValue == Double.NEGATIVE_INFINITY && leftValue > 0) {
			return TSNumber.create(-0.0);
		} else if (rightValue == 0.0 && leftValue == 0.0) {
			return TSNumber.create(Double.NaN);
		} else if (leftValue == 0.0 && rightValue > 0.0) {
			return TSNumber.create(+0.0);
		} else if (leftValue == 0.0 && rightValue < 0.0) {
			return TSNumber.create(-0.0);
		} else if (rightValue == 0.0 && leftValue < 0.0) {
			return TSNumber.create(Double.NEGATIVE_INFINITY);
		} else if (rightValue == 0.0 && leftValue > 0.0) {
			return TSNumber.create(Double.POSITIVE_INFINITY);
		}

		return TSNumber.create(leftValue / rightValue);

	}

	/**
	 * Perform a comparison. "this" is the left operand and the right operand is
	 * given by the parameter. Both operands are converted to
	 * Number/Boolean/Alphabet based on their input before the comparison.
	 * 
	 * @param right
	 *            one of the two operands of relational comparison.
	 * @return TSPrimitive
	 */
	public final TSPrimitive lesserThan(final TSValue right) {
		TSPrimitive valReturned = relationalComparision(right, true);

		if (valReturned instanceof TSUndefined) {
			valReturned = TSBoolean.create(false);
		}
		return valReturned;
	}

	/**
	 * Perform a comparison. "this" is the left operand and the right operand is
	 * given by the parameter. Both operands are converted to
	 * Number/Boolean/Alphabet based on their input before the comparison.
	 * 
	 * @param right
	 *            one of the two operands of relational comparison.
	 * @return TSPrimitive
	 */
	public final TSPrimitive greaterThan(final TSValue right) {
		TSPrimitive valReturned = relationalComparision(right, false);
		if (valReturned instanceof TSUndefined) {
			valReturned = TSBoolean.create(false);
		}
		return valReturned;
	}

	/**
	 * A help method which is called by lesserthan and greaterthan operators to
	 * perform relational comparison.
	 * 
	 * @param right
	 *            -one of the two operands of relational comparison
	 * @param leftFirst
	 *            -boolean flag used to control the order in which operations
	 *            with potentially visible side-effects are performed.
	 * @return TSPrimitive
	 */
	public TSPrimitive relationalComparision(final TSValue right,
			boolean leftFirst) {
		TSPrimitive leftValue = this.toPrimitive();
		TSPrimitive rightValue = right.toPrimitive();
		double leftNumberVal, rightNumberVal;
		String leftStringVal, rightStringVal;

		if (leftFirst) {
			leftValue = this.toPrimitive();
			rightValue = right.toPrimitive();
		} else {
			leftValue = right.toPrimitive();
			rightValue = this.toPrimitive();
		}

		if (!(leftValue instanceof TSString && rightValue instanceof TSString)) {
			leftNumberVal = leftValue.toNumber().getInternal();
			rightNumberVal = rightValue.toNumber().getInternal();

			// If nx is NaN, return undefined | If ny is NaN, return undefined.
			if ((Double.isNaN(leftNumberVal)) || (Double.isNaN(rightNumberVal))) {
				return TSUndefined.value;
			}

			// If nx and ny are the same Number value, return false.
			if (leftNumberVal == rightNumberVal) {
				return TSBoolean.create(false);
			}

			// If nx is +0 and ny is -0, return false.
			if (leftNumberVal == +0.0 && rightNumberVal == -0.0) {
				return TSBoolean.create(false);
			}

			// If nx is -0 and ny is +0, return false.
			if (leftNumberVal == -0.0 && rightNumberVal == +0.0) {
				return TSBoolean.create(false);
			}

			// If nx is +infinity, return false.
			if (leftNumberVal == Double.POSITIVE_INFINITY) {
				return TSBoolean.create(false);
			}
			// If ny is +infinity, return true.
			if (rightNumberVal == Double.POSITIVE_INFINITY) {
				return TSBoolean.create(true);
			}

			// If ny is -infinity, return false.
			if (rightNumberVal == Double.NEGATIVE_INFINITY) {
				return TSBoolean.create(false);
			}
			// If nx is -infinity, return true.
			if (leftNumberVal == Double.NEGATIVE_INFINITY) {
				return TSBoolean.create(true);
			}

			if ((leftNumberVal < rightNumberVal)
					&& ((leftNumberVal != 0 && rightNumberVal != 0)
							|| (leftNumberVal == 0 && rightNumberVal != 0)
							|| (leftNumberVal != 0 && rightNumberVal == 0)
							|| (leftNumberVal != Double.POSITIVE_INFINITY && rightNumberVal != Double.POSITIVE_INFINITY) || (leftNumberVal != Double.NEGATIVE_INFINITY && rightNumberVal != Double.NEGATIVE_INFINITY))) {

				return TSBoolean.create(true);
			} else {
				return TSBoolean.create(false);
			}
		}

		// both px and py are Strings
		else if (leftValue instanceof TSString
				&& rightValue instanceof TSString) {
			leftStringVal = leftValue.toStr().getInternal();
			rightStringVal = rightValue.toStr().getInternal();
			if (leftStringVal.startsWith(rightStringVal)) {
				return TSBoolean.create(false);
			}
			if (rightStringVal.startsWith(leftStringVal)) {
				return TSBoolean.create(true);
			}
			int i = 0;
			for (char c : leftStringVal.toCharArray()) {
				if (i < rightStringVal.length()
						&& rightValue.toString().charAt(i) != c)
					break;
				else
					i++;
			}

			int m = Character.getNumericValue(leftStringVal.toString()
					.charAt(i));
			int n = Character.getNumericValue(rightStringVal.toString().charAt(
					i));

			if (m < n) {
				return TSBoolean.create(true);
			} else {
				return TSBoolean.create(false);

			}
		}
		return TSBoolean.create(false);
	}

	/**
	 * Perform a equals comparison. "this" is the left operand and the right
	 * operand is given by the parameter. Both operands are converted to
	 * Number/Boolean/Alphabet based on their input before the comparison.
	 * 
	 * @param right
	 *            one of the two operands of equals relational comparison.
	 * @return TSPrimitive
	 */
	public final TSPrimitive equals(final TSValue right) {
		TSPrimitive leftValue = this.toPrimitive();
		TSPrimitive rightValue = right.toPrimitive();
		if (leftValue instanceof TSUndefined
				&& rightValue instanceof TSUndefined) {
			return TSBoolean.create(true);
		} else if (leftValue instanceof TSNull && rightValue instanceof TSNull) {
			return TSBoolean.create(true);
		} else if (leftValue instanceof TSNumber
				&& rightValue instanceof TSNumber) {
			if ((Double.isNaN(leftValue.toNumber().getInternal()))
					|| (Double.isNaN(rightValue.toNumber().getInternal()))) {
				return TSBoolean.create(false);
			} else if (leftValue.toNumber().getInternal() == rightValue
					.toNumber().getInternal()) {
				return TSBoolean.create(true);
			} else if (leftValue.toNumber().getInternal() == +0.0
					&& rightValue.toNumber().getInternal() == -0.0) {
				return TSBoolean.create(true);
			} else if (leftValue.toNumber().getInternal() == -0.0
					&& rightValue.toNumber().getInternal() == +0.0) {
				return TSBoolean.create(true);
			} else {
				return TSBoolean.create(false);
			}
		}

		else if (leftValue instanceof TSString
				&& rightValue instanceof TSString) {
			if (leftValue.toStr().getInternal()
					.equals(rightValue.toStr().getInternal()))
				return TSBoolean.create(true);
			else {
				return TSBoolean.create(false);
			}
		} else if (leftValue instanceof TSBoolean
				&& rightValue instanceof TSBoolean) {
			if (leftValue.toBoolean().getInternal() == rightValue.toBoolean()
					.getInternal()) {
				return TSBoolean.create(true);
			} else {
				return TSBoolean.create(false);
			}
		} else if (leftValue instanceof TSNull
				&& rightValue instanceof TSUndefined) {
			return TSBoolean.create(true);
		} else if (rightValue instanceof TSNull
				&& leftValue instanceof TSUndefined) {
			return TSBoolean.create(true);
		} else if (leftValue instanceof TSNumber
				&& rightValue instanceof TSString) {
			boolean val = ((leftValue.toNumber().getInternal()) == (rightValue
					.toNumber().getInternal()));
			return TSBoolean.create(val);
		} else if (rightValue instanceof TSNumber
				&& leftValue instanceof TSString) {
			boolean val = ((leftValue.toNumber().getInternal()) == (rightValue
					.toNumber().getInternal()));
			return TSBoolean.create(val);
		}

		// If Type(x) is Boolean, return the result of the comparison
		// ToNumber(x) == y.
		else if (leftValue instanceof TSBoolean) {
			boolean val = ((leftValue.toNumber().getInternal()) == (rightValue
					.toNumber().getInternal()));
			return TSBoolean.create(val);
		}
		// If Type(y) is Boolean, return the result of the comparison x
		// ==ToNumber(y).
		else if (rightValue instanceof TSBoolean) {
			boolean val = ((leftValue.toNumber().getInternal()) == (rightValue
					.toNumber().getInternal()));
			return TSBoolean.create(val);
		}
		// return false
		else {
			return TSBoolean.create(false);
		}
	}

	/**
	 * Perform an logical not. "this" operand is converted to boolean before
	 * logical not is performed.
	 * 
	 * @param rightValue
	 *            value on which logical not must be performed.
	 * @return TSValue
	 */

	public final TSValue logicalnot(final TSValue rightValue) {

		TSPrimitive uValue = rightValue.toPrimitive();

		if (uValue.toBoolean().getInternal()) {
			return TSBoolean.create(false);
		} else {
			return TSBoolean.create(true);
		}
	}

	// ---------------------------------------------------------------------------------------

	/**
	 * This method is called by functions
	 * 
	 * @param isConstructorCall
	 *            boolean flag to tell whether it is a constructor call.
	 * @param ths
	 *            reference of TSValue
	 * @param arguments
	 *            array of TSValue arguments.
	 * @return TSValue
	 */
	public TSValue callFunction(boolean isConstructorCall, TSValue ths,
			TSValue[] arguments) {

		TSString str = TSString.create("Not a function");
		throw new TSException(str);
	}

	/**
	 * 
	 * @param isConstructorCall
	 *            A boolean flag to tell if it's a constructor call
	 * @param ths
	 *            value of this
	 * @param arguments
	 *            TSValue args
	 * @return TSValue
	 */
	public TSValue callConstructor(boolean isConstructorCall, TSValue ths,
			TSValue[] arguments) {
		return new TSObject(null);

	}

	//
	// test for undefined
	//

	/**
	 * Is this value Undefined? Override only in TSUndefined.
	 *
	 * @return true or false, is this value the undefined value?
	 */
	public boolean isUndefined() {
		return false;
	}

	//
	// conversions to support optimized code generation
	//

	/**
	 * Convert a Java String to a TSString. Supports optimized code generation.
	 *
	 * @param value
	 *            Java String to be converted
	 * @return result of conversion
	 */
	public static TSValue make(String value) {
		return TSString.create(value);
	}

	/**
	 * Convert a Java double to a TSNumber. Supports optimized code generation.
	 *
	 * @param value
	 *            Java double to be converted
	 * @return result of conversion
	 */
	public static TSValue make(double value) {
		return TSNumber.create(value);
	}

	/**
	 * Do nothing, since value already a TSValue. Supports optimized code
	 * generation.
	 *
	 * @param value
	 *            a TSValue already
	 * @return the argument unchanged
	 */
	public static TSValue make(TSValue value) {
		return value;
	}

	/**
	 * @param propertyName
	 * 
	 *            The propertyName of the value required.
	 * @return the TSValue
	 */
	public TSValue get(String propertyName) {
		return this;

	}

	/**
	 * 
	 * @return the TSValue
	 */
	public TSValue get() {
		return this;

	}

	/**
	 * @param propertyName
	 *            the property Name
	 * @param value
	 *            The value of the property
	 */
	public void put(String propertyName, TSValue value) {
		throw new TSException(
				TSValue.make("Type Error: not an Object reference"));
	}
}
