package ts.support;

/**
 * Represents the single Null value (
 * <a href="http://www.ecma-international.org/ecma-262/5.1/#sec-8.2">ELS 8.2</a>
 * ).
 */
public final class TSNull extends TSPrimitive {
	/** Single value for this singleton class. */
	public static final TSNull value = new TSNull();

	// hide the constructor
	private TSNull() {
	}

	/** Convert to Number. Null gets mapped to +0.0. */
	public TSNumber toNumber() {
		return TSNumber.create(+0.0);
	}

	/** Convert to String ("null"). */
	public TSString toStr() {
		return TSString.create("null");
	}

	@Override
	/** Always returns false. */
	public TSBoolean toBoolean() {
		return TSBoolean.create(false);
	}

	/** Convert to Primitive ("undefined"). */
	public TSPrimitive toPrimitive() {
		return this;
	}

}
