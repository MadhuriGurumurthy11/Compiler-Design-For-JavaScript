package ts.support;

/**
 * 
 * @author Madhuri Gurumurthy
 *
 *         This class provides support for string split function
 */
public class TSStringSplit implements TSCode {

	public TSObject splitTheString(TSValue[] arguments) {
		String regex = " ";
		int limit = -1;
		String[] stringArray = null;
		String inputString = arguments[0].toStr().getInternal();

		if (arguments.length > 1) {
			regex = arguments[1].toStr().getInternal();
		}

		if (arguments.length > 2) {
			limit = (int) arguments[2].toNumber().getInternal();
			stringArray = inputString.split(regex, limit);
		} else {
			stringArray = inputString.split(regex);
		}

		TSObject obj = new TSObject();
		obj.propertyMap.put("count", TSNumber.create(stringArray.length));

		for (int i = 0; i < stringArray.length; i++) {
			obj.propertyMap.put(Integer.toString(i),
					TSString.create(stringArray[i]));
		}

		return obj;

	}

	@Override
	public TSValue execute(boolean isConstructorCall, TSValue ths,
			TSValue[] arguments, TSEnvironment env) {
		return splitTheString(arguments);
	}
}
