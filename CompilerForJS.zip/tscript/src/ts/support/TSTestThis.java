package ts.support;

/**
 * 
 * @author Madhuri Gurumurthy
 *
 */
public class TSTestThis implements TSCode {

	public static TSTestThis instance = new TSTestThis();

	@Override
	public TSValue execute(boolean isConstructorCall, TSValue ths,
			TSValue[] arguments, TSEnvironment env) {

		if (ths == null) {
			ths = TSObject.getGlobalObject();
		}
		TSValue thisObj = ths;
		ths.put("xyz", TSNumber.create(42));
		// TSObject obj = new TSObject();
		// obj.put("printXYZ", new TSFunctionObject(new TSPrintXYZ(), env));
		// TSObject.getGlobalObject().put("prototype", obj);

		// TSObject.getGlobalObject().setPrototype(obj);
		// if (ths == null) {
		// ths = TSObject.getGlobalObject();
		// }

		// ths.xyz = 42;

		return thisObj;
	}

}
