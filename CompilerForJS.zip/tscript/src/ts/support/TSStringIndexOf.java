package ts.support;

/**
 * 
 * @author Madhuri Gurumurthy
 * 
 *         This class supports string indexOf operation
 *
 */
public class TSStringIndexOf implements TSCode {

	public TSValue findIndexOf(TSValue[] arguments) {
		String inputString = arguments[0].toStr().getInternal().trim();
		String searchString = arguments[1].toStr().getInternal().trim();

		String[] strArr = inputString.split(" ");
		int index = -1;
		for (int i = 0; i < strArr.length; i++) {
			if (strArr[i].equals(searchString))
				index = i;
		}

		return TSNumber.create(index);

	}

	@Override
	public TSValue execute(boolean isConstructorCall, TSValue ths,
			TSValue[] arguments, TSEnvironment env) {
		return findIndexOf(arguments);
	}
}
