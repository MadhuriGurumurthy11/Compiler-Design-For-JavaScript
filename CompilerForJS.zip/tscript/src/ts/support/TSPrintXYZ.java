package ts.support;

/**
 * @author Madhuri Gurumurthy
 * 
 *         A non standard built-in function expects this object as argument.
 */
public class TSPrintXYZ implements TSCode {

	public static TSPrintXYZ instance = new TSPrintXYZ();

	@Override
	public TSValue execute(boolean isConstructorCall, TSValue ths,
			TSValue[] arguments, TSEnvironment env) {
		if (ths == null) {
			ths = TSObject.getGlobalObject();
		}
		TSObject thisObj = (TSObject) ths;
		TSValue val = thisObj.propertyMap.get("xyz");
		System.out.println(val.toStr().getInternal());

		// console.log(this.xyz);

		return thisObj;
	}

}
