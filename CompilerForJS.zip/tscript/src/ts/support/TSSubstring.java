package ts.support;

/**
 * 
 * @author Madhuri Gurumurthy
 *
 *         This class provides support for string substring function
 */
public class TSSubstring implements TSCode {

	public TSValue findSubstring(TSValue[] arguments) {

		String inputString = (arguments[0].toStr().getInternal()).trim();
		int startPosition = (int) arguments[1].toNumber().getInternal();
		int endPosition = (int) arguments[2].toNumber().getInternal();

		if (startPosition < 0 || Double.isNaN(startPosition)) {
			startPosition = 0;
		}
		if (startPosition > inputString.length()) {
			startPosition = inputString.length() - 1;
		}

		if (endPosition < 0 || Double.isNaN(endPosition)) {
			endPosition = 0;
		}

		if (endPosition > inputString.length()) {
			endPosition = inputString.length() - 1;
		}

		if (startPosition > endPosition) {
			int temp = startPosition;
			startPosition = endPosition;
			endPosition = temp;
		}

		String result = inputString.substring(startPosition);

		return TSString.create(result.trim());

	}

	@Override
	public TSValue execute(boolean isConstructorCall, TSValue ths, TSValue[] arguments, TSEnvironment env) {
		return findSubstring(arguments);
	}
}
