package ts.support;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author Madhuri Gurumurthy
 * 
 *         Represent an Object.
 *
 */
public class TSObject extends TSValue {

	public Map<String, TSValue> propertyMap = new HashMap<String, TSValue>();

	public static TSObject globalObject = new TSObject(null);

	TSObject prototype = null;

	public TSObject() {

	}

	/**
	 * @return the globalObject
	 */
	public static TSObject getGlobalObject() {
		return globalObject;
	}

	/**
	 * @param globalObject
	 *            the globalObject to set
	 */
	public static void setGlobalObject(TSObject globalObject) {
		TSObject.globalObject = globalObject;
	}

	/**
	 * 
	 * @param prototype
	 *            Prototype reference
	 */
	public TSObject(TSObject prototype) {
		this.prototype = prototype;
	}

	/**
	 * @return the prototype
	 */
	public TSObject getPrototype() {
		return prototype;
	}

	/**
	 * @param prototype
	 *            the prototype to set
	 */
	public void setPrototype(TSObject prototype) {
		this.prototype = prototype;
	}

	/**
	 * @return the propertyMap
	 */
	public Map<String, TSValue> getPropertyMap() {
		return propertyMap;
	}

	/**
	 * @param propertyMap
	 *            the propertyMap to set
	 */
	public void setPropertyMap(Map<String, TSValue> propertyMap) {
		this.propertyMap = propertyMap;
	}

	/**
	 * @param propertyName
	 * 
	 *            The propertyName of the value required.
	 * @return the TSValue
	 */
	public TSValue get(String propertyName) {
		// TSValue value = this.prototype.propertyMap.get(propertyName);
		// if (value == null) {
		// return TSUndefined.value;
		// }
		// return propertyMap.get(propertyName);

		if (propertyName.compareTo("prototype") == 0) {
			return propertyMap.get(propertyName);
		}

		TSValue val = propertyMap.get(propertyName);
		if (val == null) {
			TSObject obj = this;
			while ((obj = obj.getPrototype()) != null) {
				val = obj.propertyMap.get(propertyName);
				if (val != null)
					return val;
			}
		}
		return val;
	}

	/**
	 * @param propertyName
	 *            the property Name
	 * @param value
	 *            The value of the property
	 */
	public void put(String propertyName, TSValue value) {

		if (this.propertyMap == null) {
			this.propertyMap = new HashMap<String, TSValue>();
		}

		this.propertyMap.put(propertyName, value);
	}

	/**
	 * toNumber conversion
	 */
	@Override
	public TSNumber toNumber() {
		return this.toPrimitive("number").toNumber();
	}

	/**
	 * toStr conversion
	 */
	@Override
	public TSString toStr() {
		return this.toPrimitive("string").toStr();
	}

	/**
	 * to get the boolean value
	 */
	public TSBoolean toBoolean() {
		return TSBoolean.create(true);
	}

	/**
	 * TODO:
	 * 
	 * @param propValue
	 *            prototype value
	 * @return TSObject
	 */
	public static TSObject create(TSObject propValue) {
		// prototype = propValue;
		return new TSObject(propValue);

	}

	/**
	 * 
	 * @param isConstructorCall
	 *            A boolean flag to tell if it's a constructor call
	 * @param ths
	 *            value of this
	 * @param arguments
	 *            TSValue args
	 * @return TSValue
	 */
	public TSValue callConstructor(boolean isConstructorCall, TSValue ths, TSValue[] arguments) {
		TSObject obj = new TSObject();
		TSValue prototype = this.get("prototype");
		if (prototype == null || !(prototype instanceof TSObject))
			obj.setPrototype(null);
		else {
			obj.setPrototype((TSObject) prototype);
		}
		return obj;
	}

	/**
	 * to check if the property is present or not
	 * 
	 * @param prop
	 *            property key to get the value
	 * @return boolean
	 */
	public boolean containsTheProperty(String prop) {
		if (propertyMap.containsKey(prop)) {
			return true;
		} else if (prototype != null && prototype.containsTheProperty(prop)) {
			return true;
		} else
			return false;
	}

	/**
	 * to get the primitive value
	 */
	public TSPrimitive toPrimitive() {
		return this.toPrimitive("number");
	}

	/**
	 * to get the primitive value, that supports hint
	 * 
	 * @param hint
	 *            the hint send from toNumber or toString
	 * @return TSPrimitive
	 */
	public TSPrimitive toPrimitive(String hint) {
		if (hint.equalsIgnoreCase("string")) {
			if (this.containsTheProperty("toString")) {
				return this.get("toString").callFunction(false, this, null).toPrimitive();
			} else {
				if (this.containsTheProperty("valueOf")) {
					return this.get("valueOf").callFunction(false, this, null).toStr().toPrimitive();
				}
			}
		} else {
			if (hint.equalsIgnoreCase("number") || hint == null) {
				if (this.containsTheProperty("valueOf")) {
					return this.get("valueOf").callFunction(false, this, null).toPrimitive();
				} else {
					if (this.containsTheProperty("toString")) {
						return this.get("toString").callFunction(false, this, null).toPrimitive();
					}
				}
			}
		}

		throw new TSException(TSValue.make("Type error"));
	}
}