package ts.support;

/**
 * 
 * @author Madhuri Gurumurthy
 *
 *         This class provides support for string trim function
 */
public class TSStringTrim implements TSCode {

	public TSValue trimTheString(TSValue[] arguments) {

		String inputString = arguments[0].toStr().getInternal();
		String returnValue = inputString.trim();
		return TSString.create(returnValue);

	}

	@Override
	public TSValue execute(boolean isConstructorCall, TSValue ths,
			TSValue[] args, TSEnvironment env) {
		return trimTheString(args);
	}
}
