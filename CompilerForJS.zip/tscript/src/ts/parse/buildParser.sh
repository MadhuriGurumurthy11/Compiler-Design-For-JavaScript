#!/bin/bash

java -ea -jar ../../../build/lib/antlr.jar Tscript.g4 -no-listener -package ts.parse

